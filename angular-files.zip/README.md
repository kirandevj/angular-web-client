Visuals

https://www.jqwidgets.com
https://www.ngdevelop.tech/best-angular-chart-libraries/


# RiskApp
ng build --prod --base-href /apps/
ng build --prod --base-href /apps/ --aot --output-hashing none

Interface
http://brspwferiskd1.ad.corp.local/apps/index.html
http://ausasmid01.ad.corp.local:99/apps/index.html



ng s -o --port 4201



Pro
nng 

ng build --target production --build-optimizer --vendor-chunk --base-href /apps/
ng build --target=production --environment=production --base-href /apps/

npm install typescript@latest --save

Run
ng serve --host 0.0.0.0 --port 4201 --open to test latest



3rd Party Library Installation
Simply install your library via npm install lib-name --save and import it in your code.

If the library does not include typings, you can install them using npm:

npm install d3 --save
npm install @types/d3 --save-dev

https://github.com/angular/angular-cli

ng-select
https://basvandenberg.github.io/ng-select/#/getting-started



update to latest

ng new my-app --routing --prefix ma --ng4 --style scss
ng doc


`ng new --help`
### full creation of an app
`ng new my-app`
### just report the schema of the app without creation
`ng new my-app --dry-run`
### genereate new with skipping installation of the node modules 
`ng new my-app --skip-install`
### get latest angular
`ng new my-app --skip-install --ng4`
### change the prefix of the elements from default app to desired
`ng new my-app --prefix puh --skip-install --ng4`
### skip tests
`ng new my-app --skip-tests --prefix puh --skip-install --ng4`
### change the style to scss
`ng new my-app --skip-tests --prefix puh --skip-install --ng4 --style scss`
### add routing
`ng new my-app --routing --skip-tests --prefix puh --skip-install --ng4 --style scss`

Options to config the CLI

I. ng new <some-flags>
II. Manually  edit .angular-cli.json
III. ng set <property> <value>
ng set you can do it localy or globaly --global / -g

ng set defaults.styleExt scss
or
ng set defaults.styleExt scss -g


LINTING
ng lint --help

ng lint --format stylish // for easy reading of the files
ng lint --fix // autocorrect all files

npm install source-map-explorer --save-dev


#website
old website is:
\\brspdevwfe1.ad.corp.local
api
http://webapps.devtrinetapps.com
http://brspdevwfe1.ad.corp.local

new one is:
\\brspwferiskd1.ad.corp.local
http://brspwferiskd1.ad.corp.local

SignalR implementation
https://blog.sstorie.com/integrating-angular-2-and-signalr-part-2-of-2/
https://docs.microsoft.com/en-us/aspnet/signalr/
https://www.npmjs.com/package/signalr


Websockets
https://docs.microsoft.com/en-us/iis/configuration/system.webserver/websocket


npm cache clean --force

npm install

npm ls webpack

Web elements
https://medium.com/@IMM9O/web-components-with-angular-d0205c9db08f

kod
NiamaIstinskiKod1900

# RiskApp8

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 7.3.7.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).


GIT local repo

git init --bare "C:\Users\lpetrov\OneDrive - TriNet HR Corporation\risk-app10"
git remote add origin "C:\Users\lpetrov\OneDrive - TriNet HR Corporation\risk-app10"
git push origin master


in the remote exec
git config --bool core.bare true
git checkout "C:\Users\lpetrov\OneDrive - TriNet HR Corporation\risk-app10"
