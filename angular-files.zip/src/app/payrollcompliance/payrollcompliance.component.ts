import { Component, ViewEncapsulation, OnInit, ElementRef } from '@angular/core';
import { UserInfo, mapProduct, FooterInfo } from '@app/datamodels/index';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { FooterComponent } from '@app/common/index';

@Component({
  templateUrl: './payrollcompliance.html',
  styleUrls: ['./payrollcompliance.component.css']
})
export class PayrollComplianceComponent implements OnInit {
  mapoption: string;
  user: UserInfo;
  sendtofooter: FooterInfo;
  server: string;
  mapNYCOptions: Array<string>;
  mapNYCOptionsTitle: string;
  showmap = false;
  constructor(private ss: SharedServices, private gv: GlobalVariables, private element: ElementRef
  ) {
    // this.parentNativeElement = element.nativeElement;
  }
  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.mapNYCOptions = mapProduct;
    this.mapNYCOptionsTitle = 'NYC ' + this.mapNYCOptions[0];
    this.mapoption = 'LOSSRATIO';
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.showmap = true;
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - Accounting module landing page issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
  }
  mapsClicked(mapOpt: string) {
    this.mapoption = mapOpt;
  }
  mapsChange(t: string) {
    this.mapNYCOptionsTitle = 'NYC ' + t;
    this.mapoption = this.mapNYCOptionsTitle;
  }
}
