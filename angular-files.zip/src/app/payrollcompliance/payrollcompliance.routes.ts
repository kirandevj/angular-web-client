import { PayrollComplianceComponent } from './payrollcompliance.component';
import { PCMainProcessComponent } from './main-process/main-process.component';
import { PCMinWagesProcessComponent } from './min-wages/min-wages.component';

export const PayrollComplianceRoutes = [
    { path: '', component: PayrollComplianceComponent },
    { path: 'pcmainprocess', component: PCMainProcessComponent },
    { path: 'pcminwages', component: PCMinWagesProcessComponent }
];
