import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { UserInfo, FooterInfo } from '@app/datamodels/index';
import { IPreLoadedProcess } from '../../components/preloaded/pre-loaded.services';
// import { IOption } from 'ng-select';

@Component({
  templateUrl: './min-wages.html',
  styleUrls: ['./min-wages.css']
})
export class PCMinWagesProcessComponent implements OnInit {
  user: UserInfo;
  sendtofooter: FooterInfo;
  server: string;
  image0: string;
  image1: string;
  filenames: string[];
  showfile: boolean;
  sentToService: IPreLoadedProcess;
  headerName: string;
  headerBackUrl: string;
  constructor(
    private ss: SharedServices,
    private gv: GlobalVariables
  ) { }
  ngOnInit() {
    this.headerName = 'Payroll Compliance minimum wages and FLSA satus';
    this.headerBackUrl = 'payrollcompliance';
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.sentToService = {
      process: this.headerName,
      server: this.server,
      qryname: this.ss.getQueryName('PC', 'W', 0),
      username: this.user.name,
      c: this.ss.getPass(),
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      mmsback: 1
    };
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - ' + this.headerName + ' page issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
  }
  receiveFromFileService($event) {
    this.filenames = $event;
    if (this.filenames.length === 0) {
      this.showfile = false;
    } else {
      this.showfile = true;
    }
  }
}


