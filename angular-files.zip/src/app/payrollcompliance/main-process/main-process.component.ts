import { Component, ViewEncapsulation, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, ValidatorFn } from '@angular/forms';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { Selection, UserInfo, FooterInfo, PreloadedIDsInfoProcess } from '@app/datamodels/index';
import { IPreLoadedProcess } from '../../components/preloaded/pre-loaded.services';
import { ChannelService, ChannelEvent } from '@app/services/channel.sevice';
import { BehaviorSubject } from 'rxjs';
import { RiskFinanceServices } from '@app/riskfinance/shared/risk-finance.service';
// import { IOption } from 'ng-select';

@Component({
  templateUrl: './main-process.html',
  styleUrls: ['./main-process.css']
})
export class PCMainProcessComponent implements OnInit {
  @Input() message: ChannelEvent = {
    Name: '',
    ChannelName: '',
    Timestamp: (new Date(Date.now() - ((new Date()).getTimezoneOffset() * 60000))).toISOString().slice(0, -1),
    Data: {
      State: 'Process info here',
      PercentComplete: 0,
      json: ''
    },
    Json: ''
  };
  items: ChannelEvent[] = [];
  items$ = new BehaviorSubject(this.items);
  env = '';
  items2: string[] = [];
  dataprogressinfo = 'Progress info here';
  sentToSignalRChannel = 'payrollcompmain';
  receivedFromService = '';
  eventName: string;
  sendtofileloadermessages: any[] = ['', false];
  user: UserInfo;
  sendtofooter: FooterInfo;
  server: string;
  image0: string;
  image1: string;
  filenames: string[];
  showfile: boolean;
  sentToService: IPreLoadedProcess;
  headerName: string;
  headerBackUrl: string;
  transportedInfo = '';
  formEmpClassFilter: FormGroup;
  EmpClassFilters = [
    { id: 0, name: 'Assignee', checked: true, value: 'A' },
    { id: 1, name: 'Hourly Exempt', checked: false, value: 'HRX' },
    { id: 2, name: 'Ptnr Share', checked: false, value: 'K1' },
    { id: 3, name: 'K1BEN', checked: false, value: 'K1E' },
    { id: 4, name: 'Stat EE', checked: false, value: 'SE' },
    { id: 5, name: 'COBRA', checked: false, value: 'Z' },
    { id: 6, name: 'K1DIS', checked: false, value: 'K1D' },
    { id: 7, name: 'Teachers', checked: false, value: 'X' },
    { id: 8, name: 'Commision', checked: true, value: 'D' },
    { id: 9, name: 'Labor Cntr', checked: false, value: 'L' },
    { id: 10, name: 'Tipped', checked: false, value: 'TIP' },
    { id: 11, name: 'Contractor', checked: false, value: 'R' },
    { id: 12, name: 'BldnSerWor', checked: false, value: 'V' },
    { id: 13, name: 'Trusted Advisor', checked: false, value: 'U' },
    { id: 14, name: 'Doctors', checked: false, value: 'O' },
    { id: 15, name: 'Ministers', checked: false, value: 'M' },
    { id: 16, name: 'Expatriate', checked: true, value: 'E' },
    { id: 17, name: 'MSRRA', checked: false, value: 'J' },
    { id: 18, name: 'Founder', checked: false, value: 'F' },
    { id: 19, name: 'Piecework', checked: false, value: 'C' },
    { id: 20, name: 'Health Only', checked: false, value: 'H' },
    { id: 21, name: 'Prof Hrly', checked: false, value: 'W' },
    { id: 22, name: 'Attorney', checked: false, value: 'N' }
  ];
  formFLSAFilter: FormGroup;
  FLSAFilters = [
    { id: 0, name: 'Not in O', checked: true, value: 'O' }
  ];
  constructor(
    private rfs: RiskFinanceServices,
    private ss: SharedServices,
    private gv: GlobalVariables,
    private formBuilder: FormBuilder,
    private channelService: ChannelService,
    private cdr: ChangeDetectorRef
  ) {
    this.headerName = 'Payroll Compliance Main Process';
    this.headerBackUrl = 'payrollcompliance';
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.eventName = this.sentToSignalRChannel;
    this.gv.setall();
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - ' + this.headerName + ' page issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
    this.sentToService = {
      product: '5',
      process: this.headerName,
      server: this.server,
      qryname: this.ss.getQueryNameDailyHourMinute('PC', 'T', 0),
      username: this.user.name,
      c: this.ss.getPass(),
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      mmsback: 36,
      channel: this.eventName,
      eventname: this.eventName,
      signalr: this.channelService.connectionID$,
      transportedinfo: []
    };
    this.formEmpClassFilter = new FormGroup({});
    this.formFLSAFilter = new FormGroup({});
    this.formEmpClassFilter = this.formBuilder.group({
      EmpClassFilters: new FormArray([])
    });
    this.addEmpClassFilters();
    this.formFLSAFilter = this.formBuilder.group({
      FLSAFilters: new FormArray([])
    });
    this.addFLSAFilters();
    this.getTransportedInfo();
  }
  ngOnInit() {
    this.items.push(this.message);
  }
  onCheckboxChange(i: number) {
    this.EmpClassFilters[i].checked = this.formEmpClassFilter.controls.EmpClassFilters['controls'][i].value;
    this.getTransportedInfo();
  }
  onCheckboxChange2(i: number) {
    this.FLSAFilters[i].checked = this.formFLSAFilter.controls.FLSAFilters['controls'][i].value;
    this.getTransportedInfo();
  }
  receiveFromFileService($event) {
    this.filenames = $event;
    if (this.filenames.length === 0) {
      this.showfile = false;
    } else {
      this.showfile = true;
    }
  }

  addEmpClassFilters() {
    try {
      this.EmpClassFilters.map((o, i) => {
        const control = new FormControl(o.checked);
        (this.formEmpClassFilter.controls.EmpClassFilters as FormArray).push(control);
      });
    } catch {

    }
  }
  addFLSAFilters() {
    try {
      this.FLSAFilters.map((o, i) => {
        const control = new FormControl(o.checked);
        (this.formFLSAFilter.controls.FLSAFilters as FormArray).push(control);
      });
    } catch {

    }
  }
  get classFilters(): FormArray { return this.formEmpClassFilter.get('EmpClassFilters') as FormArray; }
  get flsaFilters(): FormArray { return this.formFLSAFilter.get('FLSAFilters') as FormArray; }
  getPreloadedIDsInfoProcess(v: PreloadedIDsInfoProcess) {
    this.rfs.getPreloadedIDsInfoProcess(this.server, v)
      .subscribe(
        res => {
          // console.log(res);
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              // /////////////////////////// Cleaning server and web folder
              // for (let i = 0; i < res.length; i++) {
              //   if (res[i] !== null) {
              //     const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
              //     // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
              //     const filenamefullpath = env + filename;
              //     let vv: CleanFileAndServer;
              //     if (i === 0) {
              //       vv = {
              //         fullfilename: res[i],
              //         qryname: v.qryname,
              //         c: v.c
              //       };
              //     } else {
              //       vv = {
              //         fullfilename: res[i],
              //         qryname: 'none',
              //         c: v.c
              //       };
              //     }
              //     this.ss.cleanFileServer(this.server, vv).subscribe(
              //       () => { }, err1 => { });
              //   }
              // }
              /////////////////////////// Cleaning all - web and oracle - END
            }, err => { });
        },
        err => {
          // console.log(err);
        });
  }
  /////////////////// Data loads here
  receiveFromFileServiceLoad(files: string[]) {
    if (files.length > 0) {
      // this.sentToSignalRChannel = files[0].replace('.', '').replace(/\s+/g, '_');
      this.sendtofileloadermessages[4] = this.sentToSignalRChannel;
      this.sendtofileloadermessages[5] = this.sentToSignalRChannel;
      // this.items = [];
      // this.items2 = [];
    }
  }
  ////////////////// Data loads end here
  receiveFromFileServiceProgress($event: ChannelEvent) {
    // this.items.push($event);
    console.log($event);
    // this.message = $event;
    // this.cdr.detectChanges();
    // if ($event.Data.FileNames.length > 0) {
    //   const allowedfiles = ['xlsx', 'csv'];
    //   const env = this.gv.get('excelfiledownload', 'excelfiledownload');
    //   // console.log($event.Data.FileNames);
    //   this.ss.downloadFilesFromSignalRService($event.Data.FileNames, env, allowedfiles, true, this.server);
    // }
    if ($event.Data.State.includes('Download')) {
      this.downloadFile($event.Data.State.replace('Download - ', ''));
    } else {
      this.items.push($event);
      const x = $event.Data.State + ' | Time of execution: ' + $event.Timestamp;
      this.items2.push(x);
      // console.log(x);
      this.message = $event;
    }
    this.cdr.detectChanges();
  }
  getTransportedInfo() {
    this.transportedInfo = '';
    this.EmpClassFilters.map((o) => {
      if (o.checked) {
        this.transportedInfo += o.value + ',';
      }
    });
    this.transportedInfo = this.transportedInfo.substr(0, this.transportedInfo.length - 1);
    this.transportedInfo += '|';
    this.FLSAFilters.map((o) => {
      if (o.checked) {
        this.transportedInfo += o.value + ',';
      }
    });
    this.transportedInfo = this.transportedInfo.substr(0, this.transportedInfo.length - 1);
    this.sentToService.transportedinfo = [this.transportedInfo];
    this.sentToService = JSON.parse(JSON.stringify(this.sentToService));
  }
  downloadFile(filename: string) {
    const env = this.gv.get('excelfiledownload', 'excelfiledownload');
    console.log(env);
    console.log(filename);
    this.ss.downloadFilesObservable([filename], env, ['xlsx', 'csv']).subscribe(
      res1 => {
        // console.log(res1);
        // --------------- Cleaning all - web and oracle - END
      }, err => {
        // console.log(err);
      });
  }
}


