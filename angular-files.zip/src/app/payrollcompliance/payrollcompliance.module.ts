import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SelectModule } from 'angular2-select';
import { PayCompNavBarComponent } from './nav/paycomp-navbar.component';
import { PayrollComplianceComponent } from './payrollcompliance.component';
import { PayrollComplianceServices } from './shared/payrollcompliance.services';
import { PayrollComplianceRoutes } from './payrollcompliance.routes';
import { ApiServices } from '@app/common/index';
import { LocalVariables } from './shared/local.variables';
import { FooterModule } from '@app/common/index';
import { SpinnerModule } from '@app/common/index';
import { PreLoadedModule } from '../components/preloaded/pre-loaded.module';
import { ProgressInfoModule } from '../components/progress-info/progress-info.module';
import { PCMainProcessComponent } from './main-process/main-process.component';
import { PCMinWagesProcessComponent } from './min-wages/min-wages.component';
import { RiskFinanceServices } from '@app/riskfinance/shared/risk-finance.service';

@NgModule({
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(PayrollComplianceRoutes),
    SelectModule,
    FooterModule,
    SpinnerModule,
    PreLoadedModule,
    ProgressInfoModule
  ],
  declarations: [
    PayCompNavBarComponent,
    PCMainProcessComponent,
    PayrollComplianceComponent,
    PCMinWagesProcessComponent
  ],
  providers: [
    PayrollComplianceServices,
    ApiServices,
    LocalVariables,
    RiskFinanceServices
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class PayrollComplianceModule {
  // selectedPro(): any {
  // }
}
