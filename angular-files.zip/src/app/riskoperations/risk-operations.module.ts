import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SelectModule } from 'angular2-select';
import { RunProcessVariable } from '@app/datamodels/index';
import { RiskOperationsServices } from './shared/risk-operations.service';
import { RiskOperationsComponent } from './risk-operations.component';
import { RiskOperationsRoutes } from './risk-operations.routes';
import { CarrierReportingComponent } from './carrierreporting/carrier-reporting.component';
import { RiskOptNavBarComponent } from './nav/risk-opt-navbar.component';
import { FileActionModule } from '../components/files/file-action.module';
import { SpinnerModule } from '@app/common/index';

@NgModule({
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(RiskOperationsRoutes),
    SelectModule,
    FileActionModule,
    SpinnerModule
  ],
  declarations: [
    RiskOperationsComponent,
    CarrierReportingComponent,
    RiskOptNavBarComponent
  ],
  providers: [
    RiskOperationsServices
  ]
})
export class RiskOperationsModule {
  selectedPro(): any {
  }
}
