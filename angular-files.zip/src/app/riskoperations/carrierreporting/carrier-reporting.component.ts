import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { RiskOperationsServices } from '../shared/risk-operations.service';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { LossRatio, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { CarrierWagesProcess } from '../shared/local.variables';
import { FileActionComponent } from '../../components/files/file-action.component';
import { SpinnerComponent } from '@app/common/index';

@Component({
  templateUrl: './carrier-reporting.html',
  styles: [`
  form {
    /* color: #0000ff;
    font-size: 14px;
    line-height: 1.42857143;
    background-color: #9999ff;
    background-image: none;
    */
    display: block;
    padding: 12px 12px;
    border: 4px solid #8080ff;
    border-radius: 10px;
  }
  .nav.navbar-nav {font-size: 15px;}
  li > a { color: aliceblue; }
  `]
})
export class CarrierReportingComponent implements OnInit {
  fdstime: Date;
  sdstime: Date;
  showspinner: boolean;
  filenames: string[];
  showfile: boolean;
  showbuttontoprocess: boolean;
  showbuttontoprocessspin: boolean;
  sendtofileloadermessages: any[] = ['', false];
  filetobeprocess: string;
  user: UserInfo;
  sendtofooter: FooterInfo;
  form: FormGroup;
  server: string;
  image0: string;
  image1: string;
  Servers: Array<Selection>;
  PlaceholderServers: string;
  constructor(private ros: RiskOperationsServices, private ss: SharedServices,
    private gv: GlobalVariables, private route: ActivatedRoute) { }

  ngOnInit() {
    this.fdstime = new Date();
    this.sdstime = new Date();
    this.fdstime.setMonth(this.sdstime.getMonth() - 1);
    this.fdstime.setDate(this.fdstime.getDate() + 1);
    document.getElementById('FdsDate')['valueAsDate'] = this.fdstime;
    document.getElementById('SdsDate')['valueAsDate'] = this.sdstime;
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.form.addControl('Server', new FormControl());
    this.Servers = this.ss.getServers();
    this.PlaceholderServers = this.Servers[0].label;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.sendtofileloadermessages[0] = this.server;
    this.sendtofileloadermessages[1] = false;
    this.showbuttontoprocess = false;
    this.showbuttontoprocessspin = false;
  }
  ProcessChubbWages(formValues: any) {
    this.showbuttontoprocessspin = true;
    this.showbuttontoprocess = false;
    const rr: CarrierWagesProcess = {
      server: this.ss.getFormValue(formValues.Product, this.PlaceholderServers, this.Servers, 'value', 'label'),
      fdsdate: ('00' + ((document.getElementById('FdsDate')['valueAsDate']).getMonth() + 1).toString())
        .substring(('00' + ((document.getElementById('FdsDate')['valueAsDate']).getMonth() + 1).toString()).length - 2)
        + '/' + ('00' + ((document.getElementById('FdsDate')['valueAsDate']).getDate() + 1).toString())
          .substring(('00' + ((document.getElementById('FdsDate')['valueAsDate']).getDate() + 1).toString()).length - 2)
        + '/' + (document.getElementById('FdsDate')['valueAsDate']).getFullYear().toString(),
      sdsdate: ('00' + ((document.getElementById('SdsDate')['valueAsDate']).getMonth() + 1).toString())
        .substring(('00' + ((document.getElementById('SdsDate')['valueAsDate']).getMonth() + 1).toString()).length - 2)
        + '/' + ('00' + ((document.getElementById('SdsDate')['valueAsDate']).getDate() + 1).toString())
          .substring(('00' + ((document.getElementById('SdsDate')['valueAsDate']).getDate() + 1).toString()).length - 2)
        + '/' + (document.getElementById('SdsDate')['valueAsDate']).getFullYear().toString(),
      qryname: this.ss.getQueryName('C', 'W', 0),
      username: this.user.name,
      filename: this.gv.get('excelfilesave', 'excelfilesave').replace('excel', 'ManagedFiles') + this.filetobeprocess,
      filenameshort: this.filetobeprocess,
      c: this.ss.getPass(),
      env: this.gv.get('excelfilesave', 'excelfilesave')
    };
    // // console.log(rr);
    this.getCarrierWagesProcess(rr);
  }
  getCarrierWagesProcess(v: CarrierWagesProcess) {
    this.ros.getCarrierWagesProcess(this.server, v)
      .subscribe(
        res => {
          // // console.log(res);
          this.showbuttontoprocessspin = false;
          this.showbuttontoprocess = false;
          this.sendtofileloadermessages[1] = false;
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              // // console.log('downloaded all');
              // // console.log(res1);
              for (let i = 0; i < res.length; i++) {
                if (res[i] !== null) {
                  /////////////////////////// Cleaning server and web folder
                  const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                  // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
                  // const filenamefullpath = env + filename;
                  let vv: CleanFileAndServer;
                  if (i === 0) {
                    vv = {
                      fullfilename: res[i],
                      qryname: v.qryname,
                      c: v.c
                    };
                  } else {
                    vv = {
                      fullfilename: res[i],
                      qryname: 'none',
                      c: v.c
                    };
                  }
                  this.ss.cleanFileServer(this.server, vv).subscribe(
                    () => { }, err1 => { });
                }
              }
              // --------------- Cleaning all - web and oracle - END
            }, err => { });
        },
        err => {
          // // console.log(err);
          this.showbuttontoprocessspin = false;
          this.showbuttontoprocess = false;
          this.sendtofileloadermessages[1] = false;
        });
  }
  /////////////////// Data loads here
  receiveFromFileService($event) {
    // // console.log($event);
    this.filenames = $event;
    if (this.filenames.length === 0) {
      this.showfile = false;
      this.showbuttontoprocess = false;
      this.showbuttontoprocessspin = false;
    } else {
      this.showfile = true;
      this.showbuttontoprocess = true;
      this.filetobeprocess = this.filenames[0];
    }
  }
  ////////////////// Data loads end here
}
