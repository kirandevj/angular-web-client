import { RiskOperationsComponent } from './risk-operations.component';
import { CarrierReportingComponent } from './carrierreporting/carrier-reporting.component';

export const RiskOperationsRoutes = [
  { path: '', component: RiskOperationsComponent },
  { path: 'carrierreporting', component: CarrierReportingComponent }
];
