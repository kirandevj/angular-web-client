export interface CarrierWagesProcess {
    server: string;
    fdsdate: string;
    sdsdate: string;
    qryname: string;
    username?: string;
    filename?: string;
    filenameshort?: string;
    c?: string;
    env?: string;
}
