import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SharedServices } from '@app/common/index';
// Import RxJs required methods
import { map, filter, scan, catchError, mergeMap } from 'rxjs/operators';
import { CarrierWagesProcess } from '../shared/local.variables';
import { routs } from '@app/datamodels/index';

@Injectable()
export class RiskOperationsServices {
  constructor(private http: HttpClient, private ss: SharedServices) { }
  getRouts = (): string[] => routs;
  getRout(r: string) {
    return routs.find(rout => rout.url === r);
  }
  getCarrierWagesProcess(api: string, v: CarrierWagesProcess): Observable<string[]> {
    return this.http.post(api + 'api/MainAPI?carrierwagesprocess=carrierwagesprocess', v).pipe(map((r: string[]) => {
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));
    // return this.http.post(api + 'api/MainAPI?carrierwagesprocess=carrierwagesprocess', v).map((r: Response) => r
    // ).catch((e: any) => Observable.throw(e.error || 'Server error'));
  }
}




