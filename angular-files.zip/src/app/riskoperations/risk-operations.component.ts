import { Component, ViewEncapsulation, OnInit, ElementRef } from '@angular/core';
import { UserInfo, mapProduct, FooterInfo } from '@app/datamodels/index';
import { SharedServices, GlobalVariables } from '@app/common/index';

@Component({
  templateUrl: './risk-operations.html',
  styleUrls: ['./risk-operations.css']
})
export class RiskOperationsComponent implements OnInit {
  server: string;
  mapoption: string;
  user: UserInfo;
  mapNYCOptions: Array<string>;
  mapNYCOptionsTitle: string;
  showmap = false;
  constructor(private ss: SharedServices, private gv: GlobalVariables, private element: ElementRef
  ) {
    // this.parentNativeElement = element.nativeElement;
  }
  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.mapNYCOptions = mapProduct;
    this.mapNYCOptionsTitle = 'NYC ' + this.mapNYCOptions[0];
    this.mapoption = 'LOSSRATIO';
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.showmap = true;
  }
  mapsClicked(mapOpt: string) {
    this.mapoption = mapOpt;
  }
  mapsChange(t: string) {
    if (t === 'NYC All') { this.mapNYCOptionsTitle = t; } else { this.mapNYCOptionsTitle = 'NYC ' + t; }
    this.mapoption = this.mapNYCOptionsTitle;
    this.mapsClicked(this.mapoption);
  }
}

  // // sleder options
  // sliderWidth: number;
  // minYear: number;
  // maxYear: number;
    // // slider
    // this.minYear = 2014;
    // this.maxYear = 2017;
    // this.sliderWidth = document.getElementById('nav0').offsetWidth;
    // this.initilizedSlider(this.sliderWidth, this.minYear, this.maxYear);
    // // // console.log(document.getElementById('nav0').offsetWidth);

  // initilizedSlider(w: number, minyr: number, maxyr: number) {
  //   // slider
  //   let svg = d3.select('#slider0').attr('width', w),
  //     margin = { right: 34, left: 34 },
  //     width = +svg.attr('width') - margin.left - margin.right,
  //     height = +svg.attr('height');

  //   let hueActual = 0,
  //     hueTarget = maxyr,
  //     hueAlpha = 0.2,
  //     hueTimer = d3.timer(hueTween);

  //   let x = d3.scaleLinear()
  //     .domain([maxyr, minyr])
  //     .range([0, width])
  //     .clamp(true);

  //   let slider = svg.append('g')
  //     .attr('class', 'slider')
  //     .attr('transform', 'translate(' + margin.left + ',' + height / 2 + ')');

  //   slider.append('line')
  //     .attr('class', 'track')
  //     .attr('x1', x.range()[0])
  //     .attr('x2', x.range()[1])
  //     .select(function () { return this['parentNode']['appendChild'](this['cloneNode'](true)); })
  //     .attr('class', 'track-inset')
  //     .select(function () { return this['parentNode']['appendChild'](this['cloneNode'](true)); })
  //     .attr('class', 'track-overlay')
  //     .call(d3.drag()
  //       .on('start.interrupt', function () { slider.interrupt(); })
  //       .on('start drag', function () { hue(x.invert(d3.event.x)); }));

  //   slider.insert('g', '.track-overlay')
  //     .attr('class', 'ticks')
  //     .attr('transform', 'translate(0,' + 18 + ')')
  //     .selectAll('text')
  //     .data(x.ticks(maxyr - minyr))
  //     .enter().append('text')
  //     .attr('x', x)
  //     .attr('text-anchor', 'middle')
  //     .text(function (d) { return d; });

  //   let handle = slider.insert('circle', '.track-overlay')
  //     .attr('class', 'handle')
  //     .attr('id', 'handle0')
  //     .attr('r', 9);

  //   function hue(h: any) {
  //     hueTarget = h;
  //     hueTimer.restart(hueTween);
  //   }
  //   function hueTween() {
  //     let hueError = hueTarget - hueActual;
  //     if (Math.abs(hueError) < 1e-3) {
  //       hueActual = hueTarget;
  //       hueTimer.stop();
  //     }
  //     // tslint:disable-next-line:one-line
  //     else {
  //       hueActual += hueError * hueAlpha;
  //     }
  //     handle.attr('cx', x(hueActual));
  //     // svg.style('background-color', <any>d3.hsl(hueActual, 0.8, 0.8));
  //   }
  // }

  // sliderTouch() {
  //   // // console.log(document.getElementById('handle0'));
  // }
  // onClick() {
  //   this.modal.alert()
  //     .size('lg')
  //     .showClose(true)
  //     .title('A simple Alert style modal window')
  //     .body(`
  //           <h4>Alert is a classic (title/body/footer) 1 button modal window that
  //           does not block.</h4>
  //           <b>Configuration:</b>
  //           <ul>
  //               <li>Non blocking (click anywhere outside to dismiss)</li>
  //               <li>Size large</li>
  //               <li>Dismissed with default keyboard key (ESC)</li>
  //               <li>Close wth button click</li>
  //               <li>HTML content</li>
  //           </ul>`)
  //     .open();
  // }
