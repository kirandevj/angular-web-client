import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, pipe } from 'rxjs';
import { isUndefined } from 'util';

// Import RxJs required methods
import { map, filter, scan, catchError, mergeMap, delay } from 'rxjs/operators';

import {
    CleanFileAndServer,
    Selection, routs, Products, Productsall, Months, Year, Month,
    UserInfo, YesNo, LevelOfDataAnalyses, StatesOption, PyCy,
    ClaimsAmountsStructure, AscendingDescending, WccsrSlim
} from '@app/datamodels/index';

@Injectable()
export class ApiServices {
    constructor(private http: HttpClient) { }
    APIGetUserInfo(api: string): Observable<string> {
        const apiPoint = api + 'api/SecondaryAPI?getid=youridhere';
        // return this.http.post(apiPoint, '').pipe(map((r: Response) => {
        //     return r;
        // }
        // ), catchError((e: any) => Observable.throw(e)));
        return this.http.post(apiPoint, '').pipe(map((r: string) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));

    }
    APIMainCleanUp(api: string, encr: string): Observable<string> {
        const apiPoint = api + 'api/SecondaryAPI?n=0&encr=' + encr;
        return this.http.post(apiPoint, '').pipe(map((r: string) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));

    }
    APICleanFileServer(api: string, v: CleanFileAndServer): Observable<string> {
        const apiPoint = api + 'api/MainAPI?cleansystem=cleansystem';
        return this.http.post(apiPoint, v).pipe(map((r: string) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
    API_POST_Observable(apiceed: string, v: WccsrSlim, apicall: string): Observable<string[]> {
        return this.http.post(apiceed + apicall, v).pipe(map((r: string[]) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
}
