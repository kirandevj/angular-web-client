import { Injectable, Optional, SkipSelf } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject, BehaviorSubject } from 'rxjs';
import { Observer } from 'rxjs';
import { isUndefined } from 'util';
import {
  GetData, LevelOfDataAnalysesHealth, UsersNavigationDataLoad, Productsalllimit, ClientsOptions,
  DataSetsToLoad,
  ClientsCarveoutOptions,
  ExchangesAllOptions,
  HealthCarriers,
  HealthCategories,
  Productsfull, Dummy
} from '@app/datamodels/index';

// Import RxJs required methods
import { map, filter, scan, catchError, mergeMap } from 'rxjs/operators';

import {
  CleanFileAndServer,
  Selection, routs, Products, Productsall, Productsmedicalall, Months, Year, Month,
  UserInfo, YesNo, LevelOfDataAnalyses, StatesOption, PyCy,
  ClaimsAmountsStructure, AscendingDescending,
  PassportGetDataList, SOIGetDataList, AmbroseGetDataList, AccordGetDataList,
  PassportDataIntegrityList, SOIDataIntegrityList, AmbroseDataIntegrityList, AccordDataIntegrityList,
  Deliverablesall, Servers, DIHealthEligibility, LossStratificationOptions,
  ActuarialTrianglesLevels, ActuarialTrianglesOptions, HTTPReqVerb,
  PassportGetDataListClaimsOnly, SOIGetDataListClaimsOnly,
  AmbroseGetDataListClaimsOnly, AccordGetDataListClaimsOnly,
  PassportGetDataListRevenueSideOnly, SOIGetDataListRevenueSideOnly,
  AmbroseGetDataListRevenueSideOnly, AccordGetDataListRevenueSideOnly,
  VizIncomingInitialInfo, HealthOptionsFPF, HealthOptionsData,
  CarveOutOptions
} from '@app/datamodels/index';
@Injectable()
export class SharedServices {
  loggeduser: UserInfo = {
    module: 'f',
    name: 'f',
    email: 'f',
    rights: 'f',
    machine: 'f',
    signalrconnectionid: 'f'
  };
  user: Observable<UserInfo>;
  constructor(private http: HttpClient, private route: Router) { }
  cleanFileServer(api: string, v: CleanFileAndServer): Observable<string> {
    const apiPoint = api + 'api/MainAPI?cleansystem=cleansystem';
    return this.http.post(apiPoint, v).pipe(map((r: string) => {
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));
  }
  // tslint:disable-next-line:ban-types
  cleanJustFile(api: string, fullfilename: Object): Observable<string> {
    const apiPoint = api + 'api/SecondaryAPI?cleansystem=c';
    // return this.http.post(apiPoint, fullfilename).map((r: Response) => {
    //   return r;
    // }
    // ).catch((e: any) => Observable.throw(e.error || 'Server error'));
    return this.http.post(apiPoint, fullfilename).pipe(map((r: string) => {
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));
  }
  getClaimsAmountsStructure = (): Array<Selection> => ClaimsAmountsStructure;
  getLossStratificationOptions = (): Array<Selection> => LossStratificationOptions;
  getPyCy = (): Array<Selection> => PyCy;
  getStatesOption = (): Array<Selection> => StatesOption;
  getLevelOfDataAnalyses = (): Array<Selection> => LevelOfDataAnalyses;
  getLevelOfDataAnalysesHealth = (): Array<Selection> => LevelOfDataAnalysesHealth;
  getProducts = (): Array<Selection> => Products;
  getDataSetsToLoad = (): Array<Selection> => DataSetsToLoad;
  getHTTPReqTypes = (): Array<Selection> => HTTPReqVerb;
  getServers = (): Array<Selection> => Servers;
  getActuarialTrianglesOptions = (): Array<Selection> => ActuarialTrianglesOptions;
  getActuarialTrianglesLevels = (): Array<Selection> => ActuarialTrianglesLevels;
  getProductsAll = (): Array<Selection> => Productsall;
  getProductsFull = (): Array<Selection> => Productsfull;
  getProductsAllLimit = (): Array<Selection> => Productsalllimit;
  getHealthOptionsFPF = (): Array<Selection> => HealthOptionsFPF;
  getHealthOptionsData = (): Array<Selection> => HealthOptionsData;
  getProductsAllExtended = (): Array<Selection> => Productsmedicalall;
  getDeliverablesAll = (): Array<Selection> => Deliverablesall;
  getProductsMedicalAll = (): Array<Selection> => Productsmedicalall;
  getHealthCarriers = (): Array<Selection> => HealthCarriers;
  getHealthCategories = (): Array<Selection> => HealthCategories;
  getExchangesAllOptions = (): Array<Selection> => ExchangesAllOptions;
  getClientsOptionSelection = (): Array<Selection> => ClientsOptions;
  getClientsCarveoutOptionSelection = (): Array<Selection> => ClientsCarveoutOptions;
  getDIHealthEligibility = (): Array<Selection> => DIHealthEligibility;
  getDataIntegrityProcess(api: string, v: GetData): Observable<string> {
    const obj: GetData = {};
    obj.product = v.product;
    obj.option = v.option;
    obj.asofyr = v.asofyr;
    obj.asofmm = v.asofmm;
    obj.mmsback = v.mmsback;
    obj.qryname = v.qryname;
    obj.username = v.username;
    obj.c = v.c;
    obj.env = v.env;
    obj.filenameshort = v.filenameshort;
    const apiPoint = api + 'api/MainAPI?getdataintegrity=getdataintegrity';
    // return this.http.post(apiPoint, obj).map((r: Response) => {
    //   return r;
    // }
    // ).catch((e: any) => Observable.throw(e.error || 'Server error'));
    return this.http.post(apiPoint, obj).pipe(map((r: string) => {
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));
  }
  getDataProcess(api: string, v: GetData): Observable<string[]> {
    const apiPoint = api + 'api/MainAPI?riskgetdata=riskgetdata';
    return this.http.post(apiPoint, v).pipe(map((r: string[]) => {
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));
  }
  getDataConvertLongToShort = (input: string): string => {
    let t = '';
    switch (input) {
      case 'Claims':
        t = input;
        return t;
      case 'Wages':
        t = input;
        return t;
      case 'Clients':
        t = input;
        return t;
      case 'Rates':
        t = input;
        return t;
      case 'Claims - SOI':
        t = 'Claims';
        return t;
      case 'Claims - SOI Texas Mutual':
        t = 'ClaimsT';
        return t;
      case 'Retro bill rates':
        t = 'BRates';
        return t;
      case 'Claims - CCMSI / Gallagher Bassett':
        t = 'Claims_Passport';
        return t;
      case 'Claims - AIG':
        t = 'ClaimsAIG';
        return t;
      case 'Claims - CNA':
        t = 'ClaimsCNA';
        return t;
      case 'Claims - Zurich':
        t = 'ClaimsZ';
        return t;
      case 'Claims - Wausau':
        t = 'ClaimsW';
        return t;
      case 'Claims - Texas Mutual':
        t = 'ClaimsT';
        return t;
      case 'Wages - PAD File':
        t = 'WagesP';
        return t;
      case 'Rates Progression':
        t = 'RatesProg';
        return t;
      case 'WSE':
        t = 'WSE';
        return t;
      default:
        return t;
    }
  }
  getDataList = (option: string): Array<Selection> => {
    let t: Array<Selection> = [];
    switch (option) {
      case 'TriNet III – Passport':
        t = PassportGetDataList;
        return t;
      case 'TriNet II – SOI':
        t = SOIGetDataList;
        return t;
      case 'TriNet IV – Ambrose':
        t = AmbroseGetDataList;
        return t;
      case 'TriNet I – Accord':
        t = AccordGetDataList;
        return t;
      default:
        return Dummy;
    }
  }
  getDataListRevenueSideOnly = (option: string): Array<Selection> => {
    let t: Array<Selection>;
    switch (option) {
      case 'TriNet III – Passport':
        t = PassportGetDataListRevenueSideOnly;
        return t;
      case 'TriNet II – SOI':
        t = SOIGetDataListRevenueSideOnly;
        return t;
      case 'TriNet IV – Ambrose':
        t = AmbroseGetDataListRevenueSideOnly;
        return t;
      case 'TriNet I – Accord':
        t = AccordGetDataListRevenueSideOnly;
        return t;
      default:
        return t;
    }
  }
  getDataListClaimsOnly = (option: string): Array<Selection> => {
    let t: Array<Selection>;
    switch (option) {
      case 'TriNet III – Passport':
        t = PassportGetDataListClaimsOnly;
        return t;
      case 'TriNet II – SOI':
        t = SOIGetDataListClaimsOnly;
        return t;
      case 'TriNet IV – Ambrose':
        t = AmbroseGetDataListClaimsOnly;
        return t;
      case 'TriNet I – Accord':
        t = AccordGetDataListClaimsOnly;
        return t;
      default:
        return t;
    }
  }
  getDataIntegrityList = (option: string): Array<Selection> => {
    let t: Array<Selection>;
    switch (option) {
      case 'TriNet III – Passport':
        t = PassportDataIntegrityList;
        return t;
      case 'TriNet II – SOI':
        t = SOIDataIntegrityList;
        return t;
      case 'TriNet IV – Ambrose':
        t = AmbroseDataIntegrityList;
        return t;
      case 'TriNet I – Accord':
        t = AccordDataIntegrityList;
        return t;
      default:
        return t;
    }
  }
  getYesNo = (): Array<Selection> => YesNo;
  getCarveOutOptions = (): Array<Selection> => CarveOutOptions;
  getAscendingDescending = (): Array<Selection> => AscendingDescending;
  getMonths = (): Array<Selection> => Months;
  getYears = (): Array<Selection> => {
    const r: Array<Selection> = [];
    const list: number[] = [0, 1, 2, 3, 4, 5, 6, 7, 8];
    for (const i of list) {
      const obj: Selection = { value: i, label: String(Year - i) };
      r.push(obj);
    }
    return r;
  }
  getNumberToString = (v: number, n: number): string => {
    let s = '0000000000000000000' + v.toString();
    s = s.substr(s.length - n, n);
    return s;
  }
  getYearsHolderFds = (): string => {
    if (Month === 1 || Month === 2) {
      return String(Year - 1);
    } else {
      return String(Year);
    }
  }
  getYearsHolderSds = (): string => {
    if (Month === 1) {
      return String(Year - 1);
    } else {
      return String(Year);
    }
  }
  getMonthsHolderFds = (): string => {
    if (Month === 1) {
      return '11';
    } else {
      if (Month === 2) {
        return '12';
      } else {
        return String(Month - 2);
      }
    }
  }
  getMonthsHolderSds = (): string => {
    if (Month === 1) {
      return '12';
    } else {
      return String(Month - 1);
    }
  }
  getRouts = (): string[] => routs;
  getRout(r: string) {
    return routs.find(rout => rout.url === r);
  }
  getFormValue = (formValue: any, placeHolder: any, arrayAnys: any[], keyStr1: string, keyStr2: string): string => {
    if (typeof formValue === 'undefined' || formValue === null) {
      return placeHolder;
    } else {
      return arrayAnys.filter(arrayAny => arrayAny[keyStr1] === formValue)[0][keyStr2];
    }
  }
  getFormValueInput = (formValue: any, placeHolder: any, checkValue: any): any => {
    if (formValue === checkValue) {
      return placeHolder;
    } else {
      return formValue;
    }
  }
  getFormValueInputImproved = (formValue: any, returnValue: any): any => {
    return formValue || returnValue;
  }
  getServerPolicyFiscalYear = (rawValue: any) => {
    if (rawValue === 'Calendar year') {
      return 'FY';
    } else {
      return 'PY';
    }
  }
  getServerStateOption = (rawValue: any) => {
    if (rawValue === 'Benefit state') {
      return 'BnSt';
    } else {
      return 'AcSt';
    }
  }
  getServerAscendingDescending = (rawValue: any) => {
    if (rawValue === 'Ascending') {
      return 'asc';
    } else {
      return 'desc';
    }
  }
  setCache = (storagetype: string, storagename: string, value: any, valuetype: string) => {
    const t = valuetype.toLowerCase().trim();
    if (storagetype === 'sessionStorage' || storagetype === 'localStorage') {
      if (typeof (window[storagetype]) !== 'undefined') {
        // reseting forcefuly
        if (typeof (window[storagetype][storagename]) !== 'undefined') {
          window[storagetype].removeItem(storagename);
        }
        if (t === 'object' || t === 'array') {
          window[storagetype].setItem(storagename, JSON.stringify(value));
        } else {
          window[storagetype].setItem(storagename, value);
        }
      } else {
        return false;
      }
    }
  }
  getCache = (storagetype: string, storagename: string, valuetype: string) => {
    const t = valuetype.toLowerCase().trim();
    if (typeof (window[storagetype][storagename]) !== 'undefined') {
      if (t === 'object' || t === 'array') {
        return JSON.parse(window[storagetype][storagename]);
      } else {
        return window[storagetype][storagename];
      }
    } else {
      return false;
    }
  }
  getUserInfo(apipoint?: string, encrkey?: string, machine?: string): Observable<UserInfo> {
    const server: string = apipoint;
    // return this.http.get(server + 'api/MainAPI?user=' + machine + '&e=' + encrkey).map((r: Response) => r
    // ).catch((e: any) => Observable.throw(e.error || 'Server error'));
    return this.http.get(server + 'api/MainAPI?user=' + machine + '&e=' + encrkey).pipe(map((r: UserInfo) => {
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));

  }
  getJsonData(server: string, filename: string, action: string, type: string): Observable<any> {
    // console.log('!!!!!!!!!!!!!!!!!!!!!!!! INPUT !!!!!!!!!!!!!!!');
    // console.log(server);
    const serv = server.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, '').replace(/[^a-zA-Z]/g, '')
      .replace('http', '');
    const body: object = {
      filename,
      action,
      type,
      serv,
      location: ''
    };
    // console.log('!!!!!!!!!!!!!!!!!!!!!!!! SENT !!!!!!!!!!!!!!!');
    // console.log(body);
    return this.http.post(server + 'api/MainAPI?jsondata=jsondata', body).pipe(map((r: Response) => {
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));
  }
  getQueryName = (prefix?: string, sufix?: string, order?: number): string => {
    let p = '';
    let s = '';
    let o = '';
    if (isUndefined(prefix)) { p = ''; } else { p = prefix; }
    if (isUndefined(sufix)) { s = ''; } else { s = sufix; }
    if (isUndefined(order)) { o = ''; } else { o = order.toString(); }
    let endstr = '';
    const dt = new Date();
    endstr = (p + this.getCache('localStorage', 'user', 'object')['machine'] + dt.getDate().toString() + s
      + dt.getHours().toString() + o).toLocaleUpperCase();
    return endstr;
  }
  getQueryNameShort = (username?: string): string => {
    const arr = username.split(' ');
    let endstr = '';
    const dt = new Date();
    endstr = (arr[0].slice(0, 1) + arr[0].slice(-1) + arr[1].slice(0, 1) + arr[1].slice(-1) + dt.getDate().toString()
      + dt.getHours().toString()).toLocaleUpperCase();
    return endstr;
  }
  getQueryNameDaily = (prefix?: string, sufix?: string, order?: number): string => {
    let p = '';
    let s = '';
    let o = '';
    if (isUndefined(prefix)) { p = ''; } else { p = prefix; }
    if (isUndefined(sufix)) { s = ''; } else { s = sufix; }
    if (isUndefined(order)) { o = ''; } else { o = order.toString(); }
    let endstr = '';
    const dt = new Date();
    endstr = (p + this.getCache('localStorage', 'user', 'object')['machine'] + dt.getDate().toString() + s
      + o).toLocaleUpperCase();
    return endstr;
  }
  getQueryNameDailyHourMinute = (prefix?: string, sufix?: string, order?: number): string => {
    let p = '';
    let s = '';
    let o = '';
    if (isUndefined(prefix)) { p = ''; } else { p = prefix; }
    if (isUndefined(sufix)) { s = ''; } else { s = sufix; }
    if (isUndefined(order)) { o = ''; } else { o = order.toString(); }
    let endstr = '';
    const dt = new Date();
    endstr = (p + this.getCache('localStorage', 'user', 'object')['machine'] + dt.getDate().toString() + dt.getHours().toString()
      + dt.getMinutes().toString() + s
      + o).toLocaleUpperCase();
    return endstr;
  }
  getPass = (): string => {
    let r = this.getCache('localStorage', 'pass', 'string');
    r = r.trim().replace(/ /g, '');
    return r;
  }
  downloadFile = (uri: string, name: string): void => {
    const link = document.createElement('a');
    link.download = name;
    link.href = uri;
    link.click();
  }
  downloadFileObservable = (uri: string, name: string): Observable<any> => {
    return new Observable((observer: any) => {
      observer.next(
        (() => {
          const link = document.createElement('a');
          link.download = name;
          link.href = uri;
          link.setAttribute('download', name);
          link.style.display = 'none';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        })()
      );
    });
  }

  downloadFilesObservable = (fullpaths: string[], env: string, files_extensions: string[]): Observable<any> => {
    // console.log(fullpaths);
    // console.log(env);
    // console.log(files_extensions);
    return new Observable((observer: any) => {
      observer.next(
        ((f, e) => {
          function download_next(i) {
            if (i >= f.length) {
              return 'done';
            } else {
              const filename = f[i].slice(f[i].lastIndexOf('\\') + 1);
              const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
              const filenamefullpath = e + filename;
              if (files_extensions.includes(file_extension)) {
                const a = document.createElement('a');
                a.href = filenamefullpath;
                a.target = '_parent';
                // Use a.download if available, it prevents plugins from opening.
                if ('download' in a) {
                  a.download = filename;
                }
                // Add a to the doc for click to work.
                (document.body || document.documentElement).appendChild(a);
                if (a.click) {
                  a.click(); // The click method is supported by most browsers.
                }
                // Delete the temporary link.
                a.parentNode.removeChild(a);
                // Download the next file with a small timeout. The timeout is necessary
                // for IE, which will otherwise only download the first file.
                setTimeout(() => {
                  download_next(i + 1);
                  // return a;
                }, 1500);
              }
            }
          }
          // Initiate the first download.
          download_next(0);
        })(fullpaths, env)
      );
    });
  }
  download_files(files, env) {
    function download_next(i) {
      if (i >= files.length) {
        return;
      }
      const a = document.createElement('a');
      const filename = files[i].slice(files[i].lastIndexOf('\\') + 1);
      const filenamefullpath: string = env + filename;
      // // console.log(filenamefullpath);
      // // console.log(filename);
      a.href = filenamefullpath;
      a.target = '_parent';
      // Use a.download if available, it prevents plugins from opening.
      if ('download' in a) {
        a.download = filename;
      }
      // Add a to the doc for click to work.
      (document.body || document.documentElement).appendChild(a);
      if (a.click) {
        a.click(); // The click method is supported by most browsers.
      }
      // Delete the temporary link.
      a.parentNode.removeChild(a);
      // Download the next file with a small timeout. The timeout is necessary
      // for IE, which will otherwise only download the first file.
      setTimeout(() => {
        download_next(i + 1);
      }, 500);
    }
    // Initiate the first download.
    download_next(0);
  }
  downloadFilesFromSignalRService(fullpaths: string[], env: string, files_extensions: string[],
    cleanserver: boolean, server: string) {
    // console.log(fullpaths);
    this.downloadFilesObservable(fullpaths, env, files_extensions).subscribe(
      res1 => {
        ///////////////////////// Cleaning server and web folder
        for (let i = 0; i < fullpaths.length; i++) {
          if (fullpaths[i] !== null) {
            const filename = fullpaths[i].slice(fullpaths[i].lastIndexOf('\\') + 1);
            // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
            // const filenamefullpath = env + filename;
            let vv: CleanFileAndServer;
            if (i === 0) {
              vv = {
                fullfilename: fullpaths[i],
                qryname: 'none',
                c: ''
              };
            } else {
              vv = {
                fullfilename: fullpaths[i],
                qryname: 'none',
                c: ''
              };
            }
            if (cleanserver) {
              this.cleanFileServer(server, vv).subscribe(
                () => { }, err1 => { });
            }
          }
        }
        ///////////////////////// --------------- Cleaning all - web and oracle - END
      }, err => {
      });
  }
  getTimeFrame = (): string => {
    const d = new Date();
    return d.getUTCFullYear().toString() + '_' + (d.getUTCMonth() + 1).toString() + '_'
      + d.getDate().toString() + '_' + d.getHours().toString() + '_' + d.getMinutes().toString() + '_' + d.getSeconds().toString();
  }
  getTimeFrameForServer = (): string => {
    const d = new Date();
    return ('00' + d.getDate().toString()).slice(-2) + '-' +
      ('00' + (d.getUTCMonth() + 1).toString()).slice(-2) + '-' +
      d.getUTCFullYear().toString() + ' ' +
      ('00' + d.getHours().toString()).slice(-2) + ':' +
      ('00' + d.getMinutes().toString()).slice(-2) + ':' +
      ('00' + d.getSeconds().toString()).slice(-2);
  }
  getMainTimeFrame = (): string => {
    const d = new Date();
    return ('0' + (d.getUTCDate()).toString()).substr(-2, 2) + '_'
      + ('0' + (d.getUTCMonth() + 1).toString()).substr(-2, 2) + '_' + d.getUTCFullYear().toString();
  }
  getTimeFrameShort = (): string => {
    const d = new Date();
    return + d.getMinutes().toString() + d.getSeconds().toString();
  }
  // tslint:disable-next-line:ban-types
  addUniqueObjectToArray = (arr: any[], obj: Object) => {
    let add = true;
    arr.forEach(x => {
      if (this.isObjectEquivalent(x, obj)) {
        add = false;
      }
    });
    if (add) { return arr.push(obj); } else { return arr; }
  }
  // tslint:disable-next-line:ban-types
  isObjectEquivalent = (a: Object, b: Object) => {
    const aProps = Object.getOwnPropertyNames(a);
    const bProps = Object.getOwnPropertyNames(b);
    if (aProps.length !== bProps.length) {
      return false;
    }
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < aProps.length; i++) {
      const propName = aProps[i];
      if (a[propName] !== b[propName]) {
        return false;
      }
    }
    return true;
  }
  numberToRgb = (c: number) => {
    const b = c % 256;

    const g_0 = (c % 65536 - b);

    const r_0 = c - g_0 - b;
    const g = g_0 / 256;
    const r = r_0 / 65536;
    return [r, g, b];
  }
  decimalColorToHTMLcolor(n: number) {
    // converts to a integer
    let intnumber = n - 0;
    // isolate the colors - really not necessary
    // tslint:disable-next-line:one-variable-per-declaration
    let red, green, blue;
    // needed since toString does not zero fill on left
    const template = '#000000';
    // in the MS Windows world RGB colors
    // are 0xBBGGRR because of the way Intel chips store bytes
    // tslint:disable-next-line:no-bitwise
    red = (intnumber & 0x0000ff) << 16;
    // tslint:disable-next-line:no-bitwise
    green = intnumber & 0x00ff00;
    // tslint:disable-next-line:no-bitwise
    blue = (intnumber & 0xff0000) >>> 16;
    // mask out each color and reverse the order
    // tslint:disable-next-line:no-bitwise
    intnumber = red | green | blue;
    // toString converts a number to a hexstring
    let HTMLcolor = intnumber.toString(16);
    // template adds # for standard HTML #RRGGBB
    HTMLcolor = template.substring(0, 7 - HTMLcolor.length) + HTMLcolor;
    return HTMLcolor;
  }
  getDateStringFormat(): string {
    const d = new Date();
    return ('00' + (d.getMonth() + 1)).slice(-2) + '/' + ('00' + d.getDate()).slice(-2) + '/' + d.getFullYear();
  }
  navigateToModuleService(routstring: string, usermodule: string, useraccess: UsersNavigationDataLoad): void {
    // // console.log(routstring);
    // // console.log(usermodule);
    // // console.log(useraccess);
    if (routstring === 'user') {
      this.route.navigateByUrl('/user');
    } else {
      if (routstring !== 'actuarial') {
        if (routstring !== 'health') {
          if (usermodule === 'risk' || usermodule === 'actuarial') {
            this.route.navigateByUrl('/' + routstring);
          } else {
            if (routstring === usermodule) {
              this.route.navigateByUrl('/' + routstring);
            } else {
              this.route.navigateByUrl('/' + usermodule);
            }
          }
        } else {
          if (usermodule === 'actuarial') {
            this.route.navigateByUrl('/' + routstring);
          } else {
            if (routstring === usermodule) {
              this.route.navigateByUrl('/' + routstring);
            } else {
              this.route.navigateByUrl('/' + usermodule);
            }
          }
        }
      } else {
        if (usermodule === 'actuarial') {
          this.route.navigateByUrl('/' + routstring);
        } else {
          this.route.navigateByUrl('/' + usermodule);
        }
      }
    }
  }
  getDateFromHTMLInput(dt: string): string {
    if (dt === '') {
      return this.getDateStringFormat();
    } else {
      const dtarr: string[] = dt.split('-');
      return dtarr[1] + '/' + dtarr[2] + '/' + dtarr[0];
    }
  }
  getLastDay(yr: number, mm: number): number {
    // zero base months instead of mm+1 pass 0 - 11
    return new Date(+(new Date(yr, mm + 1, 1)) - 1).getDate();
  }
  monthDiff(dateFrom: Date, dateTo: Date): number {
    return dateTo.getMonth() - dateFrom.getMonth() + (12 * (dateTo.getFullYear() - dateFrom.getFullYear()));
  }
  checkIfCanUseLoading(u: UserInfo): boolean {
    // console.log('Loading - ' + u.name);
    if (u.name === 'Lyudmil Petrov' || u.name === 'Wanda Woods'
      || u.name === 'Lolita Komisar' || u.name === 'Breen Bohn'
      || u.name === 'James McMorran' || u.name === 'Jessica Villasenor'
      || u.name === 'Jessica Villasenor' || u.module.toLocaleLowerCase() === 'actuarial'
    ) {
      return true;
    } else {
      return false;
    }
  }
  getDateForCalendarString(yr: number, mm: number, mmsback: number, option: string): Date {
    let dd = 1;
    // if (option === 'end') {
    //   dd = this.getLastDay(yr, mm);
    // }
    // // console.log(dd);
    const d = new Date(yr, mm, dd);
    d.setMonth(d.getMonth() + mmsback);
    if (option === 'end') {
      dd = this.getLastDay(d.getFullYear(), d.getMonth());
    }
    const df = new Date(d.getFullYear(), d.getMonth(), dd);
    return df;
  }
}
@Injectable()
export class GlobalVariables {
  // tslint:disable-next-line:ban-types
  public env: Object = {
    api: {
      test: 'http://localhost:63009/',
      test_latest: 'http://localhost:63009/',
      test_core: 'https://localhost:44387/',
      dev: 'http://brspwferiskd1.ad.corp.local/',
      pro: 'http://brspwferiskd1.ad.corp.local/',
      pro_sas: 'http://ausasmid01.ad.corp.local:99/',
      api: ''
    },
    excelfilesave: {
      test: 'H:\\Source\\riskapiservices_v_3\\riskapiservices_latest\\excel\\',
      test_latest: 'C:\\Users\\lpetrov\\source\\repos\\riskapiservices_v_2\\riskapiservices_v_2\\excel\\',
      dev: '\\\\brspwferiskd1.ad.corp.local\\RiskFinance\\excel\\',
      pro: '\\\\brspwferiskd1.ad.corp.local\\RiskFinance\\excel\\',
      pro_sas: '\\\\ausasmid01.ad.corp.local\\WebApps\\Actuarial\\excel\\',
      excelfilesave: ''
    },
    excelfiledownload: {
      test: 'http://localhost:63009/excel/',
      test_latest: 'http://localhost:63009/excel/',
      test_core: 'https://localhost:44387/excel/',
      dev: 'http://brspwferiskd1.ad.corp.local/excel/',
      pro: 'http://brspwferiskd1.ad.corp.local/excel/',
      pro_sas: 'http://ausasmid01.ad.corp.local:99/excel/',
      excelfilesave: ''
    },
    wccaseprecreatedexcelfiledownload: {
      test: 'http://localhost:63009/wc/files/',
      test_latest: 'http://localhost:63009/wc/files/',
      test_core: 'https://localhost:44387/wc/files/',
      dev: 'http://brspwferiskd1.ad.corp.local/wc/files/',
      pro: 'http://brspwferiskd1.ad.corp.local/wc/files/',
      pro_sas: 'http://ausasmid01.ad.corp.local:99/excel/',
      excelfilesave: ''
    },
    image: {
      test: 'assets/images/',
      test_latest: 'assets/images/',
      test_core: 'assets/images/',
      dev: 'assets/images/',
      pro: 'assets/images/',
      pro_sas: 'assets/images/',
      image: ''
    },
    map: {
      test: '../assets/',
      test_latest: '../assets/',
      test_core: '../assets/',
      dev: 'http://brspwferiskd1.ad.corp.local/excel/',
      pro: 'http://brspwferiskd1.ad.corp.local/excel/',
      pro_sas: 'http://ausasmid01.ad.corp.local:99/excel/',
      map: ''
    },
    shortnames: {
      imagelogo: 'trinet_wingmark.png',
      imageearthspin: 'earth0.gif',
      imageearthstop: 'earth0.png'
    }
  };
  get(keylevel0: string, keylevel1: string) {
    const r = this.env[keylevel0][keylevel1];
    return r;
  }

  getenv(): string { return this.env['main']; }
  setenv(value: string): void {

    this.env['main'] = value;
  }
  setall(): void {
    const _env: string = this.getenv();
    // // console.log('?????????????????????????????????????????');
    // // console.log(_env);
    // // console.log('?????????????????????????????????????????');
    const _api: string = this.env['api'][_env];
    // // console.log('?????????????????????????????????????????');
    // // console.log(_api);
    // // console.log('?????????????????????????????????????????');

    const _excelfilesave: string = this.env['excelfilesave'][_env];
    const _excelfiledownload: string = this.env['excelfiledownload'][_env];
    const _image: string = this.env['image'][_env];
    const _map: string = this.env['map'][_env];
    this.env['api']['api'] = _api;
    this.env['excelfilesave']['excelfilesave'] = _excelfilesave;
    this.env['excelfiledownload']['excelfiledownload'] = _excelfiledownload;
    this.env['image']['image'] = _image;
    this.env['map']['map'] = _map;
  }
}
@Injectable()
export class GlobalObservables {
  private subject = new Subject<any>();
  exchangeInfo: VizIncomingInitialInfo = {
    Product: '',
    InfoToPresent: '',
    ID: '',
    StartDate: '',
    EndDate: '',
    Option1: '',
    Option2: '',
    Source: '',
    qryname: '',
    username: '',
    c: '',
    env: '',
    transportedinfo: ['']
  };
  private exchangeInfoInit = new BehaviorSubject<VizIncomingInitialInfo>(this.exchangeInfo);
  currentExchangeInfo = this.exchangeInfoInit.asObservable();
  constructor(@Optional() @SkipSelf() parentModule: GlobalObservables, private http: HttpClient) { }
  changeExchangeInfo(e: VizIncomingInitialInfo) {
    this.exchangeInfo = e;
    this.exchangeInfoInit.next(this.exchangeInfo);
  }
  sendMessage(message: any) {
    this.subject.next(message);
  }
  clearMessage() {
    this.subject.next();
  }
  getMessage(): Observable<any> {
    return this.subject.asObservable();
  }
}
