import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name: 'CurrencyPipe'
    , pure: false
})
export class CurrencyPipe implements PipeTransform {
    transform(value: number, trigger: number): number {
        // // console.log('32323');
        return value * value;
    }
}
