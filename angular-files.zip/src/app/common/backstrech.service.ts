import { Injectable } from '@angular/core';
declare let $: any;
@Injectable()
export class BackstretchService {
    strech(imageurl: string) {
         $['backstretch'](imageurl);
    }
}
