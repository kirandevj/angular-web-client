
/// <reference lib="webworker" />
addEventListener('message', ({ data }) => {
  const response = `worker response to ${data}`;
  const m: WebWorkerData = data;
  postMessage(m.id + 2);
});
onmessage = (e: MessageEvent) => {
  handleMessage(e.data);
};
const handleMessage = (msg: WebWorkerData) => {
  // console.log(msg);
  postMessage(msg.id);
  // switch (msg.action) {
  //   case: 'called'
  //     // console.log(msg);
  //     // db.get(payload.docId) // get the doc id from the msg
  //     //   .then(doc => postMessage({
  //     //     id, // put the same msg id back into the response
  //     //     document: doc // result
  //     //   }))
  //     postMessage({}))
  //     break;
  // }
};
export interface WebWorkerData {
  id: number;
  action: string;
  data: object;
}



// function fibonacci(n: UserInfo): number {
//   let r = 0;
//   if (n === 1 || n === 2) {
//     r = 1;
//   } else {
//     r = fibonacci(n - 1) + fibonacci(n - 2);
//     // // console.log(r);
//   }
//   return r;
// }
