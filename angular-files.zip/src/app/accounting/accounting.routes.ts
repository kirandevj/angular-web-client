import { AccountingComponent } from './accounting.component';
import { WCCSRComponent } from './wccsr/wccsr.component';
import { GetDataComponent } from './getdata/getdata.component';
import { WagesReportingComponent } from './wagesreporting/wages-reporting.component';
import { MonthlyVarianceComponent } from './monthlyvariance/monthly-variance.component';

export const AccountingRoutes = [
    { path: '', component: AccountingComponent },
    { path: 'wccsr', component: WCCSRComponent },
    { path: 'getdata', component: GetDataComponent },
    { path: 'wagesreporting', component: WagesReportingComponent },
    { path: 'monthlyvariance', component: MonthlyVarianceComponent }
];
