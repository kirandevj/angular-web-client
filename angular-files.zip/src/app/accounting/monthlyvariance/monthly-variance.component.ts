import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { RiskFinanceServices } from '../../riskfinance/shared/risk-finance.service';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { Selection, MonthlyVariance, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { LocalVariables, RunProcess } from '../shared/local.variables';

@Component({
  // encapsulation: ViewEncapsulation.None,
  templateUrl: './monthly-variance.html',
  styles: [`
  form {
    /* color: #0000ff;
    font-size: 14px;
    line-height: 1.42857143;
    background-color: #9999ff;
    background-image: none;
    */
    display: block;
    padding: 12px 12px;
    border: 4px solid #8080ff;
    border-radius: 10px;
  }
  `]
})
export class MonthlyVarianceComponent implements OnInit {
  user: UserInfo;
  sendtofooter: FooterInfo;
  form: FormGroup;
  Products: Array<Selection>;
  Yearsfds: Array<Selection>;
  Yearssds: Array<Selection>;
  Monthsfds: Array<Selection>;
  Monthssds: Array<Selection>;
  yesnos: Array<Selection>;
  PlaceholderProduct: string;
  PlaceholderYearsfds: string;
  PlaceholderYearssds: string;
  PlaceholderMonthsfds: string;
  PlaceholderMonthssds: string;
  Placeholderyesnos: string;
  filenamesummary: string;
  filenamerawdata: string;
  server: string;
  image0: string;
  image1: string;
  reportsInfo: boolean;
  ReportsArray: Array<RunProcess>;
  variablesHome: string;
  constructor(private rfs: RiskFinanceServices, private ss: SharedServices,
    private gv: GlobalVariables, private route: ActivatedRoute, private lv: LocalVariables) { }

  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.variablesHome = 'monthlyvariance';
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.form.addControl('Product', new FormControl());
    this.form.addControl('Yearfds', new FormControl());
    this.form.addControl('Monthfds', new FormControl());
    this.form.addControl('Yearsds', new FormControl());
    this.form.addControl('Monthsds', new FormControl());
    this.form.addControl('yesno', new FormControl());
    this.yesnos = this.ss.getYesNo();
    this.Products = this.ss.getProducts();
    this.Yearsfds = this.ss.getYears();
    this.Yearssds = this.Yearsfds;
    this.Monthsfds = this.ss.getMonths();
    this.Monthssds = this.Monthsfds;
    this.PlaceholderProduct = this.Products[0].label;
    this.PlaceholderYearsfds = this.ss.getYearsHolderFds();
    this.PlaceholderYearssds = this.ss.getYearsHolderSds();
    this.PlaceholderMonthsfds = this.ss.getMonthsHolderFds();
    this.PlaceholderMonthssds = this.ss.getMonthsHolderSds();
    this.Placeholderyesnos = this.yesnos[1].label;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  onSubmit(formValues: any) {
    const rr: MonthlyVariance = {
      product: this.ss.getFormValue(formValues.Product, this.PlaceholderProduct, this.Products, 'value', 'label')
        .replace(/–/g, '').replace(/\s+/g, '_'),
      qryname: this.ss.getQueryName('M', 'V', +this.ReportsArray.length + 1),
      fdsyr: +this.ss.getFormValue(formValues.Yearfds, this.PlaceholderYearsfds, this.Yearsfds, 'value', 'label'),
      sdsyr: +this.ss.getFormValue(formValues.Yearsds, this.PlaceholderYearssds, this.Yearssds, 'value', 'label'),
      fdsmm: +this.ss.getFormValue(formValues.Monthfds, this.PlaceholderMonthsfds, this.Monthsfds, 'value', 'label'),
      sdsmm: +this.ss.getFormValue(formValues.Monthsds, this.PlaceholderMonthssds, this.Monthssds, 'value', 'label'),
      c: this.ss.getPass(),
      username: this.user.name,
      fingerprint: '',
      filenamesummary: '',
      filenamerawdata: '',
      filenamesummaryshort: '',
      filenamerawdatashort: '',
      imageprocess: this.image1,
      timeframe: this.ss.getTimeFrame(),
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      includerawdata: this.ss.getFormValue(formValues.yesno, this.Placeholderyesnos, this.yesnos, 'value', 'label')
    };
    rr.fingerprint = rr.product + rr.fdsyr.toString() + rr.sdsyr.toString() + rr.fdsmm.toString() + rr.sdsmm.toString();
    rr.filenamesummaryshort = rr.product + '_MV_' + this.ss.getNumberToString(rr.fdsmm, 2) +
      '_' + rr.fdsyr.toString() + '_vs_' + this.ss.getNumberToString(rr.sdsmm, 2) + '_' + rr.sdsyr.toString() + '_'
      + this.user.name.replace(' ', '_') + '.xlsx';
    rr.filenamerawdatashort = rr.filenamesummaryshort.replace('.xlsx', '_Raw.xlsx');
    rr.filenamesummary = rr.env + rr.filenamesummaryshort;
    rr.filenamerawdata = rr.env + rr.filenamerawdatashort;
    const p: RunProcess = {
      name: rr.filenamesummaryshort,
      run: true,
      object: rr
    };
    this.lv.add(this.variablesHome, p, rr.fingerprint);
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  runReport(r: MonthlyVariance) {
    this.ReportsArray.forEach((e: RunProcess, i: number) => {
      if (e.object.fingerprint === r.fingerprint) {
        e.object.imageprocess = e.object.imageprocess.replace('.png', '.gif');
        this.getRiskMonthlyVariance(e.object);
      }
    });
  }
  deleteReport(r: MonthlyVariance) {
    this.lv.remove(this.variablesHome, r.fingerprint);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  getRiskMonthlyVariance(v: MonthlyVariance) {
    this.rfs.getRiskMonthlyVariance(this.server, v)
      .subscribe(
        res => {
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
              // --------------- Cleaning all - web and oracle - START
              for (let i = 0; i < res.length; i++) {
                if (res[i] !== null) {
                  /////////////////////////// Cleaning server and web folder
                  const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                  // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
                  // const filenamefullpath = env + filename;
                  let vv: CleanFileAndServer;
                  if (i === 0) {
                    vv = {
                      fullfilename: res[i],
                      qryname: v.qryname,
                      c: v.c
                    };
                  } else {
                    vv = {
                      fullfilename: res[i],
                      qryname: 'none',
                      c: v.c
                    };
                  }
                  // // console.log(vv);
                  this.ss.cleanFileServer(this.server, vv).subscribe(
                    () => { }, err1 => { });
                }
              }
              // --------------- Cleaning all - web and oracle - END
            }, err => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
            });
        },
        err => { });
  }
  getStyle() {
    return '{background-color: #CEC7CE}';
  }
}
