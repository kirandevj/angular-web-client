import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SelectModule } from 'angular2-select';
import { AccNavBarComponent } from './nav/acc-navbar.component';
import { AccountingComponent } from './accounting.component';
import { WCCSRComponent } from './wccsr/wccsr.component';
import { WagesReportingComponent } from './wagesreporting/wages-reporting.component';
import { WagesReportingServices } from './wagesreporting/wages-reporting.services';
import { MonthlyVarianceComponent } from './monthlyvariance/monthly-variance.component';
import { AccountingRoutes } from './accounting.routes';
import { AccountingServices } from './shared/accounting.services';
import { ApiServices } from '@app/common/index';
import { GetDataComponent } from './getdata/getdata.component';
import { LocalVariables } from './shared/local.variables';
import { FooterModule } from '@app/common/index';
import { SpinnerModule } from '@app/common/index';
import { SharedServices } from '@app/common/index';
import { RiskFinanceServices } from '../riskfinance/shared/risk-finance.service';
@NgModule({
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(AccountingRoutes),
    SelectModule,
    FooterModule,
    SpinnerModule
  ],
  declarations: [
    AccNavBarComponent,
    AccountingComponent,
    WCCSRComponent,
    WagesReportingComponent,
    GetDataComponent,
    MonthlyVarianceComponent
  ],
  providers: [
    AccountingServices,
    ApiServices,
    LocalVariables,
    WagesReportingServices,
    SharedServices,
    RiskFinanceServices
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AccountingModule {
  // selectedPro(): any {
  // }
}
