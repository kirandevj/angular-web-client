import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedServices, GlobalVariables, ApiServices } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { Selection, UserInfo, FooterInfo, CleanFileAndServer, WccsrSlim } from '@app/datamodels/index';


@Component({
  // encapsulation: ViewEncapsulation.None,
  templateUrl: './wccsr.html',
  styleUrls: ['./wccsr.component.css']
})
export class WCCSRComponent implements OnInit {
  user: UserInfo;
  sendtofooter: FooterInfo;
  showspinner: boolean;
  form: FormGroup;
  Products: Array<Selection>;
  Years: Array<Selection>;
  Months: Array<Selection>;
  yesnos: Array<Selection>;
  ascdesc: Array<Selection>;
  ClaimsGrouping: Array<Selection>;
  PlaceholderProducts: string;
  PlaceholderYears: string;
  PlaceholderMonths: string;
  Placeholderyesnos: string;
  Placeholderascdesc: string;
  PlaceholderClaimsGrouping: string;
  image0: string;
  image1: string;
  server: string;
  loadingImage: boolean;
  constructor(private api: ApiServices, private ss: SharedServices, private gv: GlobalVariables, private route: ActivatedRoute) { }

  ngOnInit() {
    this.showspinner = false;
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.loadingImage = true;
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.form.addControl('Product', new FormControl());
    this.form.addControl('Year', new FormControl());
    this.form.addControl('Month', new FormControl());
    this.form.addControl('ClaimsGrouping', new FormControl());
    this.form.addControl('YearsOrder', new FormControl());
    this.Products = this.ss.getProductsAll();
    this.Years = this.ss.getYears();
    this.Months = this.ss.getMonths();
    this.yesnos = this.ss.getYesNo();
    this.ascdesc = this.ss.getAscendingDescending();
    this.ClaimsGrouping = this.ss.getClaimsAmountsStructure();

    this.PlaceholderProducts = this.Products[0].label;
    this.PlaceholderYears = this.ss.getYearsHolderSds();
    this.PlaceholderMonths = this.ss.getMonthsHolderSds();
    this.Placeholderyesnos = this.yesnos[1].label;
    this.Placeholderascdesc = this.ascdesc[0].label;
    this.PlaceholderClaimsGrouping = this.ClaimsGrouping[0].label;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - Acounting WCCSR issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
  }
  onSubmit(formValues: any) {
    if (!this.showspinner) {
      this.showspinner = true;
      const wccsrSlim: WccsrSlim = {
        username: this.user.name,
        Product: this.ss.getFormValue(formValues.Product, this.PlaceholderProducts, this.Products, 'value', 'label')
          .replace(/–/g, '').replace(/\s+/g, '_'),
        qryName: this.ss.getQueryName('W', 'C', 1),
        AsOfYr: +this.ss.getFormValue(formValues.Year, this.PlaceholderYears, this.Years, 'value', 'label'),
        AsOfMm: +this.ss.getFormValue(formValues.Month, this.PlaceholderMonths, this.Months, 'value', 'label'),
        ClaimsGrouping: this.ss.getFormValue(formValues.ClaimsGrouping, this.PlaceholderClaimsGrouping,
          this.ClaimsGrouping, 'value', 'label'),
        YearsOrder: this.ss.getFormValue(formValues.YearsOrder, this.Placeholderascdesc, this.ascdesc, 'value', 'label'),
        StatesOpt: 'ACCIDENTSTATE',
        env: this.gv.get('excelfilesave', 'excelfilesave'),
        c: this.ss.getPass(),
        filenameshort: ''
      };
      wccsrSlim.filenameshort = wccsrSlim.Product + '_WCCSR_Slim_'
        + this.user.name.replace(' ', '_') + '.xlsx';
      this.getWCCSRSlim(wccsrSlim);
      // // console.log(wccsrSlim);
    }
  }
  getWCCSRSlim(v: WccsrSlim) {
    this.api.API_POST_Observable(this.server, v, 'api/Accounting?getwccsrslim=getwccsrslim')
      .subscribe(
        res => {
          // // console.log(res);
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              this.showspinner = false;
              // --------------- Cleaning all - web and oracle - START
              for (let i = 0; i < res.length; i++) {
                if (res[i] !== null) {
                  /////////////////////////// Cleaning server and web folder
                  const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                  let vv: CleanFileAndServer;
                  if (i === 0) {
                    vv = {
                      fullfilename: res[i],
                      qryname: v.qryName,
                      c: v.c
                    };
                  } else {
                    vv = {
                      fullfilename: res[i],
                      qryname: 'none',
                      c: 'none'
                    };
                  }
                  this.ss.cleanFileServer(this.server, vv).subscribe(
                    () => { }, err1 => { });
                }
              }
              // --------------- Cleaning all - web and oracle - END
            }, err => {
              this.showspinner = false;
            });
          // for (let i = 0; i < res1['length']; i++) {
          //   if (res1[i] !== null) {
          //     const filenameshort = res1[i].slice(res1[i].lastIndexOf('\\') + 1);
          //     const downloadfolder: string = this.gv.get('excelfiledownload', 'excelfiledownload') + filenameshort;
          //     this.ss.downloadFileObservable(downloadfolder, filenameshort)
          //       .subscribe(
          //         res2 => {
          //           const justfile: Object = { fullfilename: res1[i] };
          //           this.ss.cleanJustFile(this.server, justfile)
          //             .subscribe(
          //               () => { }, err => { });
          //         }, err => {
          //           const justfile: Object = { fullfilename: res1[i] };
          //           this.ss.cleanJustFile(this.server, justfile)
          //             .subscribe(
          //               () => { }, err1 => { });
          //         });
          //     const v12: CleanFileAndServer = {
          //       fullfilename: res1[i],
          //       qryname: v['qryName'] + i,
          //       c: v['c']
          //     };
          //     this.ss.cleanFileServer(this.server, v12).subscribe(() => { }, err1 => { });
          //   }
          // }
          // // --------------- Cleaning server tables
          // const v22: CleanFileAndServer = {
          //   fullfilename: 'none',
          //   qryname: v['qryName'],
          //   c: v['c']
          // };
          // // // console.log(v22);
          // this.ss.cleanFileServer(this.server, v22).subscribe(() => { }, err1 => { });
          // this.showspinner = false;
        }, err => {
          this.showspinner = false;
        });
  }
}
