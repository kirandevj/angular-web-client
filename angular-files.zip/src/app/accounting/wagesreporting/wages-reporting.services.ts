import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
// Import RxJs required methods
import { map, filter, scan, catchError, mergeMap } from 'rxjs/operators';

import { WagesReporting } from '@app/datamodels/index';
@Injectable()
export class WagesReportingServices {
  constructor(private http: HttpClient) { }
  getWagesReporting(api: string, v: WagesReporting): Observable<string> {
    // return this.http.post(api + 'api/MainAPI?riskMonthlyVariance=riskMonthlyVariance', v).map((r: Response) => r
    // ).catch((e: any) => Observable.throw(e.error || 'Server error'));
    return this.http.post(api + 'api/MainAPI?riskMonthlyVariance=riskMonthlyVariance', v).pipe(map((r: string) => {
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));
  }

}




