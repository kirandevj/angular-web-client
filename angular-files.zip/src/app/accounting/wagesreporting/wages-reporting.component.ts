import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { WagesReporting, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { LocalVariables, RunProcess } from '../shared/local.variables';
import { FooterComponent } from '@app/common/index';
import { WagesReportingServices } from './wages-reporting.services';

@Component({
  templateUrl: './wages-reporting.html',
  styleUrls: ['./wages-reporting.component.css']
})
export class WagesReportingComponent implements OnInit {
  user: UserInfo;
  sendtofooter: FooterInfo;
  form: FormGroup;
  Products: Array<Selection>;
  Years: Array<Selection>;
  Months: Array<Selection>;
  yesnos: Array<Selection>;
  MonthBack: number;
  ID: string;
  PlaceholderProducts: string;
  PlaceholderYears: string;
  PlaceholderMonths: string;
  Placeholderyesnos: string;
  PlaceholderMonthBack: number;
  PlaceholderID: string;
  server: string;
  image0: string;
  image1: string;
  reportsInfo: boolean;
  ReportsArray: Array<RunProcess>;
  variablesHome: string;
  adminonly = false;
  constructor(private ss: SharedServices,
    private gv: GlobalVariables,
    private route: ActivatedRoute,
    private lv: LocalVariables,
    private wrs: WagesReportingServices) { }

  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.variablesHome = 'wagesreporting';
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.form.addControl('Product', new FormControl());
    this.form.addControl('Year', new FormControl());
    this.form.addControl('Month', new FormControl());
    this.form.addControl('yesno', new FormControl());
    this.form.addControl('MonthBack', new FormControl());
    this.form.addControl('ID', new FormControl());
    this.PlaceholderID = 'Enter ID here';
    this.Products = this.ss.getProductsAll();
    this.Years = this.ss.getYears();
    this.Months = this.ss.getMonths();
    this.yesnos = this.ss.getYesNo();
    this.MonthBack = 1;
    this.PlaceholderProducts = this.Products[0].label;
    this.PlaceholderYears = this.ss.getYearsHolderSds();
    this.PlaceholderMonths = this.ss.getMonthsHolderSds();
    this.Placeholderyesnos = this.yesnos[0].label;
    this.PlaceholderMonthBack = this.MonthBack;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
    if (this.user.rights === 'admin') {
      this.adminonly = true;
    }
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - Accounting wages reporting issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
  }
  onSubmit(formValues: any) {
    const rr: WagesReporting = {
      username: this.user.name,
      reportname: 'wagesreporting',
      product: this.ss.getFormValue(formValues.Product, this.PlaceholderProducts, this.Products, 'value', 'label')
        .replace(/–/g, '').replace(/\s+/g, '_'),
      qryname: this.ss.getQueryName('W', 'R', +this.ReportsArray.length + 1),
      asofyr: +this.ss.getFormValue(formValues.Year, this.PlaceholderYears, this.Years, 'value', 'label'),
      asofmm: +this.ss.getFormValue(formValues.Month, this.PlaceholderMonths, this.Months, 'value', 'label'),
      mmsback: +this.ss.getFormValueInputImproved(document.getElementById('mb')['value'], this.PlaceholderMonthBack),
      id: (this.ss.getFormValueInputImproved(document.getElementById('idn')['value'], '')).toLocaleUpperCase(),
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      c: this.ss.getPass(),
      overwritedepository: this.ss.getFormValue(formValues.yesnos, this.Placeholderyesnos, this.yesnos, 'value', 'label'),
      fingerprint: '',
      imageprocess: this.image1
    };
    rr.fingerprint = rr.mmsback.toString() + rr.asofyr.toString() + rr.asofmm.toString() + rr.product + rr.mmsback + rr.id;
    rr.filenameshort = 'Array of files covering above options will be downloaded here process indicator - '
      + (+this.ReportsArray.length + 1);
    const p: RunProcess = {
      name: rr.filenameshort,
      run: true,
      object: rr
    };
    this.lv.add(this.variablesHome, p, rr.fingerprint);
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  runReport(r: WagesReporting) {
    this.ReportsArray.forEach((e: RunProcess, i: number) => {
      if (e.object.fingerprint === r.fingerprint) {
        e.object.imageprocess = e.object.imageprocess.replace('.png', '.gif');
        this.getRiskLossRatio(e.object);
      }
    });
  }
  deleteReport(r: WagesReporting) {
    this.lv.remove(this.variablesHome, r.fingerprint);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  getRiskLossRatio(v: WagesReporting) {
    // // console.log(v);
    this.wrs.getWagesReporting(this.server, v)
      .subscribe(
        res => {
          // // console.log(res);
          for (let i = 0; i < res['length']; i++) {
            if (res[i] !== null) {
              const filenameshort = res[i].slice(res[i].lastIndexOf('\\') + 1);
              const downloadfolder: string = this.gv.get('excelfiledownload', 'excelfiledownload') + filenameshort;
              this.ss.downloadFileObservable(downloadfolder, filenameshort)
                .subscribe(
                  res2 => {
                    this.lv.remove(this.variablesHome, v.fingerprint);
                    this.ReportsArray = this.lv.get(this.variablesHome);
                    if (this.ReportsArray.length === 0) {
                      this.reportsInfo = true;
                    }
                    const justfile: object = { fullfilename: res[i] };
                    this.ss.cleanJustFile(this.server, justfile)
                      .subscribe(
                        () => { }, err => { });
                  }, err => {
                    const justfile: object = { fullfilename: res[i] };
                    this.ss.cleanJustFile(this.server, justfile)
                      .subscribe(
                        () => { }, err1 => { });
                  });
            }
          }
          // --------------- Cleaning server tables
          const v2: CleanFileAndServer = {
            fullfilename: v.filename,
            qryname: v.qryname,
            c: v.c
          };
          this.ss.cleanFileServer(this.server, v2)
            .subscribe(
              () => {
              }, err1 => {
              });
          if (this.ReportsArray.length !== 0) {
            this.reportsInfo = false;
          } else {
            this.reportsInfo = true;
          }
          if (res === 't') {
            const downloadfolder: string = this.gv.get('excelfiledownload', 'excelfiledownload') + v.filenameshort;
            this.ss.downloadFileObservable(downloadfolder, v.filenameshort)
              .subscribe(
              res2 => {
                this.lv.remove(this.variablesHome, v.fingerprint);
                if (this.ReportsArray.length === 0) {
                  this.reportsInfo = true;
                }
                const v3: CleanFileAndServer = {
                  fullfilename: v.filename,
                  qryname: v.qryname,
                  c: v.c
                };
                this.ss.cleanFileServer(this.server, v2)
                  .subscribe(
                  () => { }, err => { });
              }, err => {
                const v3: CleanFileAndServer = {
                  fullfilename: v.filename,
                  qryname: v.qryname,
                  c: v.c
                };
                this.ss.cleanFileServer(this.server, v2)
                  .subscribe(
                  () => { }, err1 => { });
                this.lv.remove(this.variablesHome, v.fingerprint);
                if (this.ReportsArray.length === 0) {
                  this.reportsInfo = true;
                }
              });
          }
        }, err => {
          const v2: CleanFileAndServer = {
            fullfilename: v.filename,
            qryname: v.qryname,
            c: v.c
          };
          this.ss.cleanFileServer(this.server, v2)
            .subscribe(
              () => { }, err1 => { });
        });
  }
}
