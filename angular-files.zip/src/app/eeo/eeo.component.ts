import { ChangeDetectionStrategy, Component, NgModule, ViewEncapsulation, OnInit, ElementRef, ViewChild, Input } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { HttpClient, HttpRequest } from '@angular/common/http';
import { UserInfo, FooterInfo, Selection } from '@app/datamodels/index';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { Observable } from 'rxjs';
import { BehaviorSubject } from 'rxjs';
// import {}
import { map, filter, scan, catchError, mergeMap } from 'rxjs/operators';
import { ChannelService, ConnectionState, ChannelEvent } from '../services/channel.sevice';
// import { ChartBaseComponent } from '../components/chart/chart-base/chart-base.component';
class StatusEvent {
  State: string;
  PercentComplete: number;
}
declare const $: any;
declare const moment: any;
declare const System: any;
declare function escape(s: string): string;
// const parser = require('xml2json');
// System.import('/assets/js/regular-expresions.js').then(file => {
//   // perform additional interactions after the resource has been asynchronously fetched
// });
@Component({
  // encapsulation: ViewEncapsulation.None,
  templateUrl: './eeo.html',
  styleUrls: ['./eeo.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EeoComponent implements OnInit {
  connectionState$: Observable<string>;

  public uploaderContent: BehaviorSubject<string> = new BehaviorSubject('please drop file in');
  @ViewChild('fileInput') fileInput;
  user: UserInfo;
  sendtofooter: FooterInfo;
  signalrEndPoint: string;
  server: string;
  form: FormGroup;
  HTTPReqTypes: Array<Selection>;
  APIPoint: string;
  PlaceholderHTTPReqTypes: string;
  PlaceholderAPIPoint: string;
  image0: string;
  image1: string;
  reportsInfo: boolean;
  variablesHome: string;
  constructor(
    private ss: SharedServices,
    private gv: GlobalVariables,
    private http: HttpClient,
    private channelService: ChannelService
  ) {
    // Let's wire up to the signalr observables
    //
    this.connectionState$ = this.channelService.connectionState$
      .pipe(map((state: ConnectionState) => ConnectionState[state]));

    this.channelService.error$.subscribe(
      (error: any) => { console.warn(error); },
      (error: any) => { console.error('errors$ error', error); }
    );

    // Wire up a handler for the starting$ observable to log the
    //  success/fail result
    //
    if (this.ss.getCache('sessionStorage', 'cid', 'string').length < 7) {
      this.channelService.starting$.subscribe(
        () => {
          // console.log('signalr service has been started from eeo');
        },
        () => { console.warn('signalr service failed to start from eeo'); }
      );
    }
  }

  ngOnInit() {


    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.server = this.gv.get('api', 'api');
    // // Start the connection
    // this.signalrEndPoint = this.server + 'signalr';
    // this.channelService.initilizeSignalR(this.signalrEndPoint, 'EventHub');
    // this.channelService.start();

    this.variablesHome = 'getdata';
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');



    this.form = new FormGroup({});
    this.form.addControl('HTTPReqType', new FormControl());
    this.form.addControl('APIPoint', new FormControl());
    this.form.addControl('Message', new FormControl());
    this.HTTPReqTypes = this.ss.getHTTPReqTypes();
    this.APIPoint = 'API here';
    this.PlaceholderHTTPReqTypes = this.HTTPReqTypes[0].label;
    this.PlaceholderAPIPoint = this.APIPoint;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    // Get an observable for events emitted on this channel
    //

  }
  /////////////////// Data loads here
  receiveFromFileService($event) {
    // // console.log($event);
    // this.filenames = $event;
    // if (this.filenames.length === 0) {
    //   this.showfile = false;
    // } else {
    //   this.showfile = true;
    // }
    // this.filetobeprocess = this.filenames[0];
  }
  onSubmit(f: any) {
    // // // console.log(f);
    // const httpverb = this.ss.getFormValue(f.HTTPReqType, this.PlaceholderHTTPReqTypes, this.HTTPReqTypes, 'value', 'label');
    // // // console.log(httpverb);
    // const api = this.ss.getFormValueInput(f.APIPoint, this.PlaceholderAPIPoint, 0);
    // // // console.log(api);
    // // // console.log(this.server);
    // const apiPoint = this.server + api;
    // this.RunIt(httpverb, this.server, api)
    //   .subscribe(res => { // // console.log(res); },
    //     err => { // // console.log(err); });
  }
  RunIt(verb: string, server: string, api: string): Observable<string> {
    const apiPoint = api;
    if (verb === 'GET') {
      return this.http.get(apiPoint).pipe(map((r: string) => {
        // // console.log(r);
        return r;
      }
      ), catchError((e: any) => {
        // // console.log(e);
        return Observable.throw(e);
      }
      ));
    } else {
      Observable.throw('d');
    }
  }
  CallWebWorker() {
    // const worker = new Worker('../test-worker.worker', {
    //   type: 'module'
    // });
    // worker.onmessage = ({ data }) => {
    //   // console.log('From Web Worker:', data);
    // };
    // worker.postMessage({});
  }
}

