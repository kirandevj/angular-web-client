import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SelectModule } from 'angular2-select';
import { EeoComponent } from './eeo.component';
import { EeoRoutes } from './eeo.routes';
import { EeoNavBarComponent } from './nav/eeo-navbar.component';
import { FileUploadModule } from 'ng2-file-upload';
// import { XlsxFileUploadComponent } from '../xlsx-file-upload/xlsx-file-upload.component';
// import { ChannelService, ChannelConfig, SignalrWindow } from '../services/channel.sevice';
// import { ChannelService0, SignalrWindow0 } from '../services/signalr/signalr-service-api';
import { TaskComponent } from '../task/task';
// import { ChartServices } from '../components/chart/chart.services';
// const channelConfig = new ChannelConfig();
// // channelConfig.url = 'http://localhost:63009/signalr/hubs';
// // channelConfig.hubName = 'ChatHub';
// // channelConfig.url = 'http://localhost:63009/signalr';
// // channelConfig.hubName = 'EventHub';
// channelConfig.url = '';
// channelConfig.hubName = '';

@NgModule({
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(EeoRoutes),
    SelectModule,
    FileUploadModule
  ],
  declarations: [
    EeoNavBarComponent,
    EeoComponent,
    // XlsxFileUploadComponent,
    TaskComponent
  ],
  providers: [
    // // ChartServices,
    // ChannelService,
    // { provide: SignalrWindow, useValue: window },
    // // tslint:disable-next-line:no-angle-bracket-type-assertion
    // { provide: 'channel.config', useValue: <ChannelConfig> { url: '', hubName: '' } },
    // ChannelService0,
    // { provide: SignalrWindow0, useValue: window }
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class EeoModule {
}

// https://www.npmjs.com/package/xml2json
