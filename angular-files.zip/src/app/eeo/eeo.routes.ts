import { EeoComponent } from './eeo.component';

export const EeoRoutes = [
    { path: '', component: EeoComponent }
];
