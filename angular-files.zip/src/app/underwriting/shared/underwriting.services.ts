import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { UnderWritingMainData } from '../shared/local.variables';
import { NAICSInfo, RateBookInfo, RateCalculator } from '@app/services/index';
import { LossRatio, PreloadedIDsInfoProcess, Renewal } from '@app/datamodels/index';
// Import RxJs required methods
import { map, filter, scan, catchError, mergeMap } from 'rxjs/operators';

@Injectable()
export class UnderwritingServices {
    constructor(private http: HttpClient, private ss: SharedServices) { }
    // tslint:disable-next-line:ban-types
    getUnderwritingMainModuleInfo(api: string, v: Object): Observable<UnderWritingMainData> {
        // return this.http.post(api + 'api/Underwriting?MainModuleInfo=MainModuleInfo', v).map((r: Response) => r
        // ).catch((e: any) => Observable.throw(e.error || 'Server error'));
        return this.http.post(api + 'api/Underwriting?MainModuleInfo=MainModuleInfo', v).pipe(map((r: UnderWritingMainData) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
    // tslint:disable-next-line:ban-types
    getUnderwritingMainModuleExcelFile(api: string, v: Object): Observable<string[]> {
        // return this.http.post(api + 'api/Underwriting?MainModuleExcelFile=MainModuleExcelFile', v).map((r: Response) => r
        // ).catch((e: any) => Observable.throw(e.error || 'Server error'));
        return this.http.post(api + 'api/Underwriting?MainModuleExcelFile=MainModuleExcelFile', v).pipe(map((r: string[]) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
    getRiskLossRatio(api: string, v: LossRatio): Observable<string[]> {
        return this.http.post(api + 'api/MainAPI?riskLossRatio=riskLossRatio', v).pipe(map((r: string[]) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
    getRenewal(api: string, v: Renewal): Observable<string[]> {
        return this.http.post(api + 'api/MainAPI?renewal=renewal', v).pipe(map((r: string[]) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
    getPreloadedIDsInfoProcess(api: string, v: PreloadedIDsInfoProcess): Observable<string[]> {
        const apiPoint = api + 'api/MainAPI?preloadedidsinfoprocess=preloadedidsinfoprocess';
        return this.http.post(apiPoint, v).pipe(map((r: string[]) => {
            // // console.log('observable returning');
            // // console.log(r);
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
    getRateCalculatorNAICS(api: string, username: string, e: string): Observable<NAICSInfo[]> {
        const apiPoint = api + 'api/Underwriting?ratecalculatoroption=NAICS&username=' + username + '&e=' + e;
        return this.http.get(apiPoint).pipe(map((r: string) => {
            // // console.log('observable returning');
            // // console.log(JSON.parse(r));
            return JSON.parse(r);
        }
        ), catchError((ex: any) => Observable.throw(ex)));
    }
    getRateCalculatorRates(api: string, username: string, e: string, book: string): Observable<RateBookInfo[]> {
        const apiPoint = api + 'api/Underwriting?ratecalculatoroption=' + book + '&username=' + username + '&e=' + e;
        return this.http.get(apiPoint).pipe(map((r: string) => {
            // // console.log('observable returning');
            // // console.log(JSON.parse(r));
            return JSON.parse(r);
        }
        ), catchError((ex: any) => Observable.throw(ex)));
    }
    pushPullRateCalculator(api: string, username: string, e: string, pushpull: string, historyid: string,
        info: RateCalculator[]): Observable<RateCalculator[]> {
        const apiPoint = api + 'api/Underwriting?pushpull=' + pushpull + '&historyid=' + historyid + '&username=' + username + '&e=' + e;
        return this.http.post(apiPoint, info).pipe(map((r: RateCalculator[]) => {
            // console.log('observable returning');
            // console.log(r);
            return r;
        }
        ), catchError((ex: any) => Observable.throw(ex)));
    }
}




