import { Component, OnInit } from '@angular/core';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { UserInfo, FooterInfo } from '@app/datamodels/index';
import {  IPreLoadedProcess } from '../../components/preloaded/pre-loaded.services';

@Component({
  templateUrl: './bill-rates-clients.html',
  styleUrls: ['./bill-rates-clients.css']
})
export class BillRatesClientsComponent implements OnInit {
  user: UserInfo;
  sendtofooter: FooterInfo;
  server: string;
  image0: string;
  image1: string;
  filenames: string[];
  showfile: boolean;
  sentToService: IPreLoadedProcess;
  headerName: string;
  headerBackUrl: string;
  constructor(
    private ss: SharedServices,
    private gv: GlobalVariables
  ) { }
  ngOnInit() {
    this.headerName = 'Bill Rates Clients';
    this.headerBackUrl = 'wcpricing';
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.sentToService = {
      process: 'Underwriting Bill Rates Clients',
      server: this.server,
      qryname: this.ss.getQueryName('UN', 'BRC', 0),
      username: this.user.name,
      c: this.ss.getPass(),
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      mmsback: 12
    };
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - Underwriting page issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
  }
  receiveFromFileService($event) {
    this.filenames = $event;
    if (this.filenames.length === 0) {
      this.showfile = false;
    } else {
      this.showfile = true;
    }
  }
}
