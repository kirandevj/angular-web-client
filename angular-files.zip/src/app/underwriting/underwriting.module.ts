import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SelectModule } from 'angular2-select';
import { UnderwritingComponent } from './underwriting.component';
import { MainComponent } from './main/main.component';
import { CCRRComponent } from './ccrr/ccrr.component';
import { AnalyticsComponent } from './analytics/analytics.component';
import { UndNavBarComponent } from './nav/und-navbar.component';
import { UnderwritingRoutes } from './underwriting.routes';
import { UnderwritingServices } from './shared/underwriting.services';
import { FooterModule } from '@app/common/index';
import { SpinnerModule } from '@app/common/index';
import { LossRatioUWComponent } from './loss-ratio/loss-ratio-uw.component';
import { LocalVariables } from './shared/local.variables';
import { StateExposureUWComponent } from './state-exposure/state-exposure-uw.component';
import { GetRatesUWComponent } from './get-rates/get-rates.component';
import { BillRatesClientsComponent } from './bill-rates-clients/bill-rates-clients.component';
import { PreLoadedModule } from '../components/preloaded/pre-loaded.module';
import { RateCalculatorComponent } from './rate-calculator/rate-calculator.component';
import { DataService } from '@app/services/index';
import { ProgressInfoModule } from '../components/progress-info/progress-info.module';
import { RenewalUWComponent } from './renewal/renewal.component';
@NgModule({
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(UnderwritingRoutes),
    SelectModule,
    FooterModule,
    SpinnerModule,
    PreLoadedModule,
    ProgressInfoModule
  ],
  declarations: [
    UndNavBarComponent,
    UnderwritingComponent,
    MainComponent,
    AnalyticsComponent,
    LossRatioUWComponent,
    RenewalUWComponent,
    StateExposureUWComponent,
    GetRatesUWComponent,
    BillRatesClientsComponent,
    CCRRComponent,
    RateCalculatorComponent
  ],
  providers: [
    UnderwritingServices,
    LocalVariables,
    DataService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class UnderwritingModule {
  selectedPro(): any {
  }
}
