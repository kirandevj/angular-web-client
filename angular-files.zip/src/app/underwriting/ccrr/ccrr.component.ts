import { Component, ViewEncapsulation, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { UserInfo, FooterInfo, Selection } from '@app/datamodels/index';
import { IPreLoadedProcess } from '../../components/preloaded/pre-loaded.services';
import { ChannelEvent, ChannelService } from '@app/services/channel.sevice';
import { BehaviorSubject } from 'rxjs';

@Component({
  templateUrl: './ccrr.html',
  styleUrls: ['./ccrr.component.css']
})
export class CCRRComponent implements OnInit {
  @Input() message: ChannelEvent = {
    Name: '',
    ChannelName: '',
    Timestamp: (new Date(Date.now() - ((new Date()).getTimezoneOffset() * 60000))).toISOString().slice(0, -1),
    Data: {
      State: 'Process info here',
      PercentComplete: 0,
      json: ''
    },
    Json: ''
  };
  items: ChannelEvent[] = [];
  items$ = new BehaviorSubject(this.items);
  env = '';
  sentToSignalRChannel = 'wc_pricing_ccrr';
  receivedFromService = '';
  eventName: string;

  user: UserInfo;
  sendtofooter: FooterInfo;
  showspinner: boolean;
  filenames: string[];
  showfile: boolean;
  showspinner2: boolean;
  form: FormGroup;

  serverInfoCalled: boolean;
  server: string;
  image0: string;
  variablesHome: string;
  sentToService: IPreLoadedProcess;
  yesnos: Array<Selection>;
  Placeholderyesnos: string;
  fsvs: Array<Selection> = [
    { value: 0, label: 'Short version' },
    { value: 1, label: 'Full version' },
    { value: 2, label: 'Both' }
  ];
  Placeholderfsvs: string;

  additionalInfo_0: string;

  additionalInfo_1: string;

  constructor(private ss: SharedServices, private gv: GlobalVariables, private route: ActivatedRoute,
    private channelService: ChannelService, private cdr: ChangeDetectorRef) {
    this.eventName = this.sentToSignalRChannel;
    this.serverInfoCalled = false;
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.server = this.gv.get('api', 'api');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.variablesHome = 'uw_main';
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - Underwriting ccrr page issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
    this.showspinner = false;
    this.showspinner2 = false;
  }
  ngOnInit() {
    this.form = new FormGroup({});
    this.form.addControl('yesno', new FormControl());
    this.form.addControl('fsv', new FormControl());
    this.yesnos = this.ss.getYesNo();
    this.Placeholderyesnos = this.yesnos[1].label;
    this.Placeholderfsvs = this.fsvs[0].label;
    if (typeof this.form.controls.yesno.value === 'undefined') {
      this.additionalInfo_0 = 'No';
    } else {
      this.additionalInfo_0 = this.ss.getFormValue(this.form.controls.yesno.value, this.Placeholderyesnos, this.yesnos, 'value', 'label');
    }
    if (typeof this.form.controls.fsv.value === 'undefined') {
      this.additionalInfo_1 = 'Short version';
    } else {
      this.additionalInfo_1 = this.ss.getFormValue(this.form.controls.fsv.value, this.Placeholderfsvs, this.fsvs, 'value', 'label');
    }
    this.sentToService = {
      process: 'Underwriting CCRR Process',
      server: this.server,
      qryname: this.ss.getQueryName('UN', 'MP', 0),
      username: this.user.name,
      c: this.ss.getPass(),
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      mmsback: 36,
      transportedinfo: [this.additionalInfo_0, this.additionalInfo_1],
      signalr: this.channelService.connectionID$,
      channel: this.eventName,
      eventname: this.eventName
    };
    this.items.push(this.message);
    // console.log(this.channelService.connectionID$);
  }
  receiveFromFileService($event) {
    this.filenames = $event;
    if (this.filenames.length === 0) {
      this.showfile = false;
    } else {
      this.showfile = true;
    }
  }
  receiveFromFileServiceProgress($event: ChannelEvent) {
    // this.ref.detectChanges();
    // // console.log($event);
    this.items.push($event);
    // console.log(this.items);
    this.message = $event;
    // setTimeout(() => {
    this.cdr.detectChanges();
    // }, 1);
    if ($event.Data.FileNames.length > 0) {
      const allowedfiles = ['xlsx', 'csv'];
      const env = this.gv.get('excelfiledownload', 'excelfiledownload');
      // console.log($event.Data.FileNames);
      this.showspinner = false;
      this.ss.downloadFilesFromSignalRService($event.Data.FileNames, env, allowedfiles, true, this.server);
    }
  }
  update() {
    if (typeof this.form.controls.yesno.value === 'undefined') {
      this.additionalInfo_0 = 'No';
    } else {
      this.additionalInfo_0 = this.ss.getFormValue(this.form.controls.yesno.value, this.Placeholderyesnos, this.yesnos, 'value', 'label');
    }
    if (typeof this.form.controls.fsv.value === 'undefined') {
      this.additionalInfo_1 = 'Short version';
    } else {
      this.additionalInfo_1 = this.ss.getFormValue(this.form.controls.fsv.value, this.Placeholderfsvs, this.fsvs, 'value', 'label');
    }
    this.sentToService = {
      process: 'Underwriting CCRR Process',
      server: this.server,
      qryname: this.ss.getQueryName('UN', 'MP', 0),
      username: this.user.name,
      c: this.ss.getPass(),
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      mmsback: 36,
      transportedinfo: [this.additionalInfo_0, this.additionalInfo_1],
      signalr: this.channelService.connectionID$,
      channel: this.eventName,
      eventname: this.eventName
    };
    this.sentToService = JSON.parse(JSON.stringify(this.sentToService));
  }
}
