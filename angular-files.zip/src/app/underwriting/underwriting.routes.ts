import { UnderwritingComponent } from './underwriting.component';
import { MainComponent } from './main/main.component';
import { AnalyticsComponent } from './analytics/analytics.component';
import { LossRatioUWComponent } from './loss-ratio/loss-ratio-uw.component';
import { StateExposureUWComponent } from './state-exposure/state-exposure-uw.component';
import { GetRatesUWComponent } from './get-rates/get-rates.component';
import { BillRatesClientsComponent } from './bill-rates-clients/bill-rates-clients.component';
import { CCRRComponent } from './ccrr/ccrr.component';
import { RateCalculatorComponent } from './rate-calculator/rate-calculator.component';
import { RenewalUWComponent } from './renewal/renewal.component';

export const UnderwritingRoutes = [
    { path: '', component: UnderwritingComponent },
    { path: 'main', component: MainComponent },
    { path: 'analytics', component: AnalyticsComponent },
    { path: 'lossratiouw', component: LossRatioUWComponent },
    { path: 'stateexposureuw', component: StateExposureUWComponent },
    { path: 'getratesuw', component: GetRatesUWComponent },
    { path: 'billratesclients', component: BillRatesClientsComponent },
    { path: 'ccrr', component: CCRRComponent },
    { path: 'ratecalculator', component: RateCalculatorComponent },
    { path: 'renewal', component: RenewalUWComponent }
];
