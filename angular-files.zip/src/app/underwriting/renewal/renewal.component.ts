import { Component, ViewEncapsulation, OnInit, OnChanges, SimpleChanges, Input, ChangeDetectorRef } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { UnderwritingServices } from '../shared/underwriting.services';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { LossRatio, Selection, UserInfo, FooterInfo, CleanFileAndServer, Renewal } from '@app/datamodels/index';
import { LocalVariables, RunProcess } from '../shared/local.variables';
import { ChannelEvent, ChannelService } from '@app/services/channel.sevice';
import { BehaviorSubject } from 'rxjs';

@Component({
  templateUrl: './renewal.html',
  styles: [`
  form {
    /* color: #0000ff;
    font-size: 14px;
    line-height: 1.42857143;
    background-color: #9999ff;
    background-image: none;
    */
    display: block;
    padding: 12px 12px;
    border: 4px solid #8080ff;
    border-radius: 10px;
  }
  .nav.navbar-nav {font-size: 15px;}
  li > a { color: aliceblue; }
  `]
})
export class RenewalUWComponent implements OnInit, OnChanges {
  @Input() message: ChannelEvent = {
    Name: '',
    ChannelName: '',
    Timestamp: (new Date(Date.now() - ((new Date()).getTimezoneOffset() * 60000))).toISOString().slice(0, -1),
    Data: {
      State: 'Process info here',
      PercentComplete: 0,
      json: ''
    },
    Json: ''
  };
  items: ChannelEvent[] = [];
  items$ = new BehaviorSubject(this.items);
  env = '';
  sentToSignalRChannel = 'wcrenewal';
  receivedFromService = '';
  eventName: string;

  user: UserInfo;
  sendtofooter: FooterInfo;
  form: FormGroup;
  Exchanges: Array<Selection>;
  Years: Array<Selection>;
  Months: Array<Selection>;
  MonthBack: number;
  MaxMonths = 36;
  DefaultMonths = 12;
  PlaceholderExchanges: string;
  PlaceholderYears: string;
  PlaceholderMonths: string;
  PlaceholderMonthBack: number;
  server: string;
  image0: string;
  image1: string;
  reportsInfo: boolean;
  ReportsArray: Array<RunProcess>;
  variablesHome: string;
  constructor(
    private uws: UnderwritingServices,
    private ss: SharedServices,
    private gv: GlobalVariables,
    private cdr: ChangeDetectorRef,
    private route: ActivatedRoute,
    private lv: LocalVariables,
    private channelService: ChannelService) {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.eventName = this.sentToSignalRChannel;
    this.variablesHome = 'renewaluw';
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
  }
  ngOnChanges(changes: SimpleChanges) {
    // console.log(`ngOnChanges - data is ${this.message}`);
    // tslint:disable-next-line:forin
    for (const key in changes) {
      // console.log(`${key} changed. Current: ${changes[key].currentValue}. Previous: ${changes[key].previousValue}`);
    }
  }
  ngOnInit() {
    this.form = new FormGroup({});
    this.form.addControl('Exchange', new FormControl());
    this.form.addControl('Year', new FormControl());
    this.form.addControl('Month', new FormControl());
    this.form.addControl('MonthBack', new FormControl());
    this.Exchanges = this.ss.getProductsFull();
    this.Years = this.ss.getYears();
    this.Months = this.ss.getMonths();
    this.MonthBack = this.DefaultMonths;
    this.PlaceholderExchanges = this.Exchanges[0].label;
    this.PlaceholderYears = this.ss.getYearsHolderSds();
    this.PlaceholderMonths = this.ss.getMonthsHolderSds();
    this.PlaceholderMonthBack = this.MonthBack;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
    this.items.push(this.message);
  }
  receiveFromFileServiceProgress($event: ChannelEvent) {
    // this.ref.detectChanges();
    // // console.log($event);
    this.items.push($event);
    // console.log(this.items);
    this.message = $event;
    // setTimeout(() => {
    this.cdr.detectChanges();
    // }, 1);
  }
  onSubmit(formValues: any) {
    const rr: Renewal = {
      exchange: this.ss.getFormValue(formValues.Exchange, this.PlaceholderExchanges, this.Exchanges, 'value', 'label')
        .replace(/–/g, '').replace(/\s+/g, '_'),
      asofyr: +this.ss.getFormValue(formValues.Year, this.PlaceholderYears, this.Years, 'value', 'label'),
      asofmm: +this.ss.getFormValue(formValues.Month, this.PlaceholderMonths, this.Months, 'value', 'label'),
      mmsback: +this.ss.getFormValueInputImproved(document.getElementById('mb')['value'], this.PlaceholderMonthBack),
      qryname: this.ss.getQueryName('R', 'P', +this.ReportsArray.length + 1),
      username: this.user.name,
      machine: this.user.machine,
      c: this.ss.getPass(),
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      signalr: this.channelService.connectionID$,
      channel: this.eventName,
      eventname: this.eventName,
      fingerprint: '',
      imageprocess: this.image1
    };
    rr.fingerprint = rr.exchange + rr.asofyr.toString() + rr.asofmm.toString() + rr.mmsback.toString();
    if (rr.mmsback > this.MaxMonths) {
      rr.mmsback = this.MaxMonths;
    }
    const p: RunProcess = {
      name: 'Renewal process - ' + this.ReportsArray.length,
      run: true,
      object: rr
    };
    this.lv.add(this.variablesHome, p, rr.fingerprint);
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
    // console.log(rr);
  }
  runReport(r: Renewal) {
    this.ReportsArray.forEach((e: RunProcess, i: number) => {
      if (e.object.fingerprint === r.fingerprint) {
        e.object.imageprocess = e.object.imageprocess.replace('.png', '.gif');
        this.getRiskRenewal(e.object);
      }
    });
  }
  deleteReport(r: Renewal) {
    this.lv.remove(this.variablesHome, r.fingerprint);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  getRiskRenewal(v: Renewal) {
    this.uws.getRenewal(this.server, v)
      .subscribe(
        res => {
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
              for (let i = 0; i < res.length; i++) {
                if (res[i] !== null) {
                  /////////////////////////// Cleaning server and web folder
                  const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                  let vv: CleanFileAndServer;
                  if (i === 0) {
                    vv = {
                      fullfilename: res[i],
                      qryname: v.qryname,
                      c: v.c
                    };
                  } else {
                    vv = {
                      fullfilename: res[i],
                      qryname: 'none',
                      c: v.c
                    };
                  }
                  this.ss.cleanFileServer(this.server, vv).subscribe(
                    () => { }, err1 => { });
                }
              }
              // --------------- Cleaning all - web and oracle - END
            }, err => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
            });
        },
        err => { });
  }
  normalizeMMB(v: number) {
    if (v > this.MaxMonths) {
      document.getElementById('mb')['value'] = this.DefaultMonths;
    }
  }
}
