import { Component, ViewEncapsulation, OnInit, OnDestroy, ɵConsole, ViewChild, ElementRef } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { UnderwritingServices } from '../shared/underwriting.services';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { LossRatio, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { LocalVariables, RunProcess } from '../shared/local.variables';
import { NAICSInfo, DataService, RateBookInfo, RateCalculator } from '@app/services/index';
import { Subscription } from 'rxjs';

@Component({
  templateUrl: './rate-calculator.html',
  styleUrls: ['./rate-calculator.css']
})
export class RateCalculatorComponent implements OnInit, OnDestroy {
  @ViewChild('stcode') stcodeF: ElementRef;

  FEIN = '';
  RiskID = '';
  Carrier = '';
  Exchanges: Array<Selection>;
  PlaceholderExchanges: string;

  RateCalculatorCurrent: RateCalculator[] = [];
  RateCalculatorEmpty: RateCalculator = {
    FEIN: '',
    RISKID: '',
    CARRIER: '',
    EXCHANGESTR: '',
    STCODE: '',
    WAGES: 0,
    BASERATE: 0,
    MOD_STR: 0,
    TOTALSTATECOST: 0,
    ESTIMATEDAP: 0,
    ESTIMATEDAP_MODIFIED: 0,
    TOTALSTATECOSTPERCODE: 0,
    MODIFIEDNETRATE: 0,
    TRINETRETAILRATE: 0,
    TRINETMODIFIEDRETAILRATE: 0,
    DISCOUNTNEEDEDTOMATCH: 0,
    ANNUALFEEATRETAIL: 0,
    ANNUALFEEATMATCHEDRATE: 0,
    STATETOTALINDICATOR: false,
    STATEFIRSTINDICATOR: true,
    STATETOTALSTRING: '',
    USERNAME: '',
    TIMEPERIOD: '',
    ORDER_ID: 0
  };

  NAICS: NAICSInfo[] = [];
  RateBookI: RateBookInfo[] = [];
  RateBookII: RateBookInfo[] = [];
  RateBookIII: RateBookInfo[] = [];
  RateBookIV: RateBookInfo[] = [];
  RateBookXI: RateBookInfo[] = [];
  NAICSSubscription: Subscription;
  RateBookIISubscription: Subscription;
  RateBookIIISubscription: Subscription;
  RateBookIVSubscription: Subscription;
  showmainNAICS = false;
  showmainRateBookII = false;
  showmainRateBookIII = false;
  showmainRateBookIV = false;
  showmainIssue = false;
  showupload = false;
  showdownload = false;
  user: UserInfo;
  sendtofooter: FooterInfo;
  form: FormGroup;
  server: string;
  image0: string;
  image1: string;
  reportsInfo: boolean;
  ReportsArray: Array<RunProcess>;
  variablesHome: string;
  /////////////////// Style

  constructor(private uws: UnderwritingServices, private ss: SharedServices,
    private gv: GlobalVariables, private route: ActivatedRoute, private lv: LocalVariables, private ds: DataService) {
    this.NAICSSubscription = this.ds.currentNAICS.subscribe(x => {
      if (x.length > 0) {
        // console.log('NAICS below');
        // console.log(x);
      }
      if (x.length === 0) {
        this.showmainNAICS = false;
      } else {
        this.NAICS = x;
        this.showmainNAICS = true;
      }
      ///// Initiliazing empty view
      if (this.RateCalculatorCurrent.length === 0) {
        this.restart(null);
      }
    });
    this.RateBookIISubscription = this.ds.currentRATE_BOOK_II.subscribe(x => {
      if (x.length > 0) {
        // console.log('TriNet II Rate book below');
        // console.log(x);
      }
      if (x.length === 0) {
        this.showmainRateBookII = false;
      } else {
        this.RateBookII = x;
        this.showmainRateBookII = true;
      }
    });
    this.RateBookIIISubscription = this.ds.currentRATE_BOOK_III.subscribe(x => {
      if (x.length > 0) {
        // console.log('TriNet III Rate book below');
        // console.log(x);
      }
      if (x.length === 0) {
        this.showmainRateBookIII = false;
      } else {
        this.RateBookIII = x;
        this.RateBookI = x;
        this.showmainRateBookIII = true;
      }
    });
    this.RateBookIVSubscription = this.ds.currentRATE_BOOK_IV.subscribe(x => {
      if (x.length > 0) {
        // console.log('TriNet IV Rate book below');
        // console.log(x);
      }
      if (x.length === 0) {
        this.showmainRateBookIV = false;
      } else {
        this.RateBookIV = x;
        this.showmainRateBookIV = true;
      }
    });
  }
  ngOnDestroy() {
    if (this.NAICSSubscription) {
      this.NAICSSubscription.unsubscribe();
    }
    if (this.RateBookIISubscription) {
      this.RateBookIISubscription.unsubscribe();
    }
    if (this.RateBookIIISubscription) {
      this.RateBookIIISubscription.unsubscribe();
    }
    if (this.RateBookIVSubscription) {
      this.RateBookIVSubscription.unsubscribe();
    }
  }
  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.form.addControl('Exchange', new FormControl());
    this.Exchanges = this.ss.getProductsAllLimit();
    this.PlaceholderExchanges = this.Exchanges[2].label;
    this.getNAICSData();
    this.getRateBooksData('RATE_BOOK_II');
    this.getRateBooksData('RATE_BOOK_III');
    this.getRateBooksData('RATE_BOOK_IV');
    this.RateCalculatorCurrent[0].USERNAME = this.user.name;
    this.RateCalculatorCurrent[0].TIMEPERIOD = this.ss.getTimeFrameForServer();
  }
  getNAICSData() {
    this.uws.getRateCalculatorNAICS(this.server, this.user.name, this.ss.getPass())
      .subscribe(
        res => {
          this.NAICS = res;
          if (this.NAICS.length !== 0) {
            this.ds.fillObservableObjects('NAICS', JSON.stringify(res));
          }
        }, err => {
          // console.log(err);
        });
  }
  getRateBooksData(book: string) {
    this.uws.getRateCalculatorRates(this.server, this.user.name, this.ss.getPass(), book)
      .subscribe(
        res => {
          if (book === 'RATE_BOOK_II') {
            this.RateBookII = res;
            this.RateBookXI = res;
          } else {
            if (book === 'RATE_BOOK_III') {
              this.RateBookIII = res;
              this.RateBookI = res;
            } else {
              this.RateBookIV = res;
            }
          }
          this.ds.fillObservableObjects(book, JSON.stringify(res));
        }, err => {
          // console.log(err);
        });
  }
  updateExchange(v: any) {
    this.RateCalculatorCurrent[0].EXCHANGESTR = v.label;
    this.PlaceholderExchanges = v.label;
  }
  updateData(v: string, k: string) {
    this[k] = v.trim().toLocaleUpperCase();
  }
  updateTotalStateCodePerRow(v: string, k: string, i: number) {
    // idTOTALSTATECOST.value,'TOTALSTATECOST', i
    let vv = +v.trim().toLocaleUpperCase().replace(/,/g, '');
    if (v.length === 0) {
      vv = 0;
    }
    const st = this.RateCalculatorCurrent[i].STCODE.substring(0, 2);
    this.RateCalculatorCurrent[i][k] = vv;
    this.RateCalculatorCurrent[i].MODIFIEDNETRATE = +((+vv /
      this.getEstimatedAnnualTotals(st)) * +this.RateCalculatorCurrent[i].BASERATE);
    if (+this.RateCalculatorCurrent[i].TRINETMODIFIEDRETAILRATE === 0) {
      this.RateCalculatorCurrent[i].DISCOUNTNEEDEDTOMATCH = 0;
    } else {
      this.RateCalculatorCurrent[i].DISCOUNTNEEDEDTOMATCH = +(1 - (+this.RateCalculatorCurrent[i].MODIFIEDNETRATE
        / +this.RateCalculatorCurrent[i].TRINETMODIFIEDRETAILRATE));
    }
    this.RateCalculatorCurrent[i].TOTALSTATECOSTPERCODE =
      +((+this.RateCalculatorCurrent[i].WAGES / this.getWagesTotals(st)) * +vv).toFixed(2);
    this.RateCalculatorCurrent[i].ANNUALFEEATMATCHEDRATE = +((+this.RateCalculatorCurrent[i].WAGES / 100) *
      this.RateCalculatorCurrent[i].MODIFIEDNETRATE).toFixed(2);
  }
  updateDataSimple(v: string, k: string, i: number) {
    let vv = +v.trim().toLocaleUpperCase().replace(/,/g, '');
    if (v.length === 0) {
      vv = 0;
    }
    this.RateCalculatorCurrent[i][k] = vv;
    if (this.RateCalculatorCurrent.length - i > 2) {
      this.recalculationState(i);
    }
    if (this.RateCalculatorCurrent[i].STCODE.length > 6) {
      this.recalculationStateTotal(i - 1, +vv);
    }
  }
  updateDataSTCODE(v: string, k: string, i: number) {
    const vv = v.trim().toLocaleUpperCase();
    if (vv.indexOf('Total') === -1) {
      if (vv.length !== 6) {
        this.RateCalculatorCurrent[i][k] = '';
        this.stcodeF.nativeElement.focus();
        return;
      }
      if (!this.RateCalculatorCurrent[i].STATETOTALINDICATOR) {
        this.RateCalculatorCurrent[i][k] = vv;
        this.RateCalculatorCurrent[i].STATETOTALSTRING = vv.substring(0, 2);
        const exch = this.PlaceholderExchanges.replace('TriNet ', '').replace(' – Accord', '').replace(' – SOI', '')
          .replace(' – Passport', '').replace(' – Ambrose', '').replace(' – None medical', '');
        const book: RateBookInfo[] = this['RateBook' + exch];
        try {
          const rate = book.filter(x => x.COMBO === vv)[0].RETAILRATE;
          this.RateCalculatorCurrent[i].TRINETRETAILRATE = +rate;
        } catch { }
        const st_entered = vv.substring(0, 2);
        if (i === 0) {
          const addIt = this.RateCalculatorCurrent.filter(x => {
            if (x.STATETOTALSTRING === st_entered && x.STATETOTALINDICATOR === true) {
              return true;
            } else {
              return false;
            }
          });
          if (addIt.length === 0) {
            if (this.RateCalculatorCurrent.length === 1) {
              const tba: RateCalculator = JSON.parse(JSON.stringify(this.RateCalculatorEmpty));
              tba.STATEFIRSTINDICATOR = false;
              if (this.checkIfOKToAddRow()) {
                this.RateCalculatorCurrent.push(tba);
              }
              ////////////////////// callculations here
              const EstimatedAP = +((+this.RateCalculatorCurrent[i].WAGES / 100) *
                +this.RateCalculatorCurrent[i].BASERATE).toFixed(2);
              this.RateCalculatorCurrent[i].ESTIMATEDAP = EstimatedAP;
              this.RateCalculatorCurrent[i].ESTIMATEDAP_MODIFIED = +(EstimatedAP * +this.RateCalculatorCurrent[i].MOD_STR).toFixed(2);
            }
          }
        } else {
          const mod = +this.RateCalculatorCurrent[i - 1].MOD_STR;
          const TotalStateCost = +this.RateCalculatorCurrent[i - 1].TOTALSTATECOST;
          const st_prior = this.RateCalculatorCurrent[i - 1].STCODE.substring(0, 2);
          const addIt = this.RateCalculatorCurrent.filter(x => {
            if (x.STATETOTALSTRING === st_prior && x.STATETOTALINDICATOR === true) {
              return true;
            } else {
              return false;
            }
          });
          if (st_prior !== st_entered) {
            this.RateCalculatorCurrent[i].STATEFIRSTINDICATOR = true;
            this.RateCalculatorCurrent[i].STATETOTALINDICATOR = false;
            ////////////////////// Pushing and adding
            if (addIt.length === 0) {
              const tba: RateCalculator = JSON.parse(JSON.stringify(this.RateCalculatorEmpty));
              tba.MOD_STR = mod;
              tba.TOTALSTATECOST = TotalStateCost;
              tba.STATEFIRSTINDICATOR = false;
              tba.STATETOTALINDICATOR = true;
              tba.STCODE = this.RateCalculatorCurrent[i - 1].STCODE.substring(0, 2) + ' Total';
              tba.STATETOTALSTRING = this.RateCalculatorCurrent[i - 1].STCODE.substring(0, 2);
              this.RateCalculatorCurrent.splice(i, 0, tba);
              /////////////////////////// Check if the last two if  length > 2 and last two elements are empty on STCODE
              const tba2: RateCalculator = JSON.parse(JSON.stringify(this.RateCalculatorEmpty));
              tba2.STCODE = '';
              tba2.STATEFIRSTINDICATOR = false;
              tba2.STATETOTALINDICATOR = false;
              tba2.MOD_STR = 0;
              tba2.TOTALSTATECOST = 0;
              if (this.checkIfOKToAddRow()) {
                this.RateCalculatorCurrent.push(tba2);
              }
              /////////////////// Calculating totals
              this.recalculation();
            } else {
              const tba: RateCalculator = JSON.parse(JSON.stringify(this.RateCalculatorEmpty));
              tba.MOD_STR = mod;
              tba.TOTALSTATECOST = TotalStateCost;
              tba.STATEFIRSTINDICATOR = false;
              tba.STATETOTALINDICATOR = false;
              if (this.checkIfOKToAddRow()) {
                this.RateCalculatorCurrent.push(tba);
              }
              ////////////////////// callculations here
              const EstimatedAP = +((+this.RateCalculatorCurrent[i].WAGES / 100) *
                +this.RateCalculatorCurrent[i].BASERATE).toFixed(2);
              this.RateCalculatorCurrent[i].ESTIMATEDAP = EstimatedAP;
              this.RateCalculatorCurrent[i].ESTIMATEDAP_MODIFIED = +(EstimatedAP * +this.RateCalculatorCurrent[i].MOD_STR).toFixed(2);
            }
          } else {
            if (addIt.length === 0) {
              const tba: RateCalculator = JSON.parse(JSON.stringify(this.RateCalculatorEmpty));
              tba.MOD_STR = mod;
              tba.TOTALSTATECOST = TotalStateCost;
              tba.STATEFIRSTINDICATOR = false;
              tba.STATETOTALINDICATOR = false;
              if (this.checkIfOKToAddRow()) {
                this.RateCalculatorCurrent.push(tba);
              }
              ////////////////////// callculations here
              const EstimatedAP = +((+this.RateCalculatorCurrent[i].WAGES / 100) *
                +this.RateCalculatorCurrent[i].BASERATE).toFixed(2);
              this.RateCalculatorCurrent[i].ESTIMATEDAP = EstimatedAP;
              this.RateCalculatorCurrent[i].ESTIMATEDAP_MODIFIED = +(EstimatedAP * +this.RateCalculatorCurrent[i].MOD_STR).toFixed(2);
            }
          }
        }
      } else {

      }
      if (this.RateCalculatorCurrent.length - i > 2) {
        this.recalculationState(i);
      }
    }
  }
  updateDataWages(v: string, k: string, i: number) {
    const vv = v.trim().toLocaleUpperCase().replace(/,/g, '');
    this.RateCalculatorCurrent[i][k] = vv;
    ////////////////////// callculations here
    const EstimatedAP = +((+this.RateCalculatorCurrent[i].WAGES / 100) *
      +this.RateCalculatorCurrent[i].BASERATE).toFixed(2);
    this.RateCalculatorCurrent[i].ESTIMATEDAP = EstimatedAP;
    const annualFeeAtRetail = +((+vv / 100) * +this.RateCalculatorCurrent[i].TRINETRETAILRATE).toFixed(2);
    this.RateCalculatorCurrent[i].ANNUALFEEATRETAIL = annualFeeAtRetail;
    if (this.RateCalculatorCurrent.length - i > 2) {
      this.recalculationState(i);
    }
  }
  updateDataBaseRate(v: string, k: string, i: number) {
    const vv = v.trim().toLocaleUpperCase().replace(/,/g, '');
    this.RateCalculatorCurrent[i][k] = vv;
    ////////////////////// callculations here
    const EstimatedAP = +((+this.RateCalculatorCurrent[i].WAGES / 100) *
      +this.RateCalculatorCurrent[i].BASERATE).toFixed(2);
    this.RateCalculatorCurrent[i].ESTIMATEDAP = EstimatedAP;
    if (!this.RateCalculatorCurrent[i].STATEFIRSTINDICATOR) {
      //////////////////
      this.RateCalculatorCurrent[i].MOD_STR = this.RateCalculatorCurrent[i - 1].MOD_STR;
      this.RateCalculatorCurrent[i].TOTALSTATECOST = this.RateCalculatorCurrent[i - 1].TOTALSTATECOST;
      //////////////////
      const ESTIMATEDAP_MODIFIED = +(+this.RateCalculatorCurrent[i].MOD_STR * +EstimatedAP).toFixed(2);
      this.RateCalculatorCurrent[i].ESTIMATEDAP_MODIFIED = ESTIMATEDAP_MODIFIED;
      const triNetModifiedRetailRate = +this.RateCalculatorCurrent[i].TRINETRETAILRATE * +this.RateCalculatorCurrent[i].MOD_STR;
      this.RateCalculatorCurrent[i].TRINETMODIFIEDRETAILRATE = triNetModifiedRetailRate;
    }
    if (this.RateCalculatorCurrent.length - i > 2) {
      this.recalculationState(i);
    }
    if (i >= 1) {
      this.RateCalculatorCurrent[i].MODIFIEDNETRATE = +((+this.RateCalculatorCurrent[i].TOTALSTATECOST /
        this.getEstimatedAnnualTotals(this.RateCalculatorCurrent[i].STCODE.substring(0, 2))) * +this.RateCalculatorCurrent[i].BASERATE);
      if (+this.RateCalculatorCurrent[i].TRINETMODIFIEDRETAILRATE === 0) {
        this.RateCalculatorCurrent[i].DISCOUNTNEEDEDTOMATCH = 0;
      } else {
        this.RateCalculatorCurrent[i].DISCOUNTNEEDEDTOMATCH = +(1 - (+this.RateCalculatorCurrent[i].MODIFIEDNETRATE
          / +this.RateCalculatorCurrent[i].TRINETMODIFIEDRETAILRATE));
      }
      this.RateCalculatorCurrent[i].ANNUALFEEATMATCHEDRATE = +this.RateCalculatorCurrent[i].TOTALSTATECOSTPERCODE;
      this.recalculationState(i);
    }
  }
  updateDataMOD(v: string, k: string, i: number) {
    const vv = v.trim().toLocaleUpperCase().replace(/,/g, '');
    this.RateCalculatorCurrent[i][k] = vv;
    ////////////////////// callculations here
    const ESTIMATEDAP_MODIFIED = +(+this.RateCalculatorCurrent[i].ESTIMATEDAP * +vv).toFixed(2);
    this.RateCalculatorCurrent[i].ESTIMATEDAP_MODIFIED = ESTIMATEDAP_MODIFIED;
    const triNetModifiedRetailRate = +this.RateCalculatorCurrent[i].TRINETRETAILRATE * +vv;
    this.RateCalculatorCurrent[i].TRINETMODIFIEDRETAILRATE = triNetModifiedRetailRate;
    if (this.RateCalculatorCurrent.length - i > 2) {
      this.recalculationState(i);
    }
  }
  recalculation() {
    const index = this.RateCalculatorCurrent.length - 3;
    let estimatedAPWBS = 0;
    let ESTIMATEDAP_MODIFIED = 0;
    let annualFeeAtRetail = 0;
    let annualFeeAtMatchedRate = 0;
    let totalStateCostPerCode = 0;
    const state_total: RateCalculator = JSON.parse(JSON.stringify(this.RateCalculatorCurrent[index]));
    const states = this.RateCalculatorCurrent.filter(xt => {
      if (xt.STATETOTALSTRING === state_total.STATETOTALSTRING && xt.STATETOTALINDICATOR !== true) {
        return true;
      } else {
        return false;
      }
    });
    states.map(x => {
      //////////////////// summing up for totals
      estimatedAPWBS = estimatedAPWBS + +x.ESTIMATEDAP;
      ESTIMATEDAP_MODIFIED = ESTIMATEDAP_MODIFIED + +x.ESTIMATEDAP_MODIFIED;
    });
    /////////////////// Totals here
    this.RateCalculatorCurrent[index].ESTIMATEDAP = estimatedAPWBS;
    this.RateCalculatorCurrent[index].ESTIMATEDAP_MODIFIED = ESTIMATEDAP_MODIFIED;
    ////////////////// applying formula
    this.RateCalculatorCurrent.map(x => {
      if (x.STATETOTALSTRING === state_total.STATETOTALSTRING && x.STATETOTALINDICATOR !== true) {
        if (+estimatedAPWBS === 0) {
          x.MODIFIEDNETRATE = 0;
        } else {
          x.MODIFIEDNETRATE = (+x.TOTALSTATECOST / +estimatedAPWBS) * x.BASERATE;
        }
        x.ANNUALFEEATMATCHEDRATE = +x.TOTALSTATECOSTPERCODE;
        totalStateCostPerCode = totalStateCostPerCode + +x.TOTALSTATECOSTPERCODE;
        annualFeeAtMatchedRate = +annualFeeAtMatchedRate + +x.ANNUALFEEATMATCHEDRATE;
        annualFeeAtRetail = +annualFeeAtRetail + +x.ANNUALFEEATRETAIL;
        if (+x.TRINETMODIFIEDRETAILRATE === 0) {
          x.DISCOUNTNEEDEDTOMATCH = 0;
        } else {
          x.DISCOUNTNEEDEDTOMATCH = +(1 - (+x.MODIFIEDNETRATE / +x.TRINETMODIFIEDRETAILRATE));
        }
      }
    });
    ///////////////// adding total again
    this.RateCalculatorCurrent.filter(x => {
      if (x.STATETOTALSTRING === state_total.STATETOTALSTRING && x.STATETOTALINDICATOR === true) {
        /////////////////// Totals here
        x.TOTALSTATECOSTPERCODE = +totalStateCostPerCode;
        x.ANNUALFEEATRETAIL = +annualFeeAtRetail;
        x.ANNUALFEEATMATCHEDRATE = +annualFeeAtMatchedRate;
      }
    });
  }
  recalculationState(i: number) {
    const st = this.RateCalculatorCurrent[i].STCODE.substring(0, 2);
    const estimatedAPWBS = this.getEstimatedAnnualTotals(st);
    this.RateCalculatorCurrent.filter(x => {
      if (x.STATETOTALSTRING === st && x.STCODE.length === 6) {
        x.ESTIMATEDAP_MODIFIED = +(+x.ESTIMATEDAP * +x.MOD_STR).toFixed(2);
        if (+estimatedAPWBS === 0) {
          x.MODIFIEDNETRATE = 0;
        } else {
          x.MODIFIEDNETRATE = +((+x.TOTALSTATECOST / +estimatedAPWBS) * +x.BASERATE);
        }
        x.TRINETMODIFIEDRETAILRATE = +x.TRINETRETAILRATE * +x.MOD_STR;
        if (+x.TRINETMODIFIEDRETAILRATE === 0) {
          x.DISCOUNTNEEDEDTOMATCH = 0;
        } else {
          x.DISCOUNTNEEDEDTOMATCH = +(1 - (+x.MODIFIEDNETRATE / +x.TRINETMODIFIEDRETAILRATE));
        }
        x.TOTALSTATECOSTPERCODE =
          +((+x.WAGES / this.getWagesTotals(st)) * +x.TOTALSTATECOST).toFixed(2);
        x.ANNUALFEEATRETAIL = +((+x.WAGES / 100) * +x.TRINETRETAILRATE).toFixed(2);
        x.ANNUALFEEATMATCHEDRATE = +((+x.WAGES / 100) * +x.MODIFIEDNETRATE).toFixed(2);
      }
    });
  }
  recalculationStateTotal(i: number, estimatedAPWBS: number) {
    const st = this.RateCalculatorCurrent[i].STCODE.substring(0, 2);
    let annualFeeAtMatchedRate = 0;
    let totalStateCostPerCode = 0;
    this.RateCalculatorCurrent.filter(x => {
      if (x.STATETOTALSTRING === st && x.STCODE.length === 6) {
        if (+estimatedAPWBS === 0) {
          x.MODIFIEDNETRATE = 0;
        } else {
          x.MODIFIEDNETRATE = +((+x.TOTALSTATECOST / +estimatedAPWBS) * +x.BASERATE);
        }
        if (+x.DISCOUNTNEEDEDTOMATCH === 0) {
          x.DISCOUNTNEEDEDTOMATCH = 0;
        } else {
          x.DISCOUNTNEEDEDTOMATCH = +(1 - (+x.MODIFIEDNETRATE / +x.TRINETMODIFIEDRETAILRATE));
        }
        x.TOTALSTATECOSTPERCODE =
          +((+x.WAGES / this.getWagesTotals(st)) * +x.TOTALSTATECOST).toFixed(2);
        x.ANNUALFEEATMATCHEDRATE = +((+x.WAGES / 100) * +x.MODIFIEDNETRATE).toFixed(2);
        annualFeeAtMatchedRate = annualFeeAtMatchedRate + +x.ANNUALFEEATMATCHEDRATE;
        totalStateCostPerCode = totalStateCostPerCode + +x.TOTALSTATECOSTPERCODE;
      }
    });
    this.RateCalculatorCurrent[i + 1].TOTALSTATECOSTPERCODE = +totalStateCostPerCode;
    this.RateCalculatorCurrent[i + 1].ANNUALFEEATMATCHEDRATE = +annualFeeAtMatchedRate;
  }
  getStyle(i: number): object {
    const rn = {
      'background-color': 'rgb(230, 255, 204)'
    };
    const rt = {
      'font-size': '105%',
      'font-weight': 'bold',
      'background-color': 'rgb(66, 128, 0)'
    };
    if (this.RateCalculatorCurrent[i].STATETOTALINDICATOR) {
      return rt;
    } else {
      return rn;
    }
  }
  getStyle2(i: number): object {
    const rn = {
      'background-color': 'white'
    };
    const rt = {
      'font-size': '105%',
      'font-weight': 'bold',
      'background-color': 'rgb(66, 128, 0)'
    };
    if (this.RateCalculatorCurrent[i].STATETOTALINDICATOR) {
      return rt;
    } else {
      return rn;
    }
  }
  removeRow(i: number) {
    if (i !== 0) {
      this.RateCalculatorCurrent.splice(i, 1);
    }
  }
  addRow() {
    if (this.checkIfOKToAddRow()) {
      /////////////////////////// Check if the last two if  length > 2 and last two elements are empty on STCODE
      const tba2: RateCalculator = JSON.parse(JSON.stringify(this.RateCalculatorEmpty));
      tba2.STCODE = '';
      tba2.STATEFIRSTINDICATOR = true;
      tba2.STATETOTALINDICATOR = false;
      tba2.MOD_STR = 0;
      tba2.TOTALSTATECOST = 0;
      this.RateCalculatorCurrent.push(tba2);
    }
  }
  getHistorical() {
    if (this.RiskID.length > 0) {
      this.showdownload = true;
      const t = this.ss.getTimeFrameForServer();
      let index = 0;
      this.RateCalculatorCurrent.map(x => {
        x.FEIN = this.FEIN;
        x.RISKID = this.RiskID;
        x.CARRIER = this.Carrier;
        x.EXCHANGESTR = this.PlaceholderExchanges;
        x.TIMEPERIOD = t;
        x.USERNAME = this.user.name;
        x.ORDER_ID = index;
        ++index;
      });
      this.uws.pushPullRateCalculator(this.server, this.user.name, this.ss.getPass(), 'pull',
        this.RiskID, this.RateCalculatorCurrent)
        .subscribe(
          res => {
            // console.log(res);
            const arr: RateCalculator[] = JSON.parse(res[0].RISKID);
            arr.map(x => {
              x.FEIN = x.FEIN;
              x.RISKID = x.RISKID;
              x.CARRIER = x.CARRIER;
              x.EXCHANGESTR = x.EXCHANGESTR;
              x.STCODE = x.STCODE;
              x.WAGES = +x.WAGES;
              x.BASERATE = +x.BASERATE;
              x.ESTIMATEDAP = +x.ESTIMATEDAP;
              x.MOD_STR = +x.MOD_STR;
              x.TOTALSTATECOST = +x.TOTALSTATECOST;
              x.ESTIMATEDAP_MODIFIED = +x.ESTIMATEDAP_MODIFIED;
              x.TOTALSTATECOSTPERCODE = +x.TOTALSTATECOSTPERCODE;
              x.MODIFIEDNETRATE = +x.MODIFIEDNETRATE;
              x.TRINETRETAILRATE = +x.TRINETRETAILRATE;
              x.TRINETMODIFIEDRETAILRATE = +x.TRINETMODIFIEDRETAILRATE;
              x.DISCOUNTNEEDEDTOMATCH = +x.DISCOUNTNEEDEDTOMATCH;
              x.ANNUALFEEATRETAIL = +x.ANNUALFEEATRETAIL;
              x.ANNUALFEEATMATCHEDRATE = +x.ANNUALFEEATMATCHEDRATE;
              x.STATETOTALINDICATOR = JSON.parse(JSON.parse(JSON.stringify(x.STATETOTALINDICATOR)));
              x.STATEFIRSTINDICATOR = JSON.parse(JSON.parse(JSON.stringify(x.STATEFIRSTINDICATOR)));
              x.STATETOTALSTRING = x.STATETOTALSTRING;
              x.USERNAME = x.USERNAME;
              x.TIMEPERIOD = x.TIMEPERIOD;
              x.ORDER_ID = +x.ORDER_ID;
            });
            this.RateCalculatorCurrent = arr;
            // console.log(this.RateCalculatorCurrent);
            this.showdownload = false;
          }, err => {
            this.showdownload = true;
          });
    }

  }
  uploadToServer() {
    if (this.RiskID.length > 0) {
      this.showupload = true;
      this.addTotals();
      const t = this.ss.getTimeFrameForServer();
      let index = 0;
      this.RateCalculatorCurrent.map(x => {
        x.FEIN = this.FEIN;
        x.RISKID = this.RiskID;
        x.CARRIER = this.Carrier;
        x.EXCHANGESTR = this.PlaceholderExchanges;
        x.TIMEPERIOD = t;
        x.USERNAME = this.user.name;
        x.ORDER_ID = index;
        ++index;
      });
      this.uws.pushPullRateCalculator(this.server, this.user.name, this.ss.getPass(), 'push',
        this.RiskID, this.RateCalculatorCurrent)
        .subscribe(
          res => {
            if (res[0].RISKID === 't') {
              this.restart('button');
              this.showupload = false;
            } else {
              this.showmainIssue = true;
            }
          }, err => {
            this.showmainIssue = true;
          });
    }
  }
  checkIfOKToAddRow(): boolean {
    let r = true;
    if (this.RateCalculatorCurrent.length >= 2) {
      if (this.RateCalculatorCurrent[this.RateCalculatorCurrent.length - 1].STCODE === '') {
        r = false;
      }
    }
    return r;
  }
  addTotals() {
    try {
      const i = this.RateCalculatorCurrent.length - 1;
      const mod = +this.RateCalculatorCurrent[i - 1].MOD_STR;
      const TotalStateCost = +this.RateCalculatorCurrent[i - 1].TOTALSTATECOST;
      const st_prior = this.RateCalculatorCurrent[i - 1].STCODE.substring(0, 2);
      const addIt = this.RateCalculatorCurrent.filter(x => {
        if (x.STATETOTALSTRING === st_prior && x.STATETOTALINDICATOR === true) {
          return true;
        } else {
          return false;
        }
      });
      this.RateCalculatorCurrent[i].STATEFIRSTINDICATOR = true;
      this.RateCalculatorCurrent[i].STATETOTALINDICATOR = false;
      if (addIt.length === 0) {
        const tba: RateCalculator = JSON.parse(JSON.stringify(this.RateCalculatorEmpty));
        tba.MOD_STR = +mod;
        tba.TOTALSTATECOST = +TotalStateCost;
        tba.STATEFIRSTINDICATOR = false;
        tba.STATETOTALINDICATOR = true;
        tba.STCODE = this.RateCalculatorCurrent[i - 1].STCODE.substring(0, 2) + ' Total';
        tba.STATETOTALSTRING = this.RateCalculatorCurrent[i - 1].STCODE.substring(0, 2);
        this.RateCalculatorCurrent.splice(i, 0, tba);
        /////////////////////////// Check if the last two if  length > 2 and last two elements are empty on STCODE
        const tba2: RateCalculator = JSON.parse(JSON.stringify(this.RateCalculatorEmpty));
        tba2.STCODE = '';
        tba2.STATEFIRSTINDICATOR = false;
        tba2.STATETOTALINDICATOR = false;
        tba2.MOD_STR = 0;
        tba2.TOTALSTATECOST = 0;
        if (this.checkIfOKToAddRow()) {
          this.RateCalculatorCurrent.push(tba2);
        }
        this.recalculationState(i);
      }
    } catch {

    }
  }
  getEstimatedAnnualTotals(st: string): number {
    let estimatedAP_Total = 0;
    let estimatedAP_Total_2 = 0;
    let r = 0;
    this.RateCalculatorCurrent.filter(x => {
      if (x.STCODE.substring(0, 2) === st && x.STCODE.length === 6) {
        estimatedAP_Total = +estimatedAP_Total + +x.ESTIMATEDAP;
      } else {
        if (x.STCODE.substring(0, 2) === st && x.STCODE.length !== 6) {
          estimatedAP_Total_2 = +x.ESTIMATEDAP;
        }
      }
    });
    r = estimatedAP_Total;
    if (estimatedAP_Total_2 !== estimatedAP_Total && estimatedAP_Total_2 !== 0) {
      r = estimatedAP_Total_2;
    }
    return r;
  }
  getWagesTotals(st: string): number {
    const arr = this.RateCalculatorCurrent.filter(x => {
      if (x.STCODE.substring(0, 2) === st && x.STCODE.length === 6) {
        return true;
      } else {
        return false;
      }
    });
    let r = 0;
    arr.map(x => {
      r = r + +x.WAGES;
    });
    return r;
  }
  restart(opt: string) {
    if (opt === 'button') {
      const x: RateCalculator = JSON.parse(JSON.stringify(this.RateCalculatorEmpty));
      x.USERNAME = this.user.name;
      x.TIMEPERIOD = this.ss.getTimeFrameForServer();
      this.RateCalculatorCurrent = JSON.parse(JSON.stringify([x]));
      this.FEIN = '';
      this.RiskID = '';
      this.Carrier = '';
    } else {
      this.RateCalculatorCurrent = JSON.parse(JSON.stringify([this.RateCalculatorEmpty]));
      this.FEIN = '';
      this.RiskID = '';
      this.Carrier = '';
    }
  }
  recalculateAll() {
    this.addTotals();
    //////////////////// Recalculate all here
    const arr = [];
    this.RateCalculatorCurrent.map(x => {
      arr.push(x.STCODE.substring(0, 2));
    });
    const arr2 = [...new Set(arr)];
    arr2.map(y => {
      let estimatedAP_Total = 0;
      let estimatedAMP_Total = 0;
      let annualFeeAtMatchedRate = 0;
      let annualFeeAtRetail = 0;
      let totalStateCostPerCode = 0;
      let totalStateCost = 0;
      const wagesTotals = this.getWagesTotals(y);
      ///////////////////////// Loop for row by row calculation plus totals when applicable
      this.RateCalculatorCurrent.map(x => {
        if (x.STCODE.length === 6 && x.STCODE.substring(0, 2) === y) {
          //////////////////////////// propagating TotalStateCode
          if (totalStateCost === 0) {
            totalStateCost = x.TOTALSTATECOST;
          } else {
            x.TOTALSTATECOST = totalStateCost;
          }
          x.ESTIMATEDAP = +((+x.WAGES / 100) * +x.BASERATE).toFixed(2);
          estimatedAP_Total = +estimatedAP_Total + +x.ESTIMATEDAP;
          x.ESTIMATEDAP_MODIFIED = +(+x.MOD_STR * +x.ESTIMATEDAP).toFixed(2);
          estimatedAMP_Total = +estimatedAMP_Total + +x.ESTIMATEDAP_MODIFIED;
          x.TRINETMODIFIEDRETAILRATE = +x.MOD_STR * +x.TRINETRETAILRATE;
          x.ANNUALFEEATRETAIL = +((+x.WAGES / 100) * +x.TRINETRETAILRATE).toFixed(2);
          annualFeeAtRetail = +annualFeeAtRetail + +x.ANNUALFEEATRETAIL;
          x.TOTALSTATECOSTPERCODE = +((+x.WAGES / +wagesTotals) * +x.TOTALSTATECOST).toFixed(2);
          totalStateCostPerCode = +totalStateCostPerCode + +x.TOTALSTATECOSTPERCODE;
        } else {
          if (x.STCODE.length !== 6 && x.STCODE.substring(0, 2) === y) {
            x.TOTALSTATECOST = totalStateCost;
            totalStateCost = 0;
            if (x.ESTIMATEDAP === 0) {
              x.ESTIMATEDAP = +estimatedAP_Total;
            } else {
              estimatedAP_Total = +x.ESTIMATEDAP;
            }
            x.ESTIMATEDAP_MODIFIED = +estimatedAMP_Total;
            x.ANNUALFEEATRETAIL = +annualFeeAtRetail;
            x.TOTALSTATECOSTPERCODE = +totalStateCostPerCode;
          }
        }
      });
      ///////////////////////// Loop for final calculations
      this.RateCalculatorCurrent.map(x => {
        if (x.STCODE.length === 6 && x.STCODE.substring(0, 2) === y) {
          /////////////////////////
          if (+estimatedAP_Total === 0) {
            x.MODIFIEDNETRATE = 0;
          } else {
            x.MODIFIEDNETRATE = (+x.TOTALSTATECOST / +estimatedAP_Total) * x.BASERATE;
          }
          /////////////////////////
          if (+x.TRINETMODIFIEDRETAILRATE === 0) {
            x.DISCOUNTNEEDEDTOMATCH = 0;
          } else {
            x.DISCOUNTNEEDEDTOMATCH = +(1 - (+x.MODIFIEDNETRATE / +x.TRINETMODIFIEDRETAILRATE));
          }
          /////////////////////////
          x.ANNUALFEEATMATCHEDRATE = +((+x.WAGES / 100) * +x.MODIFIEDNETRATE).toFixed(2);
          annualFeeAtMatchedRate = +annualFeeAtMatchedRate + x.ANNUALFEEATMATCHEDRATE;
        } else {
          if (x.STCODE.length !== 6 && x.STCODE.substring(0, 2) === y) {
            x.ANNUALFEEATMATCHEDRATE = +annualFeeAtMatchedRate;
          }
        }
      });
    });
    // console.log(this.RateCalculatorCurrent);
  }
}
