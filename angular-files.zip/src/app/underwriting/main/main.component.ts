import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { UserInfo, FooterInfo, CleanFileAndServer, Selection } from '@app/datamodels/index';
import { UnderwritingServices } from '../shared/underwriting.services';
import { UnderWritingMainData } from '../shared/local.variables';
import { FooterComponent } from '@app/common/index';
import { SpinnerComponent } from '@app/common/index';
import { PreLoadedComponent } from '../../components/preloaded/pre-loaded.component';
import { IPreLoadedProcess } from '../../components/preloaded/pre-loaded.services';
@Component({
  templateUrl: './main.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  MainObject: UnderWritingMainData = {
    version: '',
    id: '',
    date: '',
    id3: '',
    id4: '',
    statuses: '',
    billrateid: '',
    pfcorp: '',
    product: '',
    name: '',
    user: '',
    policyyearrate: '',
    paygrouppayfreqtierrate: '',
    lossratiotimeperiod: '',
    startdate: '',
    termdate: '',
    encr: this.ss.getCache('localStorage', 'pass', 'string'),
    env: this.gv.get('excelfilesave', 'excelfilesave'),
    filenameshort: '',
    queryname: ''
  };
  user: UserInfo;
  sendtofooter: FooterInfo;
  showspinner: boolean;
  filenames: string[];
  theDate: Date;
  showfile: boolean;
  showspinner2: boolean;
  form: FormGroup;
  ID: string;
  PlaceholderID: string;
  Date: string;
  PlaceholderDate: string;
  Statuses: string;
  PlaceholderStatuses: string;
  Product: string;
  Name: string;
  BillRateID: string;
  PFCorp: string;
  PGPFTR: string;
  LossRatio: string;
  PolicyYear: string;
  Product2: string;
  Name2: string;
  BillRateID2: string;
  PFCorp2: string;
  PGPFTR2: string;
  LossRatio2: string;
  PolicyYear2: string;
  StartdateTermdate: string;
  StartdateTermdate2: string;
  serverInfoCalled: boolean;
  server: string;
  image0: string;
  variablesHome: string;
  sentToService: IPreLoadedProcess;
  fsvs: Array<Selection> = [
    { value: 0, label: 'Short version' },
    { value: 1, label: 'Short version with concession' },
    { value: 2, label: 'Full version' }
  ];
  Placeholderfsvs: string;

  constructor(private ss: SharedServices, private gv: GlobalVariables, private route: ActivatedRoute,
    private urs: UnderwritingServices) { }
  ngOnInit() {
    this.theDate = new Date((new Date()).getTime() - (new Date()).getTimezoneOffset() * 60000);
    document.getElementById('theDate')['valueAsDate'] = this.theDate;
    this.serverInfoCalled = false;
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.server = this.gv.get('api', 'api');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.variablesHome = 'uw_main';
    this.form = new FormGroup({});
    this.form.addControl('ID', new FormControl());
    this.PlaceholderID = 'Enter ID here';
    this.form.addControl('Date', new FormControl());
    this.form.addControl('fsv', new FormControl());
    this.PlaceholderDate = this.ss.getDateStringFormat();
    this.form.addControl('Statuses', new FormControl());
    this.Placeholderfsvs = this.fsvs[0].label;
    this.PlaceholderStatuses = 'active';
    this.Product = 'Product: ';
    this.Name = 'Client name / ID3 / ID4 / Start and Term date (active): ';
    this.BillRateID = 'Latest Bill Rate ID: ';
    this.PFCorp = 'PF Corp: ';
    this.PGPFTR = 'Pay group/Pay frequency/Tier Rate: ';
    this.LossRatio = 'Loss Ratio time period: ';
    this.PolicyYear = 'Policy Year Rate Table: ';
    this.Product2 = '';
    this.Name2 = '';
    this.BillRateID2 = '';
    this.PFCorp2 = '';
    this.PGPFTR2 = '';
    this.LossRatio2 = '';
    this.StartdateTermdate = '';
    this.StartdateTermdate2 = '';
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - Underwriting main page issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
    this.showspinner = false;
    this.showspinner2 = false;
    // document.getElementById('theDate')['valueAsDate'] = new Date();
    this.sentToService = {
      process: 'Underwriting Main Process',
      server: this.server,
      qryname: this.ss.getQueryName('UN', 'MP', 0),
      username: this.user.name,
      c: this.ss.getPass(),
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      mmsback: 36
    };
  }
  ClickInfo(f: any): void {
    if (!this.serverInfoCalled) {
      this.MainObject.user = this.user.name;
      if (f.ID === null) {
        //////////// nothing
      } else {
        this.MainObject.id = f.ID.toUpperCase();
        if (f.Date === null) {
          this.MainObject.date = this.PlaceholderDate;
        } else {
          this.MainObject.date = f.Date;
        }
        if (f.Statuses === null) {
          this.MainObject.statuses = this.PlaceholderStatuses;
        } else {
          this.MainObject.statuses = f.Statuses;
        }
        this.showspinner = true;
        /////// calling info
        this.urs.getUnderwritingMainModuleInfo(this.server, this.MainObject)
          .subscribe(
            res => {
              this.MainObject = res;
              this.Product2 = res['product'];
              this.Name2 = res['name'] + ' / ' + res['id3'] + ' / ' + res['id4'] + '; Start and Term date / active: '
                + res['startdate'] + ' - ' + res['termdate'];
              this.BillRateID2 = res['billrateid'];
              this.PFCorp2 = res['pfcorp'];
              this.PGPFTR2 = res['paygrouppayfreqtierrate'];
              this.LossRatio2 = res['lossratiotimeperiod'];
              this.PolicyYear2 = res['policyyearrate'];
              this.showspinner = false;
              this.serverInfoCalled = false;
            }, // Bind to view
            err => {
              this.showspinner = false;
            });
      }
    }
  }
  GetExcelFile(f: FormGroup): void {
    if (f['ID'] !== null && f['ID'].length >= 3) {
      const d = this.PlaceholderDate;
      const encrpt = this.ss.getCache('localStorage', 'pass', 'string');
      const envir = this.gv.get('excelfilesave', 'excelfilesave');
      if (typeof this.form.controls.fsv.value === 'undefined') {
        this.MainObject.version = 'Short version';
      } else {
        this.MainObject.version = this.ss.getFormValue(this.form.controls.fsv.value, this.Placeholderfsvs, this.fsvs, 'value', 'label');
      }
      const o = {
        version: this.MainObject.version,
        id: f['ID'].toUpperCase(),
        date: this.ss.getDateFromHTMLInput(document.getElementById('theDate')['value']),
        username: this.user.name,
        qryname: this.ss.getQueryName('M', 'MQ', 0),
        encr: encrpt,
        env: envir,
        filenameshort: f['ID'].toUpperCase() + '_' + this.user.name.replace(/\s+/g, '_') + '_' +
          this.ss.getDateStringFormat().replace(/\//g, '_') + '.xlsx',
      };
      this.showspinner2 = true;
      // window.scrollTo(0, 0);
      this.urs.getUnderwritingMainModuleExcelFile(this.server, o)
        .subscribe
        (
          res => {
            const allowedfiles = ['xlsx', 'csv'];
            const env = this.gv.get('excelfiledownload', 'excelfiledownload');
            // console.log(res);
            this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
              res1 => {
                this.showspinner2 = false;
                // --------------- Cleaning all - web and oracle - START
                for (let i = 0; i < res.length; i++) {
                  if (res[i] !== null) {
                    /////////////////////////// Cleaning server and web folder
                    const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                    // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
                    // const filenamefullpath = env + filename;
                    let vv: CleanFileAndServer;
                    if (i === 0) {
                      vv = {
                        fullfilename: res[i],
                        qryname: 'none',
                        c: 'none'
                      };
                    } else {
                      vv = {
                        fullfilename: res[i],
                        qryname: 'none',
                        c: 'none'
                      };
                    }
                    this.ss.cleanFileServer(this.server, vv).subscribe(
                      () => { }, err1 => { });
                  }
                }
                // --------------- Cleaning all - web and oracle - END
              }, err => {
                this.showspinner2 = false;
              });
          }, err => {
            this.showspinner2 = false;
          });
    }
  }
  focusFunction(f: FormGroup): void {
    // // console.log(f);
  }
  receiveFromFileService($event) {
    this.filenames = $event;
    if (this.filenames.length === 0) {
      this.showfile = false;
    } else {
      this.showfile = true;
    }
  }
}
