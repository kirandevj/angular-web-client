import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { LossRatio, Selection, UserInfo, FooterInfo } from '@app/datamodels/index';

@Component({
  templateUrl: './analytics.html',
  styles: [`
  body
  {
  background-color: #f4f4f4;
  }
    .input-block-level {
  margin-top: 3em;
  display: block;
  width: 100%;
  min-height: 28px;
  .box-sizing(border-box);
}
  `]
})
export class AnalyticsComponent implements OnInit {
  user: UserInfo;
  sendtofooter: FooterInfo;
  form: FormGroup;
  Products: Array<Selection>;
  Years: Array<Selection>;
  Months: Array<Selection>;
  Levels: Array<Selection>;
  States: Array<Selection>;
  pycys: Array<Selection>;
  yesnos: Array<Selection>;
  ClaimsAmounts: Array<Selection>;
  MonthBack: number;
  CappingAmount: number;
  PlaceholderProducts: string;
  PlaceholderYears: string;
  PlaceholderMonths: string;
  PlaceholderLevels: string;
  PlaceholderStates: string;
  Placeholderpycys: string;
  Placeholderyesnos: string;
  PlaceholderClaimsAmounts: string;
  PlaceholderMonthBack: number;
  PlaceholderCappingAmount: number;
  servercallresult: string;
  servercalled: boolean;
  server: string;
  image0: string;
  constructor(private ss: SharedServices, private gv: GlobalVariables, private route: ActivatedRoute) { }

  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.form.addControl('Product', new FormControl());
    this.form.addControl('Year', new FormControl());
    this.form.addControl('Month', new FormControl());
    this.form.addControl('Level', new FormControl());
    this.form.addControl('State', new FormControl());
    this.form.addControl('pycy', new FormControl());
    this.form.addControl('yesno', new FormControl());
    this.form.addControl('ClaimAmount', new FormControl());
    this.form.addControl('MonthBack', new FormControl());
    this.form.addControl('CappingAmount', new FormControl());
    this.Products = this.ss.getProductsAll();
    this.Years = this.ss.getYears();
    this.Months = this.ss.getMonths();
    this.Levels = this.ss.getLevelOfDataAnalyses();
    this.States = this.ss.getStatesOption();
    this.pycys = this.ss.getPyCy();
    this.yesnos = this.ss.getYesNo();
    this.ClaimsAmounts = this.ss.getClaimsAmountsStructure();
    this.MonthBack = 36;
    this.CappingAmount = 1000000;
    this.PlaceholderProducts = this.Products[0].label;
    this.PlaceholderYears = this.ss.getYearsHolderSds();
    this.PlaceholderMonths = this.ss.getMonthsHolderSds();
    this.PlaceholderLevels = this.Levels[0].label;
    this.PlaceholderStates = this.States[0].label;
    this.Placeholderpycys = this.pycys[0].label;
    this.Placeholderyesnos = this.yesnos[0].label;
    this.PlaceholderClaimsAmounts = this.ClaimsAmounts[0].label;
    this.PlaceholderMonthBack = this.MonthBack;
    this.PlaceholderCappingAmount = this.CappingAmount;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
  }
  onSubmit(formValues: any) {
    // let lr: LossRatio = {
    //   mmsback: +this.ss.getFormValueInput(+formValues.MonthBack, this.PlaceholderMonthBack, 0),
    //   asofyr: +this.ss.getFormValue(formValues.Year, this.PlaceholderYears, this.Years, 'value', 'label'),
    //   asofmm: +this.ss.getFormValue(formValues.Month, this.PlaceholderMonths, this.Months, 'value', 'label'),
    //   qryname: this.ss.getQueryName(),
    //   states: this.ss.getServerStateOption(this.ss.getFormValue(formValues.State, 
    // this.PlaceholderStates, this.States, 'value', 'label')),
    //   capping: this.ss.getFormValue(formValues.yesno, this.Placeholderyesnos, this.yesnos, 'value', 'label'),
    //   grouping: this.ss.getFormValue(formValues.ClaimAmount, this.PlaceholderClaimsAmounts, this.ClaimsAmounts, 'value', 'label'),
    //   deductopt: 'TriNet',
    //   sources: this.ss.getFormValue(formValues.Product, this.PlaceholderProducts, this.Products, 'value', 'label'),
    //   pyfy: this.ss.getServerPolicyFiscalYear(this.ss.getFormValue(formValues.pycy, this.Placeholderpycys, 
    // this.pycys, 'value', 'label')),
    //   levelanalysis: this.ss.getFormValue(formValues.Level, this.PlaceholderLevels, this.Levels, 'value', 'label'),
    //   monthlydata: 'No',
    //   cappingamount: +this.ss.getFormValueInput(+formValues.CappingAmount, this.PlaceholderCappingAmount, 0),
    //   name: this.user.name,
    //   c: this.ss.getPass()
    // };
    if (!this.servercalled) {
      this.servercalled = true;
    }
  }

}
