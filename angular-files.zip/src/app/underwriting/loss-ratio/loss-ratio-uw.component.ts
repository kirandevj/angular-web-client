import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { UnderwritingServices } from '../shared/underwriting.services';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { LossRatio, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { LocalVariables, RunProcess } from '../shared/local.variables';

@Component({
  templateUrl: './loss-ratio-uw.html',
  styles: [`
  form {
    /* color: #0000ff;
    font-size: 14px;
    line-height: 1.42857143;
    background-color: #9999ff;
    background-image: none;
    */
    display: block;
    padding: 12px 12px;
    border: 4px solid #8080ff;
    border-radius: 10px;
  }
  .nav.navbar-nav {font-size: 15px;}
  li > a { color: aliceblue; }
  `]
})
export class LossRatioUWComponent implements OnInit {
  user: UserInfo;
  sendtofooter: FooterInfo;
  form: FormGroup;
  Products: Array<Selection>;
  Years: Array<Selection>;
  Months: Array<Selection>;
  Levels: Array<Selection>;
  States: Array<Selection>;
  pycys: Array<Selection>;
  yesnos: Array<Selection>;
  yesnos_for_monthly: Array<Selection>;
  ClaimsAmounts: Array<Selection>;
  MonthBack: number;
  CappingAmount: number;
  PlaceholderProducts: string;
  PlaceholderYears: string;
  PlaceholderMonths: string;
  PlaceholderLevels: string;
  PlaceholderStates: string;
  Placeholderpycys: string;
  Placeholderyesnos: string;
  Placeholderyesnos_for_monthly: string;
  PlaceholderClaimsAmounts: string;
  PlaceholderMonthBack: number;
  PlaceholderCappingAmount: number;
  server: string;
  image0: string;
  image1: string;
  reportsInfo: boolean;
  ReportsArray: Array<RunProcess>;
  variablesHome: string;
  constructor(private uws: UnderwritingServices, private ss: SharedServices,
    private gv: GlobalVariables, private route: ActivatedRoute, private lv: LocalVariables) { }

  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.variablesHome = 'lossratiouw';
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.form.addControl('Product', new FormControl());
    this.form.addControl('Year', new FormControl());
    this.form.addControl('Month', new FormControl());
    this.form.addControl('Level', new FormControl());
    this.form.addControl('State', new FormControl());
    this.form.addControl('pycy', new FormControl());
    this.form.addControl('yesno', new FormControl());
    this.form.addControl('yesno_for_monthly', new FormControl());
    this.form.addControl('ClaimAmount', new FormControl());
    this.form.addControl('MonthBack', new FormControl());
    this.form.addControl('CappingAmount', new FormControl());
    this.Products = this.ss.getProductsAll();
    this.Years = this.ss.getYears();
    this.Months = this.ss.getMonths();
    this.Levels = this.ss.getLevelOfDataAnalyses();
    this.States = this.ss.getStatesOption();
    this.pycys = this.ss.getPyCy();
    this.yesnos = this.ss.getYesNo();
    this.yesnos_for_monthly = this.ss.getYesNo();
    this.ClaimsAmounts = this.ss.getClaimsAmountsStructure();
    this.MonthBack = 36;
    this.CappingAmount = 1000000;
    this.PlaceholderProducts = this.Products[0].label;
    this.PlaceholderYears = this.ss.getYearsHolderSds();
    this.PlaceholderMonths = this.ss.getMonthsHolderSds();
    this.PlaceholderLevels = this.Levels[0].label;
    this.PlaceholderStates = this.States[0].label;
    this.Placeholderpycys = this.pycys[0].label;
    this.Placeholderyesnos = this.yesnos[0].label;
    this.Placeholderyesnos_for_monthly = this.yesnos[1].label;
    this.PlaceholderClaimsAmounts = this.ClaimsAmounts[0].label;
    this.PlaceholderMonthBack = this.MonthBack;
    this.PlaceholderCappingAmount = this.CappingAmount;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  onSubmit(formValues: any) {
    const rr: LossRatio = {
      mmsback: +this.ss.getFormValueInputImproved(document.getElementById('mb')['value'], this.PlaceholderMonthBack),
      asofyr: +this.ss.getFormValue(formValues.Year, this.PlaceholderYears, this.Years, 'value', 'label'),
      asofmm: +this.ss.getFormValue(formValues.Month, this.PlaceholderMonths, this.Months, 'value', 'label'),
      qryname: this.ss.getQueryName('L', 'R', +this.ReportsArray.length + 1),
      states: this.ss.getServerStateOption(this.ss.getFormValue(formValues.State, this.PlaceholderStates, this.States, 'value', 'label')),
      capping: this.ss.getFormValue(formValues.yesno, this.Placeholderyesnos, this.yesnos, 'value', 'label'),
      grouping: this.ss.getFormValue(formValues.ClaimAmount, this.PlaceholderClaimsAmounts, this.ClaimsAmounts, 'value', 'label'),
      deductopt: 'TriNet',
      sources: this.ss.getFormValue(formValues.Product, this.PlaceholderProducts, this.Products, 'value', 'label')
        .replace(/–/g, '').replace(/\s+/g, '_'),
      pyfy: this.ss.getServerPolicyFiscalYear(this.ss.getFormValue(formValues.pycy, this.Placeholderpycys, this.pycys, 'value', 'label')),
      levelanalysis: this.ss.getFormValue(formValues.Level, this.PlaceholderLevels, this.Levels, 'value', 'label'),
      monthlydata: this.ss.getFormValue(formValues.yesno_for_monthly,
        this.Placeholderyesnos_for_monthly, this.yesnos_for_monthly, 'value', 'label'),
      cappingamount: +this.ss.getFormValueInput(+formValues.CappingAmount, this.PlaceholderCappingAmount, 0),
      username: this.user.name,
      c: this.ss.getPass(),
      fingerprint: '',
      filename: '',
      filenameshort: '',
      imageprocess: this.image1,
      // timeframe: this.ss.getMainTimeFrame(),
      timeframe: '',
      env: this.gv.get('excelfilesave', 'excelfilesave')
    };
    rr.fingerprint = rr.mmsback.toString() + rr.asofyr.toString() + rr.asofmm.toString() + rr.states +
      rr.capping + rr.grouping + rr.sources + rr.pyfy + rr.levelanalysis.replace(/\s+/g, '') + rr.cappingamount.toString() + rr.monthlydata;
    rr.filenameshort = rr.sources + '_LR_'
      + this.ss.getNumberToString(rr.asofmm, 2) + '_' + rr.asofyr.toString() + '_' +
      rr.levelanalysis.replace(/\s+/g, '_').replace(/-/g, '_').replace('_level', '') + '_'
      + rr.pyfy + '_' + rr.username.replace(' ', '_') + rr.timeframe + '.xlsx';
    rr.filename = rr.env + rr.filenameshort;
    if (rr.mmsback > 36) {
      rr.mmsback = 36;
    }
    const p: RunProcess = {
      name: rr.filenameshort,
      run: true,
      object: rr
    };
    // // console.log(rr);
    this.lv.add(this.variablesHome, p, rr.fingerprint);
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  runReport(r: LossRatio) {
    this.ReportsArray.forEach((e: RunProcess, i: number) => {
      if (e.object.fingerprint === r.fingerprint) {
        e.object.imageprocess = e.object.imageprocess.replace('.png', '.gif');
        this.getRiskLossRatio(e.object);
      }
    });
  }
  deleteReport(r: LossRatio) {
    this.lv.remove(this.variablesHome, r.fingerprint);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  getRiskLossRatio(v: LossRatio) {
    this.uws.getRiskLossRatio(this.server, v)
      .subscribe(
        res => {
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
              for (let i = 0; i < res.length; i++) {
                if (res[i] !== null) {
                  /////////////////////////// Cleaning server and web folder
                  const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                  // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
                  // const filenamefullpath = env + filename;
                  let vv: CleanFileAndServer;
                  if (i === 0) {
                    vv = {
                      fullfilename: res[i],
                      qryname: v.qryname,
                      c: v.c
                    };
                  } else {
                    vv = {
                      fullfilename: res[i],
                      qryname: 'none',
                      c: v.c
                    };
                  }
                  this.ss.cleanFileServer(this.server, vv).subscribe(
                    () => { }, err1 => { });
                }
              }
              // --------------- Cleaning all - web and oracle - END
            }, err => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
            });
        },
        err => { });
  }
  normalizeMMB(v: number) {
    if (v > this.PlaceholderMonthBack) {
      document.getElementById('mb')['value'] = this.PlaceholderMonthBack;
    }
  }
}
