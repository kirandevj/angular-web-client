import { Component, ViewContainerRef, OnInit, ViewEncapsulation } from '@angular/core';
import { SharedServices, GlobalVariables, ApiServices } from '@app/common/index';
import { UserInfo, FooterInfo, UsersNavigationDataLoad, WebWorkerData } from '@app/datamodels/index';
import { Router, Event, NavigationStart, NavigationEnd, NavigationError, NavigationCancel } from '@angular/router';
import { FooterComponent } from '@app/common/index';
import { Observable, Subject, Subscription } from 'rxjs';
import { map, filter, scan, catchError, mergeMap } from 'rxjs/operators';
import { ChannelService, ConnectionState, ChannelEvent } from '../services/channel.sevice';
import * as $ from 'jquery';
// import { trigger, state, style, transition, animate, keyframes } from '@angular/animations';
declare var tableau: any;
@Component({
  selector: './app-landing-tiles',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})
export class LandingComponent implements OnInit {

  // theme = 'classic';
  // source =
  //   {
  //     datatype: 'json',
  //     datafields: [
  //       { name: 'OrderDate', type: 'date' },
  //       { name: 'Quantity' },
  //       { name: 'ProductName' }
  //     ],
  //     url: 'chartdata.php'
  //   };
  // dataAdapter = new jqx.dataAdapter(this.source,
  //   {
  //     autoBind: true,
  //     async: false,
  //     downloadComplete() { },
  //     loadComplete() { },
  //     loadError() { }
  //   });
  // settings = {
  //   title: 'Orders by Date',
  //   showLegend: true,
  //   padding: { left: 5, top: 5, right: 50, bottom: 5 },
  //   titlePadding: { left: 90, top: 0, right: 0, bottom: 10 },
  //   source: this.dataAdapter,
  //   xAxis:
  //   {
  //     text: 'Category Axis',
  //     textRotationAngle: 0,
  //     dataField: 'OrderDate',
  //     type: 'date',
  //     baseUnit: 'month',
  //     formatFunction: (value) => {
  //       return jqx.dataFormat.formatdate(value, 'dd/MM/yyyy');
  //     },
  //     showTickMarks: true
  //   },
  //   colorScheme: 'scheme05',
  //   seriesGroups:
  //     [
  //       {
  //         type: 'line',
  //         valueAxis:
  //         {
  //           displayValueAxis: true,
  //           description: 'Quantity',
  //           axisSize: 'auto',
  //           tickMarksColor: '#888888',
  //           unitInterval: 20,
  //           minValue: 0,
  //           maxValue: 100
  //         },
  //         series: [
  //           { dataField: 'Quantity', displayText: 'Quantity' }
  //         ]
  //       }
  //     ]
  // };


  // title = 'Revenue 2014 YTD';
  // description = '(U.S. $ in thousands)';
  // ranges: any[] = [
  //   { startValue: 0, endValue: 200, color: '#000000', opacity: 0.5 },
  //   { startValue: 200, endValue: 250, color: '#000000', opacity: 0.3 },
  //   { startValue: 250, endValue: 300, color: '#000000', opacity: 0.1 }
  // ];
  // pointer: any = { value: 230, label: 'Revenue 2014 YTD', size: '25%', color: 'Black' };
  // target: any = { value: 260, label: 'Revenue 2013 YTD', size: 4, color: 'Black' };
  // ticks: any = { position: 'both', interval: 50, size: 10 };

  viz: any;
  values: number[] = [102, 115, 130, 137];
  connectionState$: Observable<string>;
  signalrEndPoint: string;
  showadmintasks = false;
  loading = true;
  user: UserInfo;
  sendtofooter: FooterInfo;
  server: string;
  version: string;
  image0: string;
  testingmodule: boolean;
  navigationuser: UsersNavigationDataLoad;
  constructor(
    private route: Router,
    // private vcRef: ViewContainerRef,
    private ss: SharedServices, private gv: GlobalVariables,
    private api: ApiServices,
    private channelService: ChannelService,
    // private http: HttpClient
  ) {
    route.events.subscribe((routerEvent: Event) => {
      this.checkRouterEvent(routerEvent);
    });
    // Let's wire up to the signalr observables
    //
    // Wire up a handler for the starting$ observable to log the
    //  success/fail result
    // // console.log(this.ss.getCache('sessionStorage', 'cid', 'string'));
    if (this.ss.getCache('sessionStorage', 'cid', 'string').length < 7) {
      this.connectionState$ = this.channelService.connectionState$
        .pipe(map((state: ConnectionState) => ConnectionState[state]));

      this.channelService.error$.subscribe(
        (error: any) => { console.warn(error); },
        (error: any) => { console.error('errors$ error', error); }
      );
      this.channelService.starting$.subscribe(
        () => {
          // console.log('signalr service has been started from landing');
        },
        () => { console.warn('signalr service failed to start from landing'); }
      );
    }
  }
  // initViz() {
  //   const containerDiv = document.getElementById('vizContainer');
  //   const vizUrl = 'https://public.tableau.com/views/WorldIndicators/GDPpercapita';

  //   const options = {
  //     width: containerDiv.offsetWidth,
  //     height: 600,
  //     // hideTabs: true,
  //     // hideToolbar: true,
  //     onFirstInteractive: (ev) => {
  //       // console.log(ev);
  //     }
  //   };
  //   // tslint:disable-next-line:max-line-length
  // tslint:disable-next-line:max-line-length
  //   // if (viz != null) { // viz is undefined on both the first and second page loads - even though second page load throws a 'viz already present' error
  //   //   viz.dispose();
  //   // }
  //   const viz = new tableau.Viz(containerDiv, vizUrl, options);
  // }
  ngOnInit() {
    if (typeof Worker !== 'undefined') {
      // Create a new
      const worker = new Worker('@app/services/web-workers/app.worker', { type: 'module' });
      worker.onmessage = ({ data }) => {
        // console.log(`page got message: ${data}`);
      };
      const tm: WebWorkerData = {
        id: 3,
        action: 'load',
        data: {}
      };
      worker.postMessage(tm);
    } else {
      // Web Workers are not supported in this environment.
      // You should add a fallback so that your program still executes correctly.
    }
    if (this.ss.getCache('sessionStorage', 'counter', 'string') === false ||
      this.ss.getCache('sessionStorage', 'counter', 'string') === '1') {
      this.ss.setCache('sessionStorage', 'counter', '1', 'string');
    } else {
      this.ss.setCache('sessionStorage', 'counter', '1', 'string');
      this.reloadPage();
    }
    if (this.ss.getCache('sessionStorage', 'cid', 'string').length < 7) {
    }
    this.ss.setCache('localStorage', 'pass', 'Report_34_@!_GPU', 'string');
    // const strWindowFeatures = 'menubar=yes,location=yes,resizable=yes,scrollbars=yes,status=yes';
    // window.print();
    // window.open('http://www.cnn.com/', 'CNN_WindowName', strWindowFeatures);
    // const connection = new HubConnectionBuilder()
    //   .withUrl('http://localhost:63009/signalr')
    //   .build();

    // connection.on('send', data => {
    //   // // console.log(data);
    // });

    // connection.start()
    //   // .then(() => connection.invoke('send', 'Hello', 'Test'));
    //   .then(() => // // console.log('Connection started!'))
    //   .catch(err => // // console.log(err));

    // this.sendtofooter.email = 'lyudmil.petrov@trinet.com';
    // this.sendtofooter.text = 'test';
    // // console.log(window.location);
    // // console.log(window.location.pathname);
    // console.log(window.location.origin);
    this.testingmodule = false;

    //////// This tread runs on latest
    // if (window.location.origin === 'http://localhost:4200') {
    //   this.testingmodule = true;
    //   this.server = 'test';
    // } else {
    //   //////// This tread runs on latest
    //   if (window.location.origin === 'http://localhost:4201') {
    //     this.server = 'test_core';
    //   } else {
    //     if (window.location.origin === 'http://localhost:63333') {
    //       this.server = 'test_latest';
    //     } else {
    //       if (window.location.origin === 'http://brspwferiskd1.ad.corp.local') {
    //         this.server = 'pro';
    //       } else {
    //         this.server = 'pro_sas';
    //       }
    //     }
    //   }
    //   this.testingmodule = true;
    // }
    switch (window.location.origin) {
      case 'http://localhost:4200':
        this.testingmodule = true;
        this.server = 'test';
        break;
        case 'http://localhost:61530':
        this.testingmodule = true;
        this.server = 'test';
        break;
      case 'http://brspwferiskd1.ad.corp.local':
        this.server = 'pro';
        break;
      case 'http://ausasmid01.ad.corp.local:99':
        this.server = 'pro_sas';
        break;
      default:
        this.server = 'pro';
        break;
    }
    if (this.server !== 'test_core') {
      this.ss.setCache('localStorage', 'server', this.server, 'string');
      this.gv.setenv(this.server);
      this.gv.setall();
      this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
      this.version = this.server + '_0';
      this.server = this.gv.get('api', 'api');

      this.getID();
      if (this.ss.getCache('localStorage', 'version', 'string') !== this.version) {
        // hard resolve
        this.route.navigateByUrl('/user');
        this.ss.setCache('sessionStorage', 'version', this.version, 'string');
        // this.user = this.ss.getCache('localStorage', 'user', 'object');
      } else {
        if (!this.ss.getCache('localStorage', 'pass', 'string')) {
          this.route.navigateByUrl('/user');
        } else {
          if (!this.ss.getCache('localStorage', 'user', 'string')) {
            // this.ss.getUserInfo(this.gv.get('api', 'api'), this.ss.getCache('localStorage', 'pass', 'string'))
            //   .subscribe(
            //   user => {
            //     this.user = user;
            //     this.ss.setCache('localStorage', 'user', this.user, 'object');
            //   }, // Bind to view
            //   err => {
            //     // Log errors if any
            //     // // console.log(err);
            //   });
            this.route.navigateByUrl('/user');
          } else {
            this.user = this.ss.getCache('localStorage', 'user', 'object');
          }
        }
      } 
      this.sendtofooter = {
        email: 'mailto:lyudmil.petrov@trinet.com',
        text: 'This module is supported by Actuarial and Risk departments - for support click here',
        modulesender: 'Website - Landing Page issue'
      };
      this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
      this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');

      this.navigationuser = new UsersNavigationDataLoad(this.user.name);
      // // console.log(this.navigationuser.CheckIfAllowed());
      // // console.log(this.navigationuser.allowed);
    } else {
      this.route.navigateByUrl('/eeo');
    }
    // this.showAdminTasks();
    // Start the connection

    this.signalrEndPoint = this.server + 'signalr';
    // console.log(this.signalrEndPoint);
    // console.log('If no local host add port 8080 for services');
    // console.log(this.signalrEndPoint.indexOf('localhost:4200'));
    if (this.signalrEndPoint.indexOf('localhost:63009') === -1) {
      this.signalrEndPoint = this.server.slice(0, -1).replace(':99', '') + ':98/signalr';
    }
    this.channelService.initilizeSignalR(this.signalrEndPoint, 'EventHub');
    this.channelService.start();
    this.showadmintasks = this.ss.checkIfCanUseLoading(this.user);
  }
  initViz() {
    // $('#chartContainer').jqxChart(this.settings);
    // const containerDiv = document.getElementById('vizContainer');
    // const url = 'http://public.tableau.com/views/RegionalSampleWorkbook/Stocks';
    // const options = {
    //   hideTabs: true,
    //   onFirstInteractive: () => {
    //     // console.log('Run this code when the viz has finished loading.');
    //   }
    // };

    // const viz = new tableau.Viz(containerDiv, url, options);
    // // console.log(tableau);
    // Create a viz object and embed it in the container div.
  }
  getID(): void {
    this.api.APIGetUserInfo(this.server).subscribe(
      res => {
        if (res === 'System.Security.Claims.ClaimsPrincipal' || res === 'AD\\lpetrov') {
          // this.testingmodule = true;
        } else {
          // this.testingmodule = false;
        }
        this.ss.setCache('sessionStorage', 'usertesting', res, 'string');
        this.cleanSystem();
      }, err => {
        this.cleanSystem();
        // // console.log(err);
        // this.testingmodule = false;
      });
  }
  cleanSystem(): void {
    this.api.APIMainCleanUp(this.server, this.ss.getPass()).subscribe(
      res => {
        // console.log(res);
      }, err => {
        // console.log(err);
      });
  }
  checkRouterEvent(routerEvent: Event): void {
    if (routerEvent instanceof NavigationStart) {
      this.loading = true;
    } else {
      this.loading = false;
    }
  }
  navigateToModule(r: string) {
    this.ss.navigateToModuleService(r, this.user.module, this.navigationuser);
  }
  reloadPage() {
    location.reload(true);
  }
  getWidth(): any {
    if (document.body.offsetWidth < 850) {
      return '90%';
    }
    return 850;
  }
  readCSVfile() {
    // return this.http.get(url).map((response: Response) => {
    //   return response['_body'].split('\n');
    // }).catch(this.handleError);
    // return this.http.get(url).pipe(map((response: Response) => {
    //   return response['_body'].split('\n');
    // }
    // ), catchError(this.handleError));
  }
}
