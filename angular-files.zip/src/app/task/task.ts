import { Component, OnInit, Input } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { FormControl, FormGroup } from '@angular/forms';
import { ChannelService, ChannelEvent } from '../services/channel.sevice';
import { Observable } from 'rxjs';
import { map, filter, scan, catchError, mergeMap } from 'rxjs/operators';
import { SharedServices, GlobalVariables } from '@app/common';

class StatusEvent {
    State: string;
    PercentComplete: number;
}
// http://www.syntaxsuccess.com/angular-2-samples/#/demo/spreadsheet
@Component({
    selector: 'app-task',
    templateUrl: './task.html',
    styles: [`
    form {
      /* color: #0000ff;
      font-size: 14px;
      line-height: 1.42857143;
      background-color: #9999ff;
      background-image: none;
      */
      display: block;
      padding: 12px 12px;
      border: 4px solid #8080ff;
      border-radius: 10px;
    }
    .nav.navbar-nav {font-size: 15px;}
    li > a { color: aliceblue; }
    `]
})
export class TaskComponent implements OnInit {
    server: string;
    form1: FormGroup;
    @Input() eventName: string;
    @Input() apiUrl: string;
    messages = '';
    PlaceholderMessages: string;
    private channel = 'tasks';

    constructor(
        private http: HttpClient,
        private channelService: ChannelService,
        private ss: SharedServices,
        private gv: GlobalVariables
    ) {
        // this.channelService.sub(this.channel).subscribe(
        //     (x: ChannelEvent) => {
        //         // console.log(x);
        //         switch (x.Name) {
        //             case this.eventName: { this.appendStatusUpdate(x); }
        //         }
        //     },
        //     (error: any) => {
        //         console.warn('Attempt to join channel failed!', error);
        //     }
        // );
    }
    // <app-task class="flex" [eventName]="'longTask.status'" [apiUrl]="server + 'tasks/long'"></app-task>
    ngOnInit() {
        this.server = this.ss.getCache('localStorage', 'server', 'string');
        this.gv.setenv(this.server);
        this.gv.setall();
        this.server = this.gv.get('api', 'api');
        // console.log(this.server);
        this.form1 = new FormGroup({});
        this.form1.addControl('Message', new FormControl());
        this.PlaceholderMessages = 'Process info here';
        // Get an observable for events emitted on this channel
        this.channelService.sub(this.channel).subscribe(
            (x: ChannelEvent) => {
                // console.log(x);
                switch (x.Name) {
                    case this.eventName: { this.appendStatusUpdate(x); }
                }
            },
            (error: any) => {
                console.warn('Attempt to join channel failed!', error);
            }
        );
    }


    private appendStatusUpdate(ev: ChannelEvent): void {
        // Just prepend this to the messages string shown in the textarea
        // this function is called from server
        // // console.log(ev);
        this.PlaceholderMessages = ev.Data.json;
        this.form1.controls.Message.setValue('State - ' + ev.Data.State + ' | Percent complete: ' + ev.Data.PercentComplete);

        const date = new Date();
        switch (ev.Data.State) {
            case 'starting': {
                this.messages = `${date.toLocaleTimeString()} : starting\n` + this.messages;
                break;
            }

            case 'complete': {
                this.messages = `${date.toLocaleTimeString()} : complete\n` + this.messages;
                break;
            }

            default: {
                this.messages = `${date.toLocaleTimeString()} : ${ev.Data.State} : ${ev.Data.PercentComplete} % complete\n` + this.messages;
            }
        }
        // // // console.log(this.messages);
    }

    callApi() {
        // console.log(this.apiUrl);
        // // // http://localhost:63009/tasks/long
        // this.http.post( this.server + 'api/MainAPI?tests=tests&signalr=' +
        //     this.channelService.connectionID$, '').pipe(map((r: string[]) => {
        //         // // console.log(r);
        //         return r.toString();
        //     }
        //     ), catchError((e: any) => Observable.throw(e))).subscribe((message: string) => { // console.log(message); });
        this.http.get(this.apiUrl)
            .pipe(map((res: any) => {
                // console.log(res);
                return res.toString();
            }
            ))
            .subscribe((message: string) => {
                // console.log(message); 
            });
    }
}
