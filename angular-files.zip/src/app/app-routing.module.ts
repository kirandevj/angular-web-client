import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LandingComponent } from './landing/landing.component';
import { Error404Component } from './errors/404.component';
import { DashboardRoutingModule } from './dashboards/dashboards.routes';

const routes: Routes = [
  { path: '', redirectTo: 'welcome', pathMatch: 'full' },
  { path: 'welcome', component: LandingComponent },
  { path: 'app', redirectTo: 'welcome', pathMatch: 'full' },
  { path: 'riskfinance', loadChildren: () => import('./riskfinance/risk-finance.module').then(m => m.RiskFinanceModule) },
  { path: 'riskoperations', loadChildren: () => import('./riskoperations/risk-operations.module').then(m => m.RiskOperationsModule) },
  { path: 'accounting', loadChildren: () => import('./accounting/accounting.module').then(m => m.AccountingModule) },
  { path: 'fpa', loadChildren: () => import('./fpa/fpa.module').then(m => m.FPAModule) },
  { path: 'wcpricing', loadChildren: () => import('./underwriting/underwriting.module').then(m => m.UnderwritingModule) },
  { path: 'health', loadChildren: () => import('./health/health.module').then(m => m.HealthModule) },
  { path: 'dataload', loadChildren: () => import('./dataload/dataload.module').then(m => m.DataloadModule) },
  { path: 'user', loadChildren: () => import('./user/user.module').then(m => m.UserModule) },
  { path: 'eeo', loadChildren: () => import('./eeo/eeo.module').then(m => m.EeoModule) },
  { path: 'actuarial', loadChildren: () => import('./actuarial/actuarial.module').then(m => m.ActuarialModule) },
  {
    path: 'payrollcompliance', loadChildren: () => import('./payrollcompliance/payrollcompliance.module')
      .then(m => m.PayrollComplianceModule)
  },
  { path: 'general', loadChildren: () => import('./general/general.module').then(m => m.GeneralModule) },
  {
    path: 'admin', data: { preload: false },
    loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule)
  },
  {
    path: 'dashboards', data: { preload: false },
    loadChildren: () => import('./dashboards/dashboards.module').then(m => m.DashboardsModule)
  },
  { path: '**', redirectTo: 'welcome', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    useHash: true
    // ,
    // enableTracing: true
  }), DashboardRoutingModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
