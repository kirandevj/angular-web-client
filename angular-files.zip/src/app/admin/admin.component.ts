import { Component, ViewEncapsulation, OnInit, ElementRef } from '@angular/core';
import { UserInfo } from '@app/datamodels/index';
import { SharedServices, GlobalVariables } from '@app/common/index';

@Component({
  encapsulation: ViewEncapsulation.None,
  templateUrl: './admin.html',
  styleUrls: ['./admin.css']
})
export class AdminComponent implements OnInit {
  server: string;
  user: UserInfo;
  constructor(private ss: SharedServices, private gv: GlobalVariables, private element: ElementRef
  ) { }
  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.user = this.ss.getCache('localStorage', 'user', 'object');
  }
}
