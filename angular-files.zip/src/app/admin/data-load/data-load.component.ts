import { Component, ViewEncapsulation, OnInit, ChangeDetectionStrategy, Input, ChangeDetectorRef } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { LossRatio, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { FileServices } from '../../components/files/file-action.service';
// import { HealthReportsData, RunProcess, LocalVariables } from '../../shared/datamodels';
import { AdminServices } from '../shared/admin.service';
import { FooterComponent } from '@app/common/index';
import { ChannelService, ChannelEvent } from '../../services/channel.sevice';
import { BehaviorSubject } from 'rxjs';
@Component({
  templateUrl: './data-load.html',
  styleUrls: ['./data-load.css'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class AdminDataLoadComponent implements OnInit {
  showLoading = true;
  monthsDiff = 0;
  @Input() message: ChannelEvent = {
    Name: '',
    ChannelName: '',
    Timestamp: (new Date(Date.now() - ((new Date()).getTimezoneOffset() * 60000))).toISOString().slice(0, -1),
    Data: {
      State: 'Process info here',
      PercentComplete: 0,
      json: ''
    },
    Json: ''
  };
  items: ChannelEvent[] = [];
  items2: string[] = [];
  items$ = new BehaviorSubject(this.items);
  showspinner = false;
  dataprogressinfo = 'Progress info here';
  sentToSignalRChannel = 'admindataload';
  eventName: string;
  user: UserInfo;
  sendtofooter: FooterInfo;
  sendtofileloadermessages: any[] = ['', true];
  form: FormGroup;
  form2: FormGroup;
  filenames: string[];
  showfile: boolean;
  server: string;
  image0: string;
  image1: string;
  DataSets: Array<Selection>;
  PlaceholderDataSets: string;
  FirstTimes: Array<Selection>;
  PlaceholderFirstTimes: string;
  Years: Array<Selection>;
  PlaceholderYears: string;
  Months: Array<Selection>;
  PlaceholderMonths: string;
  counter = 0;
  constructor(
    private ss: SharedServices,
    private gv: GlobalVariables,
    private route: ActivatedRoute,
    private as: AdminServices,
    private fs: FileServices,
    private channelService: ChannelService,
    private cdr: ChangeDetectorRef
  ) {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.eventName = this.sentToSignalRChannel;
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.sendtofileloadermessages[0] = this.server;
    this.sendtofileloadermessages[1] = true;
    this.sendtofileloadermessages[2] = 'admin data load';
    this.sendtofileloadermessages[3] = this.channelService.connectionID$;
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - Admin data load issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
  }
  ngOnInit() {
    this.form = new FormGroup({});
    this.form2 = new FormGroup({});
    this.form2.addControl('DataSet', new FormControl());
    this.form2.addControl('FirstTime', new FormControl());
    this.form2.addControl('Year', new FormControl());
    this.form2.addControl('Month', new FormControl());
    this.DataSets = this.ss.getDataSetsToLoad();
    this.PlaceholderDataSets = this.DataSets[0].label;
    this.FirstTimes = this.ss.getYesNo();
    this.PlaceholderFirstTimes = this.FirstTimes[0].label;
    this.Years = this.ss.getYears();
    this.PlaceholderYears = this.ss.getYearsHolderSds();
    this.Months = this.ss.getMonths();
    this.PlaceholderMonths = this.ss.getMonthsHolderSds();
    // this.eventName = this.PlaceholderDataSets.toLowerCase().replace(/\s+/g, '_');
    this.sendtofileloadermessages[4] = this.eventName;
    this.sendtofileloadermessages[5] = this.eventName;
    this.sendtofileloadermessages[6] = this.PlaceholderYears;
    this.sendtofileloadermessages[7] = this.PlaceholderMonths;
  }
  /////////////////// Data loads here
  receiveFromFileServiceLoad(files: string[]) {
    if (files.length > 0) {
      // this.sentToSignalRChannel = files[0].replace('.', '').replace(/\s+/g, '_');
      this.sendtofileloadermessages[4] = this.sentToSignalRChannel;
      this.sendtofileloadermessages[5] = this.sentToSignalRChannel;
      // this.items = [];
      // this.items2 = [];
    }
  }
  receiveFromFileServiceProgress($event: ChannelEvent) {
    if ($event.Data.State.includes('Download')) {
      this.downloadFile($event.Data.State.replace('Download - ', ''));
    } else {
      this.items.push($event);
      const x = $event.Data.State + ' | Time of execution: ' + $event.Timestamp;
      this.items2.push(x);
      // console.log(x);
      this.message = $event;
    }
    this.cdr.detectChanges();
  }
  downloadFile(filename: string) {
    const env = this.gv.get('excelfiledownload', 'excelfiledownload');
    this.ss.downloadFilesObservable([filename], env, ['xlsx']).subscribe(
      res1 => {
        // console.log(res1);
        // --------------- Cleaning all - web and oracle - END
      }, err => {
        // console.log(err);
      });
  }
  loadData() {
    this.items = [];
    // ++this.counter;
    // this.sentToSignalRChannel = this.counter.toString();
    const option = this.PlaceholderDataSets.toLowerCase().replace(/\s+/g, '_').replace(/-/g, '_')
      .replace(/___/g, '_').replace('(', '').replace(')', '');
    this.showspinner = true;
    // console.log(option);
    // this.eventName = this.PlaceholderDataSets.toLowerCase().replace(/\s+/g, '_');
    // this.sentToSignalRChannel = this.eventName;
    // switch (option) {
    //   case 'clients':
    //   case 'normalize_data_sets':
    //   case 'rates_progression':
    this.as.loadHRLITERFromServer(this.server, this.channelService.connectionID$, this.user.machine, this.eventName, option,
      this.PlaceholderFirstTimes,
      +this.PlaceholderYears, +this.PlaceholderMonths,
      this.ss.getPass()).subscribe(
        res => {
          // console.log(res);
          this.showspinner = false;
        },
        err => { }
      );
    return;
    //   default:
    //     return;
    // }
  }
  selected(value: any, option: string): void {
    this.items = [];
    if (option === 'dataset') {
      this.PlaceholderDataSets = value.label;
      // this.eventName = this.PlaceholderDataSets.toLowerCase().replace(/\s+/g, '_');
    } else {
      if (option === 'as_of_yr') {
        this.PlaceholderYears = value.label;
      } else {
        if (option === 'as_of_mm') {
          this.PlaceholderMonths = value.label;
        } else {
          this.PlaceholderFirstTimes = this.PlaceholderDataSets.toLowerCase();
        }
      }
      // // console.log(this.selected);
      this.sendtofileloadermessages[4] = this.eventName;
      this.sendtofileloadermessages[5] = this.eventName;
      this.sendtofileloadermessages[6] = this.PlaceholderYears;
      this.sendtofileloadermessages[7] = this.PlaceholderMonths;
      this.sendtofileloadermessages[8] = this.PlaceholderFirstTimes;
    }
    const Dt = new Date();
    const nowDt = new Date(Dt.getFullYear(), Dt.getMonth() + 1, 1);
    const priorDt = new Date(+this.PlaceholderYears, +this.PlaceholderMonths, 1);
    this.monthsDiff = this.ss.monthDiff(priorDt, nowDt);
    if (this.monthsDiff > 1) {
      // this.showLoading = false;
    } else {
      this.showLoading = true;
    }
  }
  ////////////////// Data loads end here
}
