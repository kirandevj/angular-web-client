import { Router, ActivatedRouteSnapshot, CanActivate } from '@angular/router';
import { Injectable } from '@angular/core';
import { AdminServices } from './shared/admin.service';

@Injectable()
export class AdminActivator implements CanActivate {
  loading = true;
  constructor(private rfs: AdminServices, private router: Router) {
  }
  canActivate(router: ActivatedRouteSnapshot) {
    const routExists = !!this.rfs.getRout(router.url[0].toString());
    // // console.log(router.url);
    // tslint:disable-next-line:curly
    if (!routExists) this.router.navigate(['/404']);
    return routExists;
  }
}
