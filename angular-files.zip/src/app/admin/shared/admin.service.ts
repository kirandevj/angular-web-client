import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SharedServices } from '@app/common/index';
// Import RxJs required methods
import { map, filter, scan, catchError, mergeMap } from 'rxjs/operators';
import {
  routs, MonthlyVariance, LossRatio, InternalPricing, Wccsr, WageAnalysis, ThirdPartyDeliverables,
  PreloadedIDsInfoProcess, ESAC
} from '@app/datamodels/index';
import { RunProcessObject } from './local.variables';
@Injectable()
export class AdminServices {
  constructor(private http: HttpClient, private ss: SharedServices) { }
  getRouts = (): string[] => routs;
  getRout(r: string) {
    return routs.find(rout => rout.url === r);
  }
  loadHRLITERFromServer(api: string, connectionid: string, machinename: string, channel: string, eventname: string,
    firstime: string, as_of_yr: number, as_of_mm: number,
    encrk: string) {
    // api/DataLoad?processclients={processclients}&signalr={signalr}
    const apiPoint = api + 'api/DataLoad?machinename=' + machinename + '&channel=' + channel + '&eventname=' + eventname
      + '&firstime=' + firstime + '&as_of_yr=' + as_of_yr + '&as_of_mm=' + as_of_mm
      + '&signalr=' + connectionid + '&encrk=' + encrk;
    // console.log(apiPoint);
    return this.http.post(apiPoint, '').pipe(map((r: string[]) => {
      // console.log('observable returning');
      // console.log(r);
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));
  }
}




