import { AdminComponent } from './admin.component';
import { AdminDataLoadComponent } from './data-load/data-load.component';
export const AdminRoutes = [
  { path: '', component: AdminComponent },
  { path: 'Admin', component: AdminComponent },
  { path: 'data-load', component: AdminDataLoadComponent }
];
