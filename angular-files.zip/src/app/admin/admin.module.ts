import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SelectModule } from 'angular2-select';
import { AdminNavBarComponent } from './nav/admin-navbar.component';
import { AdminComponent } from './admin.component';
import { AdminDataLoadComponent } from './data-load/data-load.component';
import { AdminRoutes } from './admin.routes';
import { LocalVariables } from './shared/local.variables';
import { AdminServices } from './shared/admin.service';
import { SpinnerModule } from '@app/common/index';
import { FileActionModule } from '../components/files/file-action.module';
import { PreLoadedModule } from '../components/preloaded/pre-loaded.module';
import { ProgressInfoModule } from '../components/progress-info/progress-info.module';
import { FooterModule } from '@app/common/index';
@NgModule({
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(AdminRoutes),
    SelectModule,
    SpinnerModule,
    FileActionModule,
    PreLoadedModule,
    FooterModule,
    ProgressInfoModule
  ],
  declarations: [
    AdminComponent,
    AdminNavBarComponent,
    AdminDataLoadComponent
  ],
  providers: [
    AdminServices,
    LocalVariables
  ]
})
export class AdminModule { }
