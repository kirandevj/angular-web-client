import { Component, OnInit } from '@angular/core';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { UserInfo } from '@app/datamodels/index';

@Component({
  selector: './app-admin-nav-bar',
  templateUrl: './admin-navbar.html',
  styles: [`
    .nav.navbar-nav {font-size: 15px;}
    li > a { color: aliceblue; }
  `]
})
export class AdminNavBarComponent implements OnInit {
  user: UserInfo;
  image0: string;
  server: string;
  constructor(private ss: SharedServices, private gv: GlobalVariables) {
  }
  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    if (!this.ss.getCache('localStorage', 'user', 'string')) {
      this.getUserInfo();
    } else {
      this.user = this.ss.getCache('localStorage', 'user', 'object');
    }
  }
  getUserInfo() {
    // Get all comments
    this.ss.getUserInfo()
      .subscribe(
      user => { this.user = user; this.ss.setCache('localStorage', 'user', this.user, 'object'); }, // Bind to view
      err => {
        // Log errors if any
        // // console.log(err);
      });
  }
  // let dialog = this.modal.confirm()
  //   .title('Get pass')
  //   .body(`
  //   <label>Enter pass phrase</label>
  //   <input class="form-control" type="text" #answer autofocus>
  //   `
  //   )
  //   .okBtn('Save')
  //   .cancelBtn('Cancel')
  //   .open()
  //   .catch(
  //   err => alert("ERROR")) // catch error not related to the result (modal open...)
  //   .then(
  //   dialog => dialog.result) // dialog has more properties,lets just return the promise for a result.
  //   .then(
  //   result => {
  //     alert("SAVED")
  //   })
  //   .catch(
  //   err => alert("CANCELED"));
  // this.modal.alert()
  //   .size('lg')
  //   .showClose(true)
  //   .title('A simple Alert style modal window')
  //   .body(`
  //     <label>Name</label> <input class="form-control" type="text" #answer autofocus>
  //    `)
  //   .open();
  //  return this.modal.open(GetPassModal,  overlayConfigFactory({ num1: 2, num2: 3 }, BSModalContext));

}
