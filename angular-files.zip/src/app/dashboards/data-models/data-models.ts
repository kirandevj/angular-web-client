export interface LineChart {
    labels?: string[];
    datasets?: DataLineChart[];
    title?: string;
    index?: number;
    width?: number;
    height?: number;
}
export interface DataLineChart {
    data?: number[];
    label?: string;
    borderColor?: string | string[];
    fill?: boolean;
}
export interface BarChart {
    labels?: string[];
    datasets?: DataBarChart[];
    title?: string;
    index?: number;
    width?: number;
    height?: number;
}
export interface DataBarChart {
    data?: number[];
    label?: string;
    fill?: boolean;
    backgroundColor?: string | string[];
    borderColor?: string | string[];
    borderWidth?: number;
}
export interface SliderInfo {
    min?: number;
    max?: number;
    id?: number;
    latestyear?: number;
    latestmonth?: number;
    returnedyear?: number;
    returnedmonth?: number;
    returneddate?: string;
}
export interface ChartInfo {
    id?: number;
    type?: string;
    width?: number;
    height?: number;
    style?: string;
}
export interface IDataBSTYE {
    report_run?: string;
    covered_period?: string;
    exchange?: string;
    exchange_order?: number;
    r12_yr?: string;
    r12_yr_o?: number;
    claims?: number;
    premiums?: number;
    payin_rate?: number;
    emp_enroll?: number;
    mem_enroll?: number;
    rx_claims?: number;
    capitation?: number;
    claims_ibnr?: number;
    admin_on_premiums?: number;
    net_ibnr?: number;
    mod_loss_ratio?: number;
    loss_ratio?: number;
}
