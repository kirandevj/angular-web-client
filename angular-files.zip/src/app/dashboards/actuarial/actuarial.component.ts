import { AfterViewChecked, AfterViewInit, Component, Directive, ElementRef, Input, OnDestroy, OnInit, QueryList, ViewChild } from '@angular/core';
import { map } from 'rxjs/operators';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { ElementDiv } from '@app/datamodels/main.model';
// import * as pc_8_20 from '../json/PREMSCLAIMS_11_2020.json';
import { APIsService, JSONFile } from '../services/api-services';
import { HttpClient } from '@angular/common/http';
import { DataWorker } from '../services/data.worker';
import { Subscription } from 'rxjs';
import { IDataBSTYE, LineChart, DataLineChart, SliderInfo, ChartInfo } from '../data-models/data-models';
import { GenericCharsServices, ObservablesAsService, HSLAObject, GeneralServices } from '../services/data-service';
@Component({
  templateUrl: './actuarial.component.html',
  styleUrls: ['./actuarial.component.css'],
  providers: [APIsService]
})
export class ActuarialComponent implements OnInit, AfterViewInit, OnDestroy {
  // https://blog.angular-university.io/angular-debugging/
  // https://tobiasahlin.com/blog/chartjs-charts-to-get-you-started/#2-line-chart
  forSlider_Min: number;
  forSlider_Max: number;
  forSlider_LatestYear: number;
  forSlider_LatestMonth: number;
  forSlider_1: SliderInfo = {
    id: 1
  };
  dataYE: IDataBSTYE[] = [];
  arrayDataYE: IDataBSTYE[][] = [];
  dataLine1: LineChart = {};
  d1CI: ChartInfo = {};
  d2CI: ChartInfo = {};
  // d1: HTMLElement;
  // d1g: HTMLElement;
  // d2g: HTMLElement;
  // d1hw = '1,black,';
  // d1ghw = '1,black,';
  // d2ghw = '2,black,';
  error: any;
  headers: string[];
  _jsonFile: JSONFile;
  _jsonBaseURL = 'assets/json/';
  result = 0;
  Line_Loss_Ratio_e_y: LineChart[] = [];
  Line_Loss_Ratio_e_y_Subscription: Subscription;
  Line_Visible_1: LineChart[] = [];
  Line_Visible_1_Subscription: Subscription;
  Slider_Data_1: SliderInfo = {};
  Slider_Data_Subscription_1: Subscription;
  /** Based on the screen size, switch from standard to one column per row */
  cards = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
    map(({ matches }) => {
      if (matches) {
        return [
          { title: 'Card 1', cols: 1, rows: 1 },
          { title: 'Card 2', cols: 1, rows: 1 },
          { title: 'Card 3', cols: 1, rows: 1 },
          { title: 'Card 4', cols: 1, rows: 1 }
        ];
      }

      return [
        { title: 'Card 1', cols: 2, rows: 1 },
        { title: 'Card 2', cols: 1, rows: 1 },
        { title: 'Card 3', cols: 1, rows: 2 },
        { title: 'Card 4', cols: 1, rows: 1 }
      ];
    })
  );
  cardLayout = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
    map(({ matches }) => {
      if (matches) {
        return {
          columns: 1,
          miniCard: { cols: 1, rows: 1 },
          chart: { cols: 1, rows: 2 },
          table: { cols: 1, rows: 4 },
        };
      }

      return {
        columns: 4,
        miniCard: { cols: 1, rows: 1 },
        chart: { cols: 2, rows: 2 },
        table: { cols: 4, rows: 4 },
      };
    })
  );
  constructor(
    private GS: GeneralServices,
    private breakpointObserver: BreakpointObserver,
    private APIs: APIsService,
    private OAS: ObservablesAsService) {
    this.initilizeAll();
    this.Line_Loss_Ratio_e_y_Subscription = this.OAS.arrayGraphLineLossRatio_e_y.subscribe(x => {
      // // // console.log(x);
      if (x.length > 0) {
        this.Line_Loss_Ratio_e_y = x;
      }
    });
    this.Slider_Data_Subscription_1 = this.OAS.objectSliderBar_1.subscribe((x: SliderInfo) => {
      if (Object.keys(x).length !== 0) {
        this.Slider_Data_1 = x;
        this.updateData(this.Slider_Data_1);
      }
    });
  }
  ngOnDestroy() {
    if (this.Line_Loss_Ratio_e_y_Subscription) {
      this.Line_Loss_Ratio_e_y_Subscription.unsubscribe();
    }
    if (this.Slider_Data_Subscription_1) {
      this.Slider_Data_Subscription_1.unsubscribe();
    }
  }
  ngOnInit() { }
  ngAfterViewInit(): void {
    // setTimeout(() => {
    //   this.d9 = document.getElementById('d9');
    //   this.d9hw += this.d9.offsetHeight + ',' + this.d9.offsetWidth;
    //   this.dataLine1.width = +this.d9.offsetWidth;
    //   this.dataLine1.height = +this.d9.offsetHeight;
    //   this.OAS.changeGraphLine(this.dataLine1, 'GraphLineVisible_1');
    //   // // // console.log(this.d9hw);
    //   this.d1g = document.getElementById('dg1');
    //   // // // console.log(this.d1g.scrollHeight);
    //   this.d1ghw += this.d1g.offsetHeight + ',' + this.d1g.offsetWidth;
    //   // // // console.log(this.d1ghw);
    //   // this.d2g = document.getElementById('dg5');
    //   // this.d2ghw += this.d2g.offsetHeight + ',' + this.d2g.offsetWidth;
    //   // // // // console.log(this.d2ghw);
    // }, 200);
  }
  showJSON(filepath: string) {
    this.APIs.getJSON(filepath)
      .subscribe(
        (data: JSONFile) => {
          this._jsonFile = { ...data };
          // // // console.log(data);
        }, // success path
        error => this.error = error // error path
      );
  }
  showJSON_v1(filepath: string) {
    this.APIs.getJSON_1(filepath)
      .subscribe((data: JSONFile) => this._jsonFile = {
        Url: data.Url,
        textfile: data.textfile
      });
  }
  showJSON_v2(filepath: string) {
    this.APIs.getJSON(filepath)
      // clone the data object, using its known Config shape
      .subscribe((data: JSONFile) => this._jsonFile = { ...data });
  }
  showJSONResponse(filepath: string) {
    this.APIs.getJSONResponse(filepath)
      // resp is of type `HttpResponse<JSONFile>`
      .subscribe(resp => {
        // display its headers
        const keys = resp.headers.keys();
        this.headers = keys.map(key =>
          `${key}: ${resp.headers.get(key)}`);
        // access the body directly, which is typed as `JSONFile`.
        this._jsonFile = { ...resp.body };
      });
  }
  initilizeAll() {
    // https://hslpicker.com/
    const color = 'hsla(0, 0%, 29%, 0.84)';
    this.d1CI.id = 1;
    this.d1CI.type = 'Line';
    this.d1CI.style = color;
    this.d2CI.id = 1;
    this.d2CI.type = 'Bar';
    this.d2CI.style = color;
    this.forSlider_Min = 1;
    this.forSlider_Max = 12;

    const d = new Date();
    d.setMonth(d.getMonth() - 1);
    this.forSlider_LatestYear = d.getFullYear();
    this.forSlider_LatestMonth = d.getMonth() + 1;
    this.forSlider_1.latestmonth = this.forSlider_LatestMonth;
    this.forSlider_1.latestyear = this.forSlider_LatestYear;
    this.forSlider_1.min = this.forSlider_Min;
    this.forSlider_1.max = this.forSlider_Max;
    const fileURL1 = this._jsonBaseURL + 'PREMSCLAIMS_Y_E_' + this.forSlider_LatestMonth + '_' + this.forSlider_LatestYear + '.json';
    this.OAS.readJSONToText(fileURL1, 'By Exchange By Years', 'Line', 1, 'exchange', 'r12_yr', 'mod_loss_ratio');
  }
  updateData(x: SliderInfo) {
    const fileURL1 = this._jsonBaseURL + 'PREMSCLAIMS_Y_E_' + x.returnedmonth + '_' + x.returnedyear + '.json';
    this.OAS.readJSONToText(fileURL1, 'By Exchange By Years', 'Line', 1, 'exchange', 'r12_yr', 'mod_loss_ratio');
  }
}
