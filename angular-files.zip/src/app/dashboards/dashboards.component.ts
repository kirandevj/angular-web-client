import { Component, ViewContainerRef, OnInit, ViewEncapsulation } from '@angular/core';
import { SharedServices, GlobalVariables, ApiServices } from '@app/common/index';
import { UserInfo, FooterInfo, UsersNavigationDataLoad, WebWorkerData } from '@app/datamodels/index';
import { Router, Event, NavigationStart, NavigationEnd, NavigationError, NavigationCancel } from '@angular/router';
import { FooterComponent } from '@app/common/index';
import { Observable, Subject, Subscription } from 'rxjs';
import { map, filter, scan, catchError, mergeMap } from 'rxjs/operators';
import { ChannelService, ConnectionState, ChannelEvent } from '../services/channel.sevice';
import * as $ from 'jquery';
// import { trigger, state, style, transition, animate, keyframes } from '@angular/animations';
declare var tableau: any;
@Component({
  templateUrl: './dashboards.html',
  styleUrls: ['./dashboards.css']
})
export class DashboardsComponent implements OnInit {

  viz: any;
  values: number[] = [102, 115, 130, 137];
  connectionState$: Observable<string>;
  signalrEndPoint: string;
  showadmintasks = false;
  loading = true;
  user: UserInfo;
  sendtofooter: FooterInfo;
  server: string;
  version: string;
  image0: string;
  testingmodule: boolean;
  navigationuser: UsersNavigationDataLoad;
  constructor(
    private route: Router,
    // private vcRef: ViewContainerRef,
    private ss: SharedServices, private gv: GlobalVariables,
    private api: ApiServices,
    private channelService: ChannelService,
    // private http: HttpClient
  ) {
    route.events.subscribe((routerEvent: Event) => {
      // console.log(routerEvent);
      this.checkRouterEvent(routerEvent);
    });
    // Let's wire up to the signalr observables
    //
    // Wire up a handler for the starting$ observable to log the
    //  success/fail result
    // // // console.log(this.ss.getCache('sessionStorage', 'cid', 'string'));
    if (this.ss.getCache('sessionStorage', 'cid', 'string').length < 7) {
      this.connectionState$ = this.channelService.connectionState$
        .pipe(map((state: ConnectionState) => ConnectionState[state]));

      this.channelService.error$.subscribe(
        (error: any) => { console.warn(error); },
        (error: any) => { console.error('errors$ error', error); }
      );
      this.channelService.starting$.subscribe(
        () => {
          // // console.log('signalr service has been started from landing');
        },
        () => { console.warn('signalr service failed to start from landing'); }
      );
    }
  }
  ngOnInit() {
    if (this.ss.getCache('sessionStorage', 'counter', 'string') === false ||
      this.ss.getCache('sessionStorage', 'counter', 'string') === '1') {
      this.ss.setCache('sessionStorage', 'counter', '1', 'string');
    } else {
      this.ss.setCache('sessionStorage', 'counter', '1', 'string');
      this.reloadPage();
    }
    if (this.ss.getCache('sessionStorage', 'cid', 'string').length < 7) {
    }
    this.ss.setCache('localStorage', 'pass', 'Report_34_@!_GPU', 'string');
    this.testingmodule = false;
    switch (window.location.origin) {
      case 'http://localhost:4200':
        this.testingmodule = true;
        this.server = 'test';
        break;
      case 'http://brspwferiskd1.ad.corp.local':
        this.server = 'pro';
        break;
      case 'http://ausasmid01.ad.corp.local:99':
        this.server = 'pro_sas';
        break;
      default:
        this.server = 'pro';
        break;
    }
    if (this.server !== 'test_core') {
      this.ss.setCache('localStorage', 'server', this.server, 'string');
      this.gv.setenv(this.server);
      this.gv.setall();
      this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
      this.version = this.server + '_0';
      this.server = this.gv.get('api', 'api');

      this.getID();
      if (this.ss.getCache('localStorage', 'version', 'string') !== this.version) {
        // hard resolve
        this.route.navigateByUrl('/user');
        this.ss.setCache('sessionStorage', 'version', this.version, 'string');
        // this.user = this.ss.getCache('localStorage', 'user', 'object');
      } else {
        if (!this.ss.getCache('localStorage', 'pass', 'string')) {
          this.route.navigateByUrl('/user');
        } else {
          if (!this.ss.getCache('localStorage', 'user', 'string')) {
            // this.ss.getUserInfo(this.gv.get('api', 'api'), this.ss.getCache('localStorage', 'pass', 'string'))
            //   .subscribe(
            //   user => {
            //     this.user = user;
            //     this.ss.setCache('localStorage', 'user', this.user, 'object');
            //   }, // Bind to view
            //   err => {
            //     // Log errors if any
            //     // // // console.log(err);
            //   });
            this.route.navigateByUrl('/user');
          } else {
            this.user = this.ss.getCache('localStorage', 'user', 'object');
          }
        }
      }
      this.sendtofooter = {
        email: 'mailto:lyudmil.petrov@trinet.com',
        text: 'This module is supported by Actuarial and Risk departments - for support click here',
        modulesender: 'Website - Landing Page issue'
      };
      this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
      this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');

      this.navigationuser = new UsersNavigationDataLoad(this.user.name);
      // // // console.log(this.navigationuser.CheckIfAllowed());
      // // // console.log(this.navigationuser.allowed);
    } else {
      this.route.navigateByUrl('/eeo');
    }
    // this.showAdminTasks();
    // Start the connection

    this.signalrEndPoint = this.server + 'signalr';
    // // console.log(this.signalrEndPoint);
    // // console.log('If no local host add port 8080 for services');
    // // console.log(this.signalrEndPoint.indexOf('localhost:4200'));
    if (this.signalrEndPoint.indexOf('localhost:63009') === -1) {
      this.signalrEndPoint = this.server.slice(0, -1).replace(':99', '') + ':98/signalr';
    }
    this.channelService.initilizeSignalR(this.signalrEndPoint, 'EventHub');
    this.channelService.start();
    this.showadmintasks = this.ss.checkIfCanUseLoading(this.user);
  }
  getID(): void {
    this.api.APIGetUserInfo(this.server).subscribe(
      res => {
        if (res === 'System.Security.Claims.ClaimsPrincipal' || res === 'AD\\lpetrov') {
          // this.testingmodule = true;
        } else {
          // this.testingmodule = false;
        }
        this.ss.setCache('sessionStorage', 'usertesting', res, 'string');
        this.cleanSystem();
      }, err => {
        this.cleanSystem();
        // // // console.log(err);
        // this.testingmodule = false;
      });
  }
  cleanSystem(): void {
    this.api.APIMainCleanUp(this.server, this.ss.getPass()).subscribe(
      res => {
        // // console.log(res);
      }, err => {
        // // console.log(err);
      });
  }
  checkRouterEvent(routerEvent: Event): void {
    if (routerEvent instanceof NavigationStart) {
      this.loading = true;
    } else {
      this.loading = false;
    }
  }
  navigateToModule(r: string) {
    this.ss.navigateToModuleService(r, this.user.module, this.navigationuser);
  }
  reloadPage() {
    location.reload(true);
  }
  getWidth(): any {
    if (document.body.offsetWidth < 850) {
      return '90%';
    }
    return 850;
  }
  readCSVfile() {
    // return this.http.get(url).map((response: Response) => {
    //   return response['_body'].split('\n');
    // }).catch(this.handleError);
    // return this.http.get(url).pipe(map((response: Response) => {
    //   return response['_body'].split('\n');
    // }
    // ), catchError(this.handleError));
  }
}
