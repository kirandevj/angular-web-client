import { throwError as observableThrowError, Observable, from, BehaviorSubject, Subject, Subscription, AsyncSubject, of } from 'rxjs';
import { Injectable, Optional, SkipSelf } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { LineChart, DataLineChart, IDataBSTYE, BarChart, DataBarChart, SliderInfo } from '../data-models/data-models';
import { map, filter, scan, catchError, mergeMap, debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

export interface HSLAObject {
    hue: number;
    saturation: number;
    lightness: number;
    alpha: number;
    HSLAValue: string;
}
@Injectable({ providedIn: 'root' })
export class GenericCharsServices {
    constructor(@Optional() @SkipSelf() parentModule: GenericCharsServices
    ) {
        if (parentModule) {
            throw new Error(
                'CoreModule is already loaded. Import it in the AppModule only');
        }
    }
    // https://www.kirupa.com/html5/generating_random_colors.htm
    // var h_range = [55, 65];
    // var s_range = [90, 100];
    // var l_range = [50, 95];
    // var a_range = [1, 1];
    // var yellowColor = getRandomColor(h_range, s_range, l_range, a_range);
    // 0 to 45 degree is Red, Orange, Yellow
    // 45 to 90 is Orange, Yellow, Green,
    // 90 to 135 is Green
    // 135 to 180 Green, Blue,
    // 180 to 225 Green, Blue
    // 225 to 270 Blue, Purple
    // 270 to 315 Purple, Red
    // 315 to 360 Red, Orange

    getRandomNumber(low: number, high: number): number {
        return Math.floor(Math.random() * (high - low + 1)) + low;
    }
    getHSLAColor(h: number, s: number, l: number, a: number): string {
        return `hsl(${h}, ${s}%, ${l}%, ${a})`;
    }
    getSimpleRandomColor(): string {
        const characters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) {
            color += characters[this.getRandomNumber(0, 15)];
        }
        return color;
    }
    getRandomColor() {
        const color = Math.floor(0x1000000 * Math.random()).toString(16);
        return '#' + ('000000' + color).slice(-6);
    }
    getHSLARandomColor(h: number[], s: number[], l: number[], a: number[]): HSLAObject {
        const hue = this.getRandomNumber(h[0], h[1]);
        const saturation = this.getRandomNumber(s[0], s[1]);
        const lightness = this.getRandomNumber(l[0], l[1]);
        const alpha = this.getRandomNumber(a[0] * 100, a[1] * 100) / 100;
        const objectR: HSLAObject = {} as HSLAObject;
        objectR.hue = hue;
        objectR.saturation = saturation;
        objectR.lightness = lightness;
        objectR.alpha = alpha;
        objectR.HSLAValue = this.getHSLAColor(hue, saturation, lightness, alpha);
        // // // // console.log(objectR);
        return objectR;
    }
    // HSLA
    // hue, saturation, lightness, alpha.
    // Hue is the actual color you are going for, and it is represented in terms of a color wheel:
    // Saturation refers to how intense the color appears, and it goes from a value of 0 to 100:
    // The next value you specify is something known as lightness.
    // Imagine you have a bright white light that you can shine onto a color.
    // A value of 0 means that none of that light shines onto our color. It is the equivalent of complete darkness.
    // A value of 100 means the full wrath of that light shines onto our color to simulate complete brightness:
    // The alpha value describes how transparent our color will be. A value of 0 is full transparency, and value of 1 is full opacity:
}
@Injectable({ providedIn: 'root' })
export class ObservablesAsService {

    GraphLineLossRatio_e_y: LineChart[] = [];
    private GraphLineLossRatio_e_y_Init = new BehaviorSubject<LineChart[]>(this.GraphLineLossRatio_e_y);
    arrayGraphLineLossRatio_e_y = this.GraphLineLossRatio_e_y_Init.asObservable();
    GraphBarLossRatio_e_y: BarChart[] = [];
    private GraphBarLossRatio_e_y_Init = new BehaviorSubject<BarChart[]>(this.GraphBarLossRatio_e_y);
    arrayGraphBarLossRatio_e_y = this.GraphBarLossRatio_e_y_Init.asObservable();

    GraphLineVisible_1: LineChart = {};
    private GraphLineVisible_1_Init = new BehaviorSubject<LineChart>(this.GraphLineVisible_1);
    arrayGraphLineVisible_1 = this.GraphLineVisible_1_Init.asObservable();
    GraphBarVisible_1: BarChart = {};
    private GraphBarVisible_1_Init = new BehaviorSubject<BarChart>(this.GraphBarVisible_1);
    arrayGraphBarVisible_1 = this.GraphBarVisible_1_Init.asObservable();
    SliderBar_1: SliderInfo = {};
    private SliderBar_1_Init = new BehaviorSubject<SliderInfo>(this.SliderBar_1);
    objectSliderBar_1 = this.SliderBar_1_Init.asObservable();

    constructor(@Optional() @SkipSelf() parentModule: ObservablesAsService,
        private httpClient: HttpClient,
        private GCS: GenericCharsServices
    ) {
        if (parentModule) {
            throw new Error(
                'CoreModule is already loaded. Import it in the AppModule only');
        }
    }
    // GraphLineLossRatio_e_y, GraphLineVisible_1
    changeGraphLine(data: LineChart, key: string) {
        this[key] = data;
        this[key + '_Init'].next(data);
    }
    changeGraphBar(data: BarChart, key: string) {
        this[key] = data;
        this[key + '_Init'].next(data);
    }
    // SliderBar_1
    changeSliderInfo(data: SliderInfo, id: number) {
        const key = 'SliderBar_' + id;
        // console.log(JSON.stringify(this[key]) === JSON.stringify(data));
        // if (data.id === this[key]['id'] &&
        //     data.returneddate !== this[key]['returneddate']
        // ) {
        this[key] = data;
        this[key + '_Init'].next(data);
        // }
    }
    readJSONToText(fileURL: string, charttitle: string, charttype: string, chartid: number,
        keyfordatasets: string,
        keyforlables: string, keyforpresenteddata: string) {
        this.fileExists(fileURL).subscribe(x => {
            console.log(x);
            if (x) {
                this.httpClient.get(fileURL).subscribe(d => {
                    this.convertToLineChartObservableYE(JSON.parse(JSON.stringify(d)), charttitle,
                        charttype, chartid, keyfordatasets, keyforlables, keyforpresenteddata);
                    this.convertToBarChartObservableYE(JSON.parse(JSON.stringify(d)), charttitle,
                        'Bar', chartid, keyfordatasets, keyforlables, keyforpresenteddata);
                        // add return !!!!!!!!!!!!!!!!!!!
                    return JSON.stringify(d);
                });
            } else {
                this.convertToLineChartObservableYE(JSON.parse(JSON.stringify([])), charttitle,
                    charttype, chartid, keyfordatasets, keyforlables, keyforpresenteddata);
                this.convertToBarChartObservableYE(JSON.parse(JSON.stringify([])), charttitle,
                    'Bar', chartid, keyfordatasets, keyforlables, keyforpresenteddata);
                return JSON.stringify([]);
            }
        });
    }
    fileExists(url: string): Observable<boolean> {
        return this.httpClient.get(url)
            .pipe(
                map(() => {
                    return true;
                }),
                catchError(() => {
                    return of(false);
                })
            );
    }
    convertToLineChartObservableYE(data: IDataBSTYE[], charttitle: string,
        charttype: string, chartid: number,
        keyfordatasets: string,
        keyforlables: string, keyforpresenteddata: string) {
        const dataLine: LineChart = {};
        dataLine.datasets = [];
        const datasetsInfo = [...new Set(data.map(x => x[keyfordatasets]))].filter(x => x !== undefined);
        const lables = [...new Set(data.map(x => {
            if (x[keyfordatasets] === datasetsInfo[0]) {
                // // // // console.log(x[keyforlables].length);
                return x[keyforlables];
            }
        }))].filter(x => x !== undefined);
        dataLine.labels = lables;
        const baseColorStep = 360 / datasetsInfo.length;
        let cI = 0;
        datasetsInfo.map(y => {
            // // // // console.log(y);
            const datasetsFoDataLine: DataLineChart = {};
            const dataN = [];
            data.map(x => {
                if (x[keyfordatasets] === y) {
                    dataN.push(x[keyforpresenteddata]);
                    datasetsFoDataLine.label = y;
                }
            });
            datasetsFoDataLine.data = dataN;
            // // // // console.log(datasetsFoDataLine.data);
            datasetsFoDataLine.fill = true;
            // HSLA
            // hue, saturation, lightness, alpha.
            // Hue is the actual color you are going for, and it is represented in terms of a color wheel:
            // Saturation refers to how intense the color appears, and it goes from a value of 0 to 100:
            // The next value you specify is something known as lightness.
            // Imagine you have a bright white light that you can shine onto a color.
            // A value of 0 means that none of that light shines onto our color. It is the equivalent of complete darkness.
            // A value of 100 means the full wrath of that light shines onto our color to simulate complete brightness:
            // The alpha value describes how transparent our color will be.
            // A value of 0 is full transparency, and value of 1 is full opacity:
            // const h_range = [135, 315];
            // const s_range = [90, 100];
            // const l_range = [50, 95];
            // const a_range = [1, 1];
            const h_range = [cI * baseColorStep, ((cI + 1) * baseColorStep) - 1];
            const s_range = [70, 80];
            const l_range = [70, 80];
            const a_range = [1, 1];
            const baseColor = this.GCS.getHSLARandomColor(h_range, s_range, l_range, a_range);
            cI += 1;
            datasetsFoDataLine.borderColor = baseColor.HSLAValue;
            dataLine.datasets.push(datasetsFoDataLine);
        });
        dataLine.title = charttitle;
        dataLine.index = chartid;
        const stringPassed = 'Graph' + charttype + 'Visible_' + chartid;
        console.log(stringPassed);
        this.changeGraphLine(dataLine, stringPassed);
        // // // // console.log(dataLine);
    }
    convertToBarChartObservableYE(data: IDataBSTYE[], charttitle: string,
        charttype: string, chartid: number,
        keyfordatasets: string,
        keyforlables: string, keyforpresenteddata: string) {
        const dataBar: BarChart = {};
        dataBar.datasets = [];
        const datasetsInfo = [...new Set(data.map(x => x[keyfordatasets]))].filter(x => x !== undefined);
        const lables = [...new Set(data.map(x => {
            if (x[keyfordatasets] === datasetsInfo[0]) {
                return x[keyforlables];
            }
        }))].filter(x => x !== undefined);
        dataBar.labels = lables;
        // console.log(datasetsInfo);
        datasetsInfo.map(y => {
            const datasetsFoDataBar: DataBarChart = {};
            datasetsFoDataBar.borderColor = [];
            datasetsFoDataBar.backgroundColor = [];
            const dataN = [];
            data.map(x => {
                // console.warn([x, keyfordatasets, y, keyforpresenteddata]);
                if (x[keyfordatasets] === y) {
                    dataN.push(x[keyforpresenteddata]);
                    datasetsFoDataBar.label = y;
                }
            });
            datasetsFoDataBar.data = dataN;
            datasetsFoDataBar.fill = true;
            // console.log(datasetsFoDataBar);
            dataBar.datasets.push(datasetsFoDataBar);
        });
        dataBar.title = charttitle;
        dataBar.index = chartid;
        const stringPassed = 'Graph' + charttype + 'Visible_' + chartid;
        const baseColorStep = 360 / datasetsInfo.length;
        let cI = 0;
        dataBar.datasets.map(x => {
            // console.log(x);
            datasetsInfo.map(y => {
                // console.log(y);
                if (y === x.label) {
                    const h_range1 = [cI * baseColorStep, ((cI + 1) * baseColorStep) - 1];
                    const s_range1 = [70, 80];
                    const l_range1 = [70, 80];
                    const a_range1 = [1, 1];
                    const baseColor1 = this.GCS.getHSLARandomColor(h_range1, s_range1, l_range1, a_range1);
                    x.borderColor = baseColor1.HSLAValue;
                    const baseColor2 = this.GCS.getHSLAColor(baseColor1.hue, baseColor1.saturation, baseColor1.lightness, 0.3);
                    x.backgroundColor = baseColor2;
                    x.borderWidth = 1;
                    cI += 1;
                }
            });
        });
        console.log(stringPassed);
        this.changeGraphBar(dataBar, stringPassed);
    }
}
@Injectable({ providedIn: 'root' })
export class GeneralServices {
    getLastDay(yr: number, mm: number): number {
        // zero base months instead of mm+1 pass 0 - 11
        return new Date(+(new Date(yr, mm + 1, 1)) - 1).getDate();
    }
    monthDiff(dateFrom: Date, dateTo: Date): number {
        return dateTo.getMonth() - dateFrom.getMonth() + (12 * (dateTo.getFullYear() - dateFrom.getFullYear()));
    }
    getDateForSlider(yr: number, mm: number, mmsback: number, option: string): string {
        let dd = 1;
        const d = new Date(yr, mm, dd);
        d.setMonth(d.getMonth() + mmsback);
        if (option === 'end') {
            dd = this.getLastDay(d.getFullYear(), d.getMonth());
        }
        const df = new Date(d.getFullYear(), d.getMonth(), dd);
        const rdf = ('00' + (df.getMonth() + 1)).slice(-2) + '/' + ('00' + df.getDate()).slice(-2) + '/' + df.getFullYear();
        return rdf;
    }
    constructor(@Optional() @SkipSelf() parentModule: GeneralServices
    ) {
        if (parentModule) {
            throw new Error(
                'CoreModule is already loaded. Import it in the AppModule only');
        }
    }
}
