import { Component, OnInit, Input, Output, ViewChild, EventEmitter, ElementRef, AfterViewInit, SimpleChanges, OnChanges, OnDestroy } from '@angular/core';
import { MatSliderChange } from '@angular/material/slider';
import { SliderInfo } from '@app/dashboards/data-models/data-models';
import { Subscription } from 'rxjs';
import { GeneralServices, GenericCharsServices, ObservablesAsService } from '../../services/data-service';
@Component({
  selector: 'app-dashboards-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.css']
})
export class SliderComponent implements OnInit, OnDestroy {
  @Input() id: SliderInfo;
  // @Output() messageToEmit = new EventEmitter<string>();
  @ViewChild('slider') slider;
  Slider_Data: SliderInfo = {};
  Slider_Data_Subscription: Subscription;
  constructor(private OAS: ObservablesAsService) {
  }
  ngOnDestroy() {
    if (this.Slider_Data_Subscription) {
      this.Slider_Data_Subscription.unsubscribe();
    }
  }
  ngOnInit(): void {
    const idSub = 'objectSliderBar_' + this.id.id;
    this.Slider_Data_Subscription = this.OAS[idSub].subscribe((x: SliderInfo) => {
      if (Object.keys(x).length !== 0) {
        this.Slider_Data = x;
        this.id = this.Slider_Data;
      }
    });
  }
  formatLabel(value) {
    return value;
  }
  onInputChange(event: MatSliderChange) {
    const i = event.value;
    const rv: string[] = this.getDateForSlider(this.id.latestyear, this.id.latestmonth, -(i - this.id.min) - 1, 'end');
    this.slider._value = rv[0];
    if (typeof this.Slider_Data.returneddate === 'undefined' || this.Slider_Data.returneddate !== rv[0]) {
      this.Slider_Data = this.id;
      this.Slider_Data.returnedyear = +rv[1];
      this.Slider_Data.returnedmonth = +rv[2];
      this.Slider_Data.returneddate = rv[0];
      this.OAS.changeSliderInfo(this.Slider_Data, this.id.id);
    }
  }
  getLastDay(yr: number, mm: number): number {
    return new Date(+(new Date(yr, mm + 1, 1)) - 1).getDate();
  }
  getDateForSlider(yr: number, mm: number, mmsback: number, option: string): string[] {
    let dd = 1;
    const d = new Date(yr, mm, dd);
    d.setMonth(d.getMonth() + mmsback);
    if (option === 'end') {
      dd = this.getLastDay(d.getFullYear(), d.getMonth());
    }
    const df = new Date(d.getFullYear(), d.getMonth(), dd);
    const rdf = ('00' + (df.getMonth() + 1)).slice(-2) + '/' + ('00' + df.getDate()).slice(-2) + '/' + df.getFullYear();
    const yrstr = df.getFullYear().toString();
    const mmstr = (df.getMonth() + 1).toString();
    return [rdf, yrstr, mmstr];
  }
}
