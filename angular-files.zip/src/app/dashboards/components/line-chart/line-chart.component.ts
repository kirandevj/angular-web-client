import { Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import { ElementRef } from '@angular/core';
import { AfterViewInit } from '@angular/core';
import * as Chart from 'chart.js';
import { ElementDiv } from '@app/datamodels/main.model';
import { LineChart, ChartInfo } from '@app/dashboards/data-models/data-models';
import { Subscription } from 'rxjs';
import { ObservablesAsService } from '../../services/data-service';

@Component({
  selector: 'app-dashboards-line-chart',
  templateUrl: './line-chart.component.html',
  styleUrls: ['./line-chart.component.css']
})
export class LineChartComponent implements OnInit, AfterViewInit, OnChanges, OnDestroy {
  @Input() PassedInfo: ChartInfo;
  @ViewChild('linechart')
  linechartCanvas: ElementRef<HTMLCanvasElement>;
  public context: CanvasRenderingContext2D;
  public chart: Chart;
  public heightDiv: 0;
  public widthDiv: 0;
  Line_Chart_Data: LineChart = {};
  Line_Chart_Data_Subscription: Subscription;
  // dataLine: LineChart = {};
  colorLetters = 'hsla(360, 100%, 100%, 0.89)';
  constructor(private OAS: ObservablesAsService) { }
  ngOnDestroy() {
    if (this.Line_Chart_Data_Subscription) {
      this.Line_Chart_Data_Subscription.unsubscribe();
    }
  }
  ngOnInit() { }
  ngAfterViewInit(): void {
    // https://hslpicker.com/#fff,0.69
    const visualLineNumber = this.PassedInfo.id;
    const visualLineSub = 'arrayGraph' + this.PassedInfo.type + 'Visible_' + visualLineNumber;
    this.Line_Chart_Data_Subscription = this.OAS[visualLineSub].subscribe((x: LineChart) => {
      console.log(x);
      if (Object.keys(x).length !== 0) {
        this.Line_Chart_Data = x;
        const options = {
          type: 'line',
          data: {
            labels: this.Line_Chart_Data.labels,
            datasets: this.Line_Chart_Data.datasets,
            // fontSize: 11,
            // fontColor: this.colorLetters
          },
          options: {
            responsive: true,
            responsiveAnimationDuration: 1500,
            title: {
              display: true,
              text: this.Line_Chart_Data.title,
              // fontSize: 13,
              // fontColor: this.colorLetters
            },
            scales: {
              yAxes: [{
                scaleLabel: {   // To format the scale Lebel
                  // fontColor: this.colorLetters
                },
                ticks: {
                  reverse: false,
                  // fontColor: this.colorLetters
                }
              }],
              xAxes: [{
                scaleLabel: {   // To format the scale Lebel
                  // fontColor: this.colorLetters
                },
                ticks: {
                  // fontColor: this.colorLetters
                }
              }]
            }
          }
        };
        if (typeof this.chart !== 'undefined') {
          this.chart.clear();
          this.chart.destroy();
        }
        this.context = this.linechartCanvas.nativeElement.getContext('2d');
        this.chart = new Chart(this.context, options);
        Chart.plugins.register({
          beforeDraw: (chartInstance) => {
            const ctx = chartInstance.chart.ctx;
            ctx.fillStyle = this.PassedInfo.style;
            ctx.fillRect(0, 0, chartInstance.chart.width, chartInstance.chart.height);
          }
        });
        const changeItemColor = (item) => {
          item.scaleLabel.fontColor = this.colorLetters;
          item.scaleLabel.fontStyle = 'normal';
          item.ticks.fontColor = this.colorLetters;
          item.ticks.fontStyle = 'normal';
          item.ticks.minor.fontColor = this.colorLetters;
          item.ticks.major.fontColor = this.colorLetters;
          item.ticks.minor.fontStyle = 'normal';
          item.ticks.major.fontStyle = 'normal';
        };
        console.log(this.chart.options.scales.xAxes);
        console.log(this.chart.options.scales.yAxes);
        this.chart.options.scales.xAxes.forEach((item) => changeItemColor(item));
        this.chart.options.scales.yAxes.forEach((item) => changeItemColor(item));
        this.chart.options.title.fontColor = this.colorLetters;
        this.chart.options.title.fontStyle = 'normal';
        this.chart.options.legend.labels.fontColor = this.colorLetters;
        this.chart.options.legend.labels.fontStyle = 'normal';
        if (typeof this.chart !== 'undefined') { this.chart.update(); }
      } else {
        if (typeof this.chart !== 'undefined') {
          this.chart.clear();
          this.chart.destroy();
        }
      }
    });
  }
  ngOnChanges(changes: SimpleChanges) {
    console.log(this.PassedInfo);
    if (typeof this.PassedInfo !== 'undefined') {
      if (typeof this.chart !== 'undefined') {

        // hwa = this.hw.split(',');
        // if (hwa[2] > 0 && hwa[3] > 0) {
        //   // // console.log(hwa);
        //   this.heightDiv = hwa[2];
        //   this.chart.canvas.parentNode.style.height = hwa[2] + 'px';
        //   this.widthDiv = hwa[3];
        //   this.chart.canvas.parentNode.style.width = hwa[3] + 'px';
        //   this.chart.update();
        // }
      }
    }
  }
}
