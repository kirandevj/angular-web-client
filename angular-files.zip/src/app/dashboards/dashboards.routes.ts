import { DashboardsComponent } from './dashboards.component';
import { ActuarialComponent } from './actuarial/actuarial.component';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { WCComponent } from './wc/wc.component';
import { EmployeesComponent } from './employees/employees.component';
import { ClientsComponent } from './clients/clients.component';
export const DashboardsRoutes = [
  // {
  //   path: 'actuarial',
  //   component: ActuarialComponent,
  //   outlet: 'popup'
  // },
  {
    path: 'dashboards',
    component: DashboardsComponent,
    children: [
      { path: '', component: ActuarialComponent },
      { path: 'actuarial', pathMatch: 'full', component: ActuarialComponent },
      { path: 'wc', pathMatch: 'full', component: WCComponent },
      { path: 'clients', pathMatch: 'full', component: ClientsComponent },
      { path: 'employees', pathMatch: 'full', component: EmployeesComponent }
    ]
  },
  { path: 'dashboards', component: DashboardsComponent },


  // { path: 'dashboards/Actuarial', component: DashboardsComponent },
  // {
  //   path: 'dashboards', component: DashboardsComponent,
  //   children: [
  //     { path: '/dashboards/Actuarial', component: ActuarialComponent }
  //   ]
  // }
  // { path: 'actuarial-dashboards', loadChildren: () =>
  //  import('./actuarial-dashboards/actuarial-dashboards.module').then(m => m.ActuarialDashboardsModule) },
];
@NgModule({
  imports: [
    RouterModule.forChild(DashboardsRoutes)
  ],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
