import { NgModule, CUSTOM_ELEMENTS_SCHEMA, Injector } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { CurrencyPipe } from '@app/common/currency.pipe';
import { DashboardRoutingModule, DashboardsRoutes } from './dashboards.routes';
import { FooterModule, SpinnerModule } from '@app/common/index';
import { FileActionModule } from '../components/files/file-action.module';
import { PreLoadedModule } from '../components/preloaded/pre-loaded.module';
import { ProgressInfoModule } from '../components/progress-info/progress-info.module';
import { DashboardsComponent } from './dashboards.component';
import { NavComponent } from './nav/nav.component';
import { MaterialModule } from '@app/shared/material.module';
import { ActuarialComponent } from '../dashboards/actuarial/actuarial.component';
import { WCComponent } from '../dashboards/wc/wc.component';
import { ClientsComponent } from '../dashboards/clients/clients.component';
import { EmployeesComponent } from '../dashboards/employees/employees.component';
import { CardComponent } from './components/card/card.component';
import { SliderComponent } from './components/slider/slider.component';
import { LineChartComponent } from './components/line-chart/line-chart.component';
import { BarChartComponent } from './components/bar-chart/bar-chart.component';
import { HttpClientModule, HttpClientXsrfModule } from '@angular/common/http';
import { APIsService } from './services/api-services';
import { GeneralServices, GenericCharsServices, ObservablesAsService } from './services/data-service';
@NgModule({
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    DashboardRoutingModule,
    SpinnerModule,
    FileActionModule,
    PreLoadedModule,
    ProgressInfoModule,
    FooterModule,
    MaterialModule,
    HttpClientModule,
    HttpClientXsrfModule.withOptions({
      cookieName: 'My-Xsrf-Cookie',
      headerName: 'My-Xsrf-Header',
    }),
  ],
  declarations: [
    DashboardsComponent,
    NavComponent,
    ActuarialComponent,
    WCComponent,
    ClientsComponent,
    EmployeesComponent,
    CardComponent,
    LineChartComponent,
    BarChartComponent,
    SliderComponent
  ],
  providers: [
    APIsService, GenericCharsServices, ObservablesAsService, GeneralServices
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class DashboardsModule {
  selectedPro(): any {
  }
}
