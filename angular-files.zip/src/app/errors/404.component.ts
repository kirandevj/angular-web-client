import { Component, OnInit } from '@angular/core';
import { Router, Event, NavigationStart, NavigationEnd, NavigationError, NavigationCancel } from '@angular/router';
import { SharedServices, GlobalVariables } from '@app/common/index';
@Component({
  templateUrl: './404.html',
  styleUrls: ['./404.component.css']
})
export class Error404Component implements OnInit {
  loading = true;
  r: string;
  server: string;
  constructor(private route: Router, private ss: SharedServices, private gv: GlobalVariables) {
  }
  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.server = this.gv.get('api', 'api');
    this.r = this.server + '/' + this.route.url.replace(/\/\/+/g, '/');
  }
}
