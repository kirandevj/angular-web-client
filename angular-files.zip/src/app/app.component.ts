import { Component, OnInit } from '@angular/core';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { UserInfo, FooterInfo } from '@app/datamodels/index';
import { Router, Event, NavigationStart, NavigationEnd, NavigationError, NavigationCancel } from '@angular/router';
import { OfflineService } from '@app/services/index';
import { Subscription } from 'rxjs';
// import '../../node_modules/tableau-2.2.2.min.js';
// import * as $ from 'jquery';
// import { ChannelService, ConnectionState, ChannelConfig, SignalrWindow } from './services/signalr/signalr-services';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { IfStmt } from '@angular/compiler';
// import { ChannelService0, ConnectionState0,
// ChannelConfig0, SignalrWindow0, ChannelEvent0 } from './services/signalr/signalr-service-api';

// import {ChannelService, ConnectionState} from './services/channel.sevice';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent implements OnInit {

  // An internal "copy" of the connection state stream used because
  //  we want to map the values of the original stream. If we didn't
  //  need to do that then we could use the service's observable
  //  right in the template.
  //
  // connectionState$: Observable<string>;
  // channelConfig = new ChannelConfig0();


  private offlineSubscription: Subscription;
  constructor(private offlineService: OfflineService,
              private router: Router,
              private ss: SharedServices
    // private cS0: ChannelService0,
    // private channelService: ChannelService,
    // // private sr: SignalrWindow,
    // private sr0: SignalrWindow0
  ) {
    router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        // browserRefresh = !router.navigated;
        // console.log(router.navigated);
        if (router.navigated === false) {
          this.ss.setCache('sessionStorage', 'cid', '', 'string');
        }
      }
    });
    // // Let's wire up to the signalr observables
    // this.connectionState$ = this.channelService.connectionState$
    //   .pipe(map((state: ConnectionState) => {
    //     // // console.log(state);
    //     return ConnectionState[state];
    //   }));

    // this.channelService.error$.subscribe(
    //   (error: any) => { console.warn(error); },
    //   (error: any) => { console.error('errors$ error', error); }
    // );

    // // Wire up a handler for the starting$ observable to log the
    // //  success/fail result

    // this.channelService.starting$.subscribe(
    //   () => { // // console.log('signalr service has been started'); },
    //   () => { console.warn('signalr service failed to start!'); }
    // );

  }
  ngOnInit() {
    // this.offlineSubscription = this.offlineService.offline$.subscribe(() => {
    // // console.log(window.location);
    // // console.log(window.location.pathname);
    // // console.log(window.location.origin);

    // this.channelConfig.urlName = 'http://localhost:63333';
    // this.channelConfig.subUrlName = '/signalr';
    // this.channelConfig.hubName = 'EventHub';
    // this.channelConfig.channelName = 'tasks';
    // this.channelConfig.callerName = 'mine';

    // const test = new ChannelService0(this.sr0, this.channelConfig);
    // test.start()
    //   .subscribe(
    //     (x: ChannelEvent0) => {
    //       // // console.log('Works perfectly');
    //       // // console.log(x);
    //     },
    //     (error: any) => {
    //       console.warn('Attempt to join channel failed!', error);
    //     }
    //   );

    // const ChatHubProxy = $.connection.ChatHub;
    // ChatHubProxy.client.addChatMessageToPage = function (name, message) {
    //   // // console.log(name + ' ' + message);
    // };
    // // // console.log(ChatHubProxy);
    // $.connection.hub.start().done(function () {
    //   // Wire up Send button to call NewContosoChatMessage on the server.
    //   $('#newContosoChatMessage').click(function () {
    //     ChatHubProxy.server.newChatMessage('New ID', 'Hi');
    //     // $('#message').val('').focus();
    //   });
    // });
    // });
    //  this.offlineService.getValueFromObservable().subscribe();
  }

}

