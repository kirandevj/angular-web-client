import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SelectModule } from 'angular2-select';
import { DataLoaderComponent } from '@app/common/index';
import { DataLoaderServices } from '@app/common/index';
import { FileActionModule } from '../files/file-action.module';
import { SpinnerModule } from '@app/common/index';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        SelectModule,
        SpinnerModule,
        FileActionModule
    ],
    declarations: [DataLoaderComponent],
    providers: [DataLoaderServices],
    exports: [
        DataLoaderComponent
    ]
})

export class DataLoaderModule {

}
