import { Component, Input, Output, EventEmitter, OnInit, Optional, SkipSelf } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { DataLoaderServices, IDataLoaderProcess } from './data-loader.services';
import { GlobalVariables, SharedServices } from '@app/common/shared.service';
import { Selection, UserInfo, CleanFileAndServer } from '@app/datamodels/index';
import { FileActionComponent } from '../files/file-action.component';
import { SpinnerComponent } from '@app/common/index';

@Component({
  selector: './app-data-loader',
  templateUrl: './data-loader.html',
  styleUrls: ['./data-loader.css']
})
export class DataLoaderComponent implements OnInit {
  @Input() sentFromUser: IDataLoaderProcess;
  outputmessage: string;
  @Output() outputmessageEvent = new EventEmitter<string[]>();

  IDs: string;
  PlaceHolderIDs: string;
  Products: Array<Selection>;
  PlaceholderProducts: string;
  startdate: Date;
  enddate: Date;
  showspinner: boolean;
  filenames: string[];
  showfile: boolean;
  showbuttontoprocess: boolean;
  sendtofileloadermessages: any[] = ['', false];
  filetobeprocess: string;
  form: FormGroup;
  server: string;
  image0: string;
  image1: string;
  Servers: Array<Selection>;
  PlaceholderServers: string;
  user: UserInfo;
  constructor(@Optional() @SkipSelf() parentModule: DataLoaderComponent,
              private ps: DataLoaderServices,
              private gv: GlobalVariables,
              private ss: SharedServices
  ) {
    if (parentModule) {
      throw new Error(
        'CoreModule is already loaded. Import it in the AppModule only');
    }
  }

  ngOnInit() {
    // // console.log(this.sentFromUser);
    this.startdate = new Date((new Date()).getTime() - (new Date()).getTimezoneOffset() * 60000);
    this.enddate = new Date((new Date()).getTime() - (new Date()).getTimezoneOffset() * 60000);
    this.startdate.setMonth(this.enddate.getMonth() - this.sentFromUser.mmsback);
    // this.startdate.setDate(this.startdate.getDate());
    document.getElementById('startdate')['valueAsDate'] = this.startdate;
    document.getElementById('enddate')['valueAsDate'] = this.enddate;
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.form.addControl('ID', new FormControl());
    this.IDs = 'Enter Company ID';
    this.PlaceHolderIDs = this.IDs;
    this.form.addControl('Product', new FormControl());
    this.Products = this.ss.getProductsAllExtended();
    this.PlaceholderProducts = this.Products[2].label;
    this.form.addControl('Server', new FormControl());
    this.Servers = this.ss.getServers();
    this.PlaceholderServers = this.Servers[0].label;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.sendtofileloadermessages[0] = this.server;
    this.sendtofileloadermessages[1] = false;
    this.showbuttontoprocess = false;

  }
  receiveFromFileService($event) {
    this.filenames = $event;
    if (this.filenames.length === 0) {
      this.showfile = false;
    } else {
      this.showfile = true;
    }
    this.filetobeprocess = this.filenames[0];
  }
  RunProcess(formValues: any) {
    this.showbuttontoprocess = true;
    const rr: IDataLoaderProcess = {
      process: this.sentFromUser.process,
      clientid: (this.ss.getFormValueInputImproved(document.getElementById('idn')['value'], '')).toLocaleUpperCase(),
      fileloaded: this.filetobeprocess,
      server: this.ss.getFormValue(formValues.Server, this.PlaceholderServers, this.Servers, 'value', 'label'),
      product: this.ss.getFormValue(formValues.Product, this.PlaceholderProducts, this.Products, 'value', 'label'),
      startdate: this.ss.getDateFromHTMLInput(document.getElementById('startdate')['value']),
      enddate: this.ss.getDateFromHTMLInput(document.getElementById('enddate')['value']),
      qryname: this.ss.getQueryName('RX', 'XR', 0),
      username: this.sentFromUser.username,
      c: this.sentFromUser.c,
      env: this.sentFromUser.env
    };
    // // console.log(rr);
    this.getPreloadedIDsInfoProcess(rr);
  }
  getPreloadedIDsInfoProcess(v: IDataLoaderProcess) {
    this.ps.getPreloadedIDsInfoProcess(this.server, v)
      .subscribe(
        res => {
          // // // console.log(res);
          this.showbuttontoprocess = false;
          this.sendtofileloadermessages[1] = false;
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              // // // console.log('downloaded all');
              // // // console.log(res1);
              for (let i = 0; i < res.length; i++) {
                if (res[i] !== null) {
                  /////////////////////////// Cleaning server and web folder
                  const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                  // // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
                  // const filenamefullpath = env + filename;
                  let vv: CleanFileAndServer;
                  if (i === 0) {
                    vv = {
                      fullfilename: res[i],
                      qryname: v.qryname,
                      c: v.c
                    };
                  } else {
                    vv = {
                      fullfilename: res[i],
                      qryname: 'none',
                      c: v.c
                    };
                  }
                  this.ss.cleanFileServer(this.server, vv).subscribe(
                    () => { }, err1 => { });
                }
              }
              // --------------- Cleaning all - web and oracle - END
            }, err => { });
        },
        err => {
          // // console.log(err);
          this.showbuttontoprocess = false;
          this.sendtofileloadermessages[1] = false;
        });
  }

}
