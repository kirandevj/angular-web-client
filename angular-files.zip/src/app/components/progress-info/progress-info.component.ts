import { Component, Input, Output, EventEmitter, OnInit, Optional, SkipSelf, OnChanges } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { PreLoadedServices, IPreLoadedProcess } from '../preloaded/pre-loaded.services';
import { GlobalVariables, SharedServices } from '@app/common/shared.service';
import { Selection, UserInfo, CleanFileAndServer } from '@app/datamodels/index';
import { ChannelService, ChannelEvent } from '../../services/channel.sevice';
import { Observable } from 'rxjs';
import { map, filter, scan, catchError, mergeMap } from 'rxjs/operators';
import { HttpClient, HttpResponse } from '@angular/common/http';

@Component({
  selector: './app-progress-info',
  templateUrl: './progress-info.html'
})
export class ProgressInfoComponent implements OnInit, OnChanges {
  server: string;
  apiUrl: string;
  private channel = 'tasks';
  @Input() sentToSignalRChannel = '';
  @Output() outputmessageEvent = new EventEmitter<ChannelEvent>();
  sentFromServer: ChannelEvent;
  user: UserInfo;
  constructor(@Optional() @SkipSelf() parentModule: ProgressInfoComponent,
    private gv: GlobalVariables,
    private ss: SharedServices,
    private channelService: ChannelService,
    private http: HttpClient
  ) {
    if (parentModule) {
      throw new Error(
        'CoreModule is already loaded. Import it in the AppModule only');
    }
    this.server = this.gv.get('api', 'api');
  }
  ngOnChanges() {
    // console.table(this.sentToSignalRChannel);
    if (this.sentToSignalRChannel.length > 0) {
      this.subscribeToChannel(this.sentToSignalRChannel);
    }
  }
  ngOnInit() { }
  subscribeToChannel(channel: string) {
    this.channelService.sub(channel).subscribe(
      (x: ChannelEvent) => {
        // // console.log('Subscribed');
        // console.table(x);
        this.sentFromServer = x;
        this.outputmessageEvent.emit(this.sentFromServer);
      },
      (error: any) => {
        console.warn('Attempt to join channel failed!', error);
      }
    );
  }
}
