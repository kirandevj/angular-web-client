import { Component, Input, Output, EventEmitter, OnInit, Optional, SkipSelf } from '@angular/core';
import { FooterServices } from './footer.service';
import { FooterInfo } from '@app/datamodels/index';

@Component({
  selector: './app-footer',
  templateUrl: './footer.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  @Input() incomingmessage: FooterInfo;

  outputmessage: string;
  @Output() outputmessageEvent = new EventEmitter<string[]>();

  constructor(@Optional() @SkipSelf()
  parentModule: FooterComponent,
    private fs: FooterServices
  ) {
    if (parentModule) {
      throw new Error(
        'CoreModule is already loaded. Import it in the AppModule only');
    }
  }
  ngOnInit() {
  }
}
