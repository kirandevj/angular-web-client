import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FileActionComponent } from './file-action.component';
import { FileServices } from './file-action.service';
import { ProgressInfoModule } from '../../components/progress-info/progress-info.module';
@NgModule({
    imports: [CommonModule, ProgressInfoModule],
    declarations: [FileActionComponent],
    providers: [FileServices],
    exports: [
        FileActionComponent
    ]
})

export class FileActionModule {

}
