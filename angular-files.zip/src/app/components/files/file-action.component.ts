import { Component, Input, Output, EventEmitter, OnInit, Optional, SkipSelf, AfterViewInit } from '@angular/core';
import { FileServices, IFileProcess } from './file-action.service';
import { GlobalVariables, SharedServices } from '@app/common/shared.service';
import { UserInfo, WebWorkerData } from '@app/datamodels/index';
import { ChannelService, ChannelEvent } from '../../services/channel.sevice';
import { Router } from '@angular/router';

@Component({
  selector: './app-file-action',
  templateUrl: './file-action.html',
  styleUrls: ['./file-action.component.css']
})
export class FileActionComponent implements OnInit, AfterViewInit {
  server: string;
  // sentToSignalRChannel = '';
  fileprocess: IFileProcess = {
    modulecaller: '',
    username: '',
    servertable: '',
    machine: '',
    shortfilename: '',
    fileextension: '',
    fullfilename: '',
    action: '',
    result: '',
    env: '',
    c: '',
    channel: '',
    eventname: '',
    signalr: '',
    as_of_yr: 0,
    as_of_mm: 0
  };
  fileprocesstest: IFileProcess = {
    modulecaller: '',
    username: '',
    servertable: '',
    machine: '',
    shortfilename: '',
    fileextension: '',
    fullfilename: '',
    action: '',
    result: '',
    env: '',
    c: '',
    channel: '',
    eventname: '',
    signalr: '',
    as_of_yr: 0,
    as_of_mm: 0
  };
  user: UserInfo;
  filenames: string[];
  showfile: boolean;
  showloadfiletoserver: boolean;
  showloadfiletoservermodule: boolean;
  fileToUpload: FileList = null;
  showcomponent = true;

  @Input() incomingmessages: any[];

  outputmessage: string;
  @Output() outputmessageEvent = new EventEmitter<string[]>();

  constructor(@Optional() @SkipSelf() parentModule: FileActionComponent,
    private fs: FileServices,
    private gv: GlobalVariables,
    private ss: SharedServices,
    private channelService: ChannelService,
    private router: Router
  ) {
    if (parentModule) {
      throw new Error(
        'CoreModule is already loaded. Import it in the AppModule only');
    }
  }
  ngOnInit() {
    this.showcomponent = true;
    this.server = this.incomingmessages[0];
    this.showloadfiletoserver = this.incomingmessages[1];
    this.showloadfiletoservermodule = this.showloadfiletoserver;
    // // console.log(this.incomingmessages);
    this.filenames = [];
    this.showfile = false;
    this.sendMessage(this.filenames);
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.fileprocess.username = this.user.name;
    this.fileprocess.machine = this.user.machine;
    this.fileprocess.env = this.gv.get('excelfilesave', 'excelfilesave').replace('\\excel\\', '\\ManagedFiles\\');
    this.fileprocess.c = this.ss.getPass();
    this.fileprocesstest.username = this.user.name;
    this.fileprocesstest.machine = this.user.machine;
    this.fileprocesstest.env = this.gv.get('excelfilesave', 'excelfilesave').replace('\\excel\\', '\\ManagedFiles\\');
    this.fileprocesstest.c = this.ss.getPass();
  }
  ngAfterViewInit() {
    // if (typeof Worker !== 'undefined') {
    //   // Create a new
    //   const worker = new Worker('@app/services/web-workers/app.worker', { type: 'module' });
    //   worker.onmessage = ({ data }) => {
    //     // console.log(`page got message: ${data}`);
    //   };
    //   const tm: WebWorkerData = {
    //     id: 3,
    //     action: 'load',
    //     data: {}
    //   };
    //   document.querySelector('input[type="file"]').addEventListener('change', function (e) {
    //     tm.data = this.files;
    //     worker.postMessage(tm);
    //   }, false);
    // } else {
    //   // Web Workers are not supported in this environment.
    //   // You should add a fallback so that your program still executes correctly.
    // }
  }
  handleFileInput(files: FileList) {
    // console.log(files);
    // https://www.html5rocks.com/en/tutorials/file/filesystem-sync/#toc-readingsync
    for (let i = 0; i < files.length; i++) {
      this.showfile = true;
      this.filenames.push(files.item(i).name);
      this.outputmessage = files.item(i).name;
      this.uploadFileToActivity(files.item(i));
    }
    this.sendMessage(this.filenames);
  }
  uploadFileToActivity(file: File): void {
    //////////////////// start copying here
    // console.log('loading now');
    // console.log(this.server);
    this.showcomponent = false;
    this.fs.postFile(this.server, file).subscribe(data => {
      // console.log(data);
      this.showcomponent = true;
    }, error => {
      // console.log(error);
      this.ss.setCache('sessionStorage', 'counter', '2', 'string');
      this.router.navigateByUrl('/welcome');
      this.showcomponent = true;
    });
  }
  LoadAllFilesToServer(): void {
    let counter = 0;
    this.showloadfiletoserver = !this.showloadfiletoserver;
    // console.log(this.filenames);
    this.filenames.forEach((v, i): void => {
      counter++;
      this.fileprocess.servertable = 'TEMP' + this.fileprocess.machine.toLocaleUpperCase() + counter + 'DATALOAD';
      this.fileprocess.shortfilename = v;
      this.fileprocess.fileextension = this.fileprocess.shortfilename.split('.').pop();
      this.fileprocess.fullfilename = this.fileprocess.env + this.fileprocess.shortfilename;
      this.fileprocess.modulecaller = this.incomingmessages[2];
      this.fileprocess.channel = this.incomingmessages[4];
      this.fileprocess.eventname = this.incomingmessages[5];
      this.fileprocess.signalr = this.incomingmessages[3];
      this.fileprocess.as_of_yr = this.incomingmessages[6];
      this.fileprocess.as_of_mm = this.incomingmessages[7];
      // setTimeout(() => {
      this.fs.loadFile(this.server, this.fileprocess).subscribe(data => {
        this.filenames = this.filenames.filter(f => (f !== v));
        if (this.filenames.length === 0) {
          this.showloadfiletoserver = !this.showloadfiletoserver;
          this.showfile = false;
          this.deleteFileFromActivity(this.fileprocess.shortfilename);
        }
        this.sendMessage(this.filenames);
      }, error => {
        this.deleteFileFromActivity(this.fileprocess.shortfilename);
        this.showloadfiletoserver = !this.showloadfiletoserver;
        this.showfile = false;
      });
      // }, i * 3000);
      // this.fileprocesstest.servertable = 'TEMP' + this.fileprocess.machine.toLocaleUpperCase() + counter + 'DATALOAD';
      // this.fileprocesstest.shortfilename = 'MedStat_MAY2018_5_2018.txt';
      // this.fileprocesstest.fileextension = this.fileprocesstest.shortfilename.split('.').pop();
      // this.fileprocesstest.fullfilename = this.fileprocesstest.env + this.fileprocesstest.shortfilename;
      // this.fileprocesstest.modulecaller = this.incomingmessages[2];
      // // // console.log(this.fileprocesstest);

    });
  }
  deleteFileFromActivity(fileout: string): void {
    this.fs.deleteFile(this.server, fileout).subscribe(data => {
      this.filenames = this.filenames.filter(f => (f !== fileout));
      if (this.filenames.length === 0) {
        this.showfile = false;
      }
      this.sendMessage(this.filenames);
    }, error => {
      // // console.log(error);
    });
  }
  sendMessage(message: string[]): void {
    this.outputmessageEvent.emit(this.filenames);
  }
  receiveFromFileService($event: ChannelEvent) {
    // // console.log($event);
  }
}
