import { Component, Input, Output, EventEmitter, OnInit, Optional, SkipSelf, ɵConsole, OnDestroy } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ChartServices, ChartInfo0, ChartBase0 } from '../chart.services';
import { VizIncomingInitialInfo } from '@app/datamodels/index';
import { GlobalVariables, SharedServices, GlobalObservables } from '@app/common/shared.service';
import { Selection, UserInfo, CleanFileAndServer } from '@app/datamodels/index';
import { Chart } from 'chart.js';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subscription, of, merge } from 'rxjs';
import { mapTo, delay } from 'rxjs/operators';
// import { Exchanges, PLAN_NAME_SHORT } from '../chart-base/chart.services';

@Component({
  providers: [ChartServices],
  selector: './app-chart-base',
  templateUrl: './chart-base.html',
  styleUrls: ['./chart-base.css']
})
export class ChartBaseComponent implements OnInit, OnDestroy {
  showme = false;
  IDs: string;
  PlaceHolderIDs: string;
  Products: Array<Selection>;
  PlaceholderProducts: string;
  startdate: Date;
  enddate: Date;
  showspinner: boolean;
  filenames: string[];
  showfile: boolean;
  showbuttontoprocess: boolean;
  sendtofileloadermessages: any[] = ['', false];
  filetobeprocess: string;
  form: FormGroup;
  server: string;
  image0: string;
  image1: string;
  Servers: Array<Selection>;
  PlaceholderServers: string;
  user: UserInfo;
  lineChartData: any;
  chart: any = []; // This will hold our chart info
  /////// data below
  ChartData: ChartInfo0[] = [];
  ChartViz: [ChartBase0[], string[]] = [[], []];
  ////////////////////// Subscriptions
  vizInfoSubscription: Subscription;
  message: any;
  subscription: Subscription;
  initInfo: VizIncomingInitialInfo;
  constructor(
    private cs: ChartServices,
    private gv: GlobalVariables,
    private ss: SharedServices,
    private _http: HttpClient,
    private viz: ChartServices,
    private glo: GlobalObservables
  ) {
    this.vizInfoSubscription = this.glo.currentExchangeInfo.subscribe(x => {
      // // // console.log('Received within Chart-Base component on the subscription level');
      // // // console.log(x);
    });
    this.subscription = this.glo.getMessage().subscribe(x => {
      // // // console.log('Received within Chart-Base component on the subscription level');
      // // console.log(x);
      this.initViz(x);
    });
  }
  ngOnDestroy() {
    if (this.vizInfoSubscription) {
      this.vizInfoSubscription.unsubscribe();
    }
  }
  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.ChartData = [];
  }
  outPutViz() {
    const id = 'canvas';
    const idp = 'canvasparent';
    const p = document.getElementById(id);
    document.getElementById(id).parentNode.removeChild(document.getElementById(id));
    const pid = document.getElementById(idp);
    const newElement = document.createElement('canvas');
    newElement.setAttribute('id', id);
    newElement.innerHTML = p.outerHTML;
    pid.appendChild(newElement);
    return new Chart(id, {
      type: 'line',
      data: {
        labels: this.ChartViz[1],
        datasets: this.ChartViz[0]
      },
      options: {
        legend: {
          display: true
        },
        scales: {
          xAxes: [{
            gridLines: {
              display: false,
              color: 'black'
            },
            scaleLabel: {
              display: true,
              labelString: 'Time periods',
              fontColor: 'red'
            }
          }],
          yAxes: [{
            gridLines: {
              display: false,
              color: 'black',
              borderDash: [2, 5],
            },
            scaleLabel: {
              display: true,
              labelString: 'Data points',
              fontColor: 'green'
            }
          }],
        },
      }
    });
  }
  initViz(v: VizIncomingInitialInfo) {
    this.ChartData = [];
    this.chart = null;
    this.cs.getChartData(this.server, v).subscribe(
      res => {
        // // console.log(JSON.parse(res));
        if (res.length > 0) {
          this.ChartData = JSON.parse(res);
          this.cs.formatData(this.ChartData).subscribe(val => {
            this.showme = true;
            this.ChartViz = val;
            setTimeout(() => {
              this.chart = this.outPutViz().update();
              this.glo.sendMessage('true');
            }, 1);
          });
        }
      },
      err => { });
  }
  // T() {
  //   const sendtochartinfo: VizIncomingInitialInfo = {
  //     Product: 'T',
  //     InfoToPresent: '',
  //     ID: '',
  //     StartDate: '',
  //     EndDate: '',
  //     Option1: '',
  //     Option2: '',
  //     Source: '',
  //     qryname: '',
  //     username: 'T',
  //     c: '',
  //     env: '',
  //     transportedinfo: ['']
  //   };
  //   // this.glo.changeExchangeInfo(sendtochartinfo);
  //   this.glo.sendMessage(sendtochartinfo);
  // }
}
