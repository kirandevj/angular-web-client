import { Injectable, Optional, SkipSelf } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, filter, scan, catchError, mergeMap, debounceTime } from 'rxjs/operators';
import { VizIncomingInitialInfo } from '@app/datamodels';
// import { Headers, HttpRequest } from '@angular/common/http';
@Injectable()
export class ChartServices {
    // private subject = new Subject<any>();
    // exchangeInfo: VizIncomingInitialInfo = {
    //     Product: '',
    //     InfoToPresent: '',
    //     ID: '',
    //     StartDate: '',
    //     EndDate: '',
    //     qryname: '',
    //     username: '',
    //     c: '',
    //     env: '',
    //     transportedinfo: ['']
    // };
    // private exchangeInfoInit = new BehaviorSubject<VizIncomingInitialInfo>(this.exchangeInfo);
    // currentExchangeInfo = this.exchangeInfoInit.asObservable();
    constructor(@Optional() @SkipSelf() parentModule: ChartServices, private http: HttpClient) { }
    formatData(arr: ChartInfo0[]): Observable<[ChartBase0[], string[]]> {
        const returnObsevable = Observable.create(observer => {
            const labels = [...new Set(arr.map(x => x.CategoryLable))];
            const dates = [...new Set(arr.sort((a, b) => a.NO - b.NO).map(x => x.CategoryDate))];
            const arrRetrun: ChartBase0[] = [];
            let arrData: any[] = [];
            labels.map(x => {
                arrData = arr.filter(y => y.CategoryLable === x).sort((a, b) => a.NO - b.NO).map(z => z.CategoryData);
                const obj: ChartBase0 = {
                    label: x,
                    data: arrData,
                    borderColor: this.stringToColour(x),
                    fill: false
                };
                arrRetrun.push(obj);
            });
            observer.next([arrRetrun, dates]);
            // observer.complete();
        }).pipe(debounceTime(1000));
        return returnObsevable;
    }
    stringToColour(str: string) {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            // tslint:disable-next-line:no-bitwise
            hash = str.charCodeAt(i) + ((hash << 5) - hash);
        }
        let colour = '#';
        for (let x = 0; x < 3; x++) {
            // tslint:disable-next-line:no-bitwise
            const value = (hash >> (x * 8)) & 0xFF;
            colour += ('00' + value.toString(16)).substr(-2);
        }
        return colour;
    }
    getChartData(api: string, v: VizIncomingInitialInfo): Observable<string> {
        // https://skryvets.com/blog/2017/11/26/simply-about-new-httpclient-in-angular/
        // https://angular.io/guide/http
        const headers = new HttpHeaders().set('Content-Type', 'application/json');
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        };
        // const headers = new HttpHeaders().set('Content-Type', 'text').append('Authorization', 'CustomToken12345');
        // const options = new HttpRequest({ headers: headersobj });
        // return this.http.post<ChartInfo0[]>(api + 'api/MainAPI?viz=', v, httpOptions).pipe(map((r: ChartInfo0[]) => {
        return this.http.post(api + 'api/MainAPI?viz=', v, httpOptions).pipe(map((r: string) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
}
export interface ChartInfo0 {
    CategoryDate: string;
    CategoryLable: string;
    CategoryData: number;
    NO: number;
}
export interface ChartBase0 {
    label: string;
    data: number[];
    borderColor: string;
    fill: boolean;
}
