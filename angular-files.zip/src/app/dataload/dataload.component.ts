import { Component, ViewEncapsulation, OnInit, ElementRef } from '@angular/core';
import { UserInfo, FooterInfo } from '@app/datamodels/index';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { FooterComponent } from '@app/common/index';

@Component({
  // encapsulation: ViewEncapsulation.None,
  templateUrl: './dataload.html',
  styleUrls: ['./dataload.component.css']
})
export class DataloadComponent implements OnInit {
  loading = false;
  user: UserInfo;
  sendtofooter: FooterInfo;
  constructor(private ss: SharedServices, private element: ElementRef
  ) {
    // this.parentNativeElement = element.nativeElement;
  }
  ngOnInit() {
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - Underwriting landing page issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
  }
}
