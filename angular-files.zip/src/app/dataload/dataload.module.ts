import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SelectModule } from 'angular2-select';
import { DataloadComponent } from './dataload.component';
import { ClientsComponent } from './clients/clients.component';
import { WagesComponent } from './wages/wages.component';
import { DataloadNavBarComponent } from './nav/dataload-navbar.component';
import { DataloadRoutes } from './dataload.routes';
import { DataloadServices } from './shared/dataload.services';
import { FooterModule } from '@app/common/index';
import { SpinnerModule } from '@app/common/index';

@NgModule({
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(DataloadRoutes),
    SelectModule,
    FooterModule,
    SpinnerModule
  ],
  declarations: [
    DataloadNavBarComponent,
    DataloadComponent,
    ClientsComponent,
    WagesComponent,
  ],
  providers: [
    DataloadServices
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class DataloadModule {
  selectedPro(): any {
  }
}
