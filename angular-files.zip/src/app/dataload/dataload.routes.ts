import { DataloadComponent } from './dataload.component';
import { ClientsComponent } from './clients/clients.component';
import { WagesComponent } from './wages/wages.component';

export const DataloadRoutes = [
    { path: '', component: DataloadComponent },
    { path: 'clients', component: ClientsComponent },
    { path: 'wages', component: WagesComponent }
];
