import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { UnderWritingMainData } from '../shared/datamodels';
// Import RxJs required methods
import { map, filter, scan, catchError, mergeMap } from 'rxjs/operators';

@Injectable()
export class DataloadServices {
    constructor(private http: HttpClient, private ss: SharedServices) { }
    getUnderwritingMainModuleInfo(api: string, v: Object): Observable<UnderWritingMainData> {
        // return this.http.post(api + 'api/Underwriting?MainModuleInfo=MainModuleInfo', v).map((r: Response) => r
        // ).catch((e: any) => Observable.throw(e.error || 'Server error'));
        return this.http.post(api + 'api/Underwriting?MainModuleInfo=MainModuleInfo', v).pipe(map((r: UnderWritingMainData) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
    getUnderwritingMainModuleExcelFile(api: string, v: Object): Observable<string[]> {
        // return this.http.post(api + 'api/Underwriting?MainModuleExcelFile=MainModuleExcelFile', v).map((r: Response) => r
        // ).catch((e: any) => Observable.throw(e.error || 'Server error'));
        return this.http.post(api + 'api/Underwriting?MainModuleExcelFile=MainModuleExcelFile', v).pipe(map((r: string[]) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
}




