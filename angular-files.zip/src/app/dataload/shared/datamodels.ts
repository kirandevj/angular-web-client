export interface UnderWritingMainData {
    id: string;
    date: string;
    id3: string;
    id4: string;
    statuses: string;
    billrateid: string;
    pfcorp: string;
    product: string;
    name: string;
    user: string;
    policyyearrate: string;
    paygrouppayfreqtierrate: string;
    lossratiotimeperiod: string;
    startdate: string;
    termdate: string;
    encr: string;
    env: string;
    filenameshort: string;
    queryname: string;
}
