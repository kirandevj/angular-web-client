import { Component, ViewEncapsulation, OnInit, Input, ChangeDetectorRef, AfterViewInit, ChangeDetectionStrategy } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { LossRatio, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
// import { HealthReportsData, RunProcess, LocalVariables } from '../../shared/datamodels';
// import { HealthServices } from '../../shared/health.services';
import { FooterComponent } from '@app/common/index';
import { ChannelEvent, ChannelService } from '@app/services/channel.sevice';
import { BehaviorSubject } from 'rxjs';
import { ActuarialServices } from '../shared/actuarial.services';
import { SASGenericReport } from '../shared/datamodels';

@Component({
  templateUrl: './mlrs.html',
  styleUrls: ['./mlrs.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SASMLRSComponent implements OnInit {
  @Input() message: ChannelEvent = {
    Name: '',
    ChannelName: '',
    Timestamp: (new Date(Date.now() - ((new Date()).getTimezoneOffset() * 60000))).toISOString().slice(0, -1),
    Data: {
      State: 'Process info here',
      PercentComplete: 0,
      FileNames: [],
      json: ''
    },
    Json: ''
  };
  items: ChannelEvent[] = [];
  items$ = new BehaviorSubject(this.items);
  env = '';
  sentToSignalRChannel = 'saspremiumclaims';
  receivedFromService = '';
  eventName: string;
  report: SASGenericReport = {
    reportname: '',
    exchanges: [''],
    category: '',
    carriers: [''],
    asofyr: 0,
    asofmm: 0,
    id: '',
    qryname: '',
    username: '',
    machinename: '',
    env: '',
    c: '',
    channel: '',
    eventname: '',
    signalr: ''
  };
  showspinner = false;
  showspinner2 = false;
  user: UserInfo;
  sendtofooter: FooterInfo;
  sendtofileloadermessages: any[] = ['', true];
  form: FormGroup;
  Exchanges: Array<Selection>;
  PlaceHolderExchanges: string;
  Categories: Array<Selection>;
  PlaceHolderCategories: string;
  Carriers: Array<Selection>;
  PlaceHolderCarriers: string;
  AsOfYrs: Array<Selection>;
  PlaceholderAsOfYrs: string;
  AsOfMms: Array<Selection>;
  PlaceholderAsOfMms: string;
  server: string;
  image0: string;
  image1: string;
  reportsInfo: boolean;
  // ReportsArray: Array<RunProcess>;
  variablesHome: string;
  theDateStart: Date;
  theDateEnd: Date;
  theDateClient: Date;
  constructor(
    private cd: ChangeDetectorRef,
    private ss: SharedServices,
    private gv: GlobalVariables,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef,
    private as: ActuarialServices,
    private channelService: ChannelService
  ) {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.variablesHome = this.sentToSignalRChannel;
    this.eventName = this.sentToSignalRChannel;
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - Actuarial MLRs page issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
  }
  ngOnInit() {
    this.sendtofileloadermessages[0] = this.server;
    this.sendtofileloadermessages[1] = true;
    this.form = new FormGroup({});
    this.form.addControl('Exchange', new FormControl());
    this.form.addControl('Category', new FormControl());
    this.form.addControl('Carrier', new FormControl());
    this.form.addControl('AsOfYr', new FormControl());
    this.form.addControl('AsOfMm', new FormControl());
    this.Exchanges = this.ss.getExchangesAllOptions();
    // this.PlaceHolderExchanges = this.Exchanges[0].label;
    this.PlaceHolderExchanges = '';
    this.Categories = this.ss.getHealthCategories();
    this.PlaceHolderCategories = this.Categories[0].label;
    this.Carriers = this.ss.getHealthCarriers();
    this.PlaceHolderCarriers = '';
    // this.PlaceHolderCarriers = this.Carriers[0].label;
    const d = new Date();
    this.AsOfYrs = this.ss.getYears();
    this.PlaceholderAsOfYrs = (new Date()).getFullYear().toString();
    this.AsOfMms = this.ss.getMonths();
    this.PlaceholderAsOfMms = ((new Date()).getMonth() + 1).toString();
    this.theDateStart = this.ss.getDateForCalendarString(+this.PlaceholderAsOfYrs, +this.PlaceholderAsOfMms, -15, 'start');
    this.theDateEnd = this.ss.getDateForCalendarString(+this.PlaceholderAsOfYrs, +this.PlaceholderAsOfMms, -4, 'end');
    this.theDateClient = this.ss.getDateForCalendarString(+this.PlaceholderAsOfYrs, +this.PlaceholderAsOfMms, -17, 'start');
    document.getElementById('theDateStart')['valueAsDate'] = this.theDateStart;
    document.getElementById('theDateEnd')['valueAsDate'] = this.theDateEnd;
    document.getElementById('theDateClient')['valueAsDate'] = this.theDateClient;
    this.items.push(this.message);
  }
  /////////////////// Data loads here
  receiveFromFileServiceProgress($event: ChannelEvent) {
    this.items.push($event);
    // // console.log($event);
    this.message = $event;
    this.cdr.detectChanges();
    if ($event.Data.FileNames.length > 0) {
      const allowedfiles = ['xlsx', 'csv'];
      const env = this.gv.get('excelfiledownload', 'excelfiledownload');
      // console.log($event.Data.FileNames);
      this.showspinner = false;
      this.showspinner2 = false;
      this.ss.downloadFilesFromSignalRService($event.Data.FileNames, env, allowedfiles, true, this.server);
    }
  }
  GetExcelFile(f: FormGroup): void {
    this.showspinner = true;
    this.report.qryname = this.ss.getQueryName('A', 'F', 0);
    this.report.reportname = 'MLRs';
    this.report.exchanges = this.pullDataFromMultiSelect(f['Exchange'], this.Exchanges);
    // this.report.exchanges = [this.ss.getFormValue(f['Exchange'], this.PlaceHolderExchanges, this.Exchanges, 'value', 'label')];
    this.report.category = this.ss.getFormValue(f['Category'], this.PlaceHolderCategories, this.Categories, 'value', 'label');
    this.report.carriers = this.pullDataFromMultiSelect(f['Carrier'], this.Carriers);
    // this.report.carriers = [this.ss.getFormValue(f['Carrier'], this.PlaceHolderCarriers, this.Carriers, 'value', 'label')];
    this.report.asofyr = +this.ss.getFormValue(f['AsOfYr'], this.PlaceholderAsOfYrs, this.AsOfYrs, 'value', 'label');
    this.report.asofmm = +this.ss.getFormValue(f['AsOfMm'], this.PlaceholderAsOfMms, this.AsOfMms, 'value', 'label');
    this.report.startdate = this.ss.getDateFromHTMLInput(document.getElementById('theDateStart')['value']);
    this.report.enddate = this.ss.getDateFromHTMLInput(document.getElementById('theDateEnd')['value']);
    this.report.clientdatesmaturity = this.ss.getDateFromHTMLInput(document.getElementById('theDateClient')['value']);
    this.report.username = this.user.name;
    this.report.machinename = this.user.machine;
    this.report.c = this.ss.getPass();
    this.report.env = this.gv.get('excelfilesave', 'excelfilesave');
    this.report.channel = this.eventName;
    this.report.eventname = this.eventName;
    this.report.signalr = this.channelService.connectionID$;
    // console.log(this.report);
    // this.connectToSASTest();
    ////////////////////// Subscribing to process here
    this.as.getSASActuarialGenericReporting(this.server, this.report).subscribe(
      res => {
        // // console.log(res);
        // this.showspinner = false;
      },
      err => { });
  }
  GetExcelFile2(f: FormGroup): void {
    this.showspinner2 = true;
    this.report.qryname = this.ss.getQueryName('A', 'F', 0);
    this.report.reportname = 'MLRs';
    this.report.exchanges = ['All'];
    // this.report.exchanges = [this.ss.getFormValue(f['Exchange'], this.PlaceHolderExchanges, this.Exchanges, 'value', 'label')];
    this.report.category = 'Medical';
    this.report.carriers = ['All'];
    // this.report.carriers = [this.ss.getFormValue(f['Carrier'], this.PlaceHolderCarriers, this.Carriers, 'value', 'label')];
    this.report.asofyr = +this.ss.getFormValue(f['AsOfYr'], this.PlaceholderAsOfYrs, this.AsOfYrs, 'value', 'label');
    this.report.asofmm = +this.ss.getFormValue(f['AsOfMm'], this.PlaceholderAsOfMms, this.AsOfMms, 'value', 'label');
    this.report.startdate = this.ss.getDateFromHTMLInput(document.getElementById('theDateStart')['value']);
    this.report.enddate = this.ss.getDateFromHTMLInput(document.getElementById('theDateEnd')['value']);
    this.report.clientdatesmaturity = this.ss.getDateFromHTMLInput(document.getElementById('theDateClient')['value']);
    this.report.username = this.user.name;
    this.report.machinename = this.user.machine;
    this.report.c = this.ss.getPass();
    this.report.env = this.gv.get('excelfilesave', 'excelfilesave');
    this.report.channel = this.eventName;
    this.report.eventname = this.eventName;
    this.report.signalr = this.channelService.connectionID$;
    // console.log(this.report);
    // this.connectToSASTest();
    ////////////////////// Subscribing to process here
    this.as.getSASActuarialGenericReporting(this.server, this.report).subscribe(
      res => {
        // // console.log(res);
        // this.showspinner = false;
      },
      err => { });
  }
  updateChange(s: string) {
    // console.log(s);
  }
  pullDataFromMultiSelect(arr: number[], arrmain: Selection[]): string[] {
    const r: string[] = [];
    // console.log(arr);
    if (arr === null) {
      r.push(arrmain[0].label);
    } else {
      if (arr.length !== 0) {
        arr.map(x => {
          arrmain.map(y => {
            if (y.value === x) {
              r.push(y.label);
            }
          });
          return x;
        });
      } else {
        r.push(arrmain[0].label);
      }
    }
    return r;
  }
}
