import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { UserInfo, FooterInfo, Selection, CleanFileAndServer } from '@app/datamodels/index';
import { ActuarialServices } from '../shared/actuarial.services';
import { ActuarialFiananceReporting } from '../shared/local.variables';

@Component({
  // encapsulation: ViewEncapsulation.None,
  templateUrl: './finance-reporting.html',
  styleUrls: ['./finance-reporting.components.css']
})
export class FinanceReportingComponent implements OnInit {
  MainObject: ActuarialFiananceReporting = {
    asofyr: 0,
    asofmm: 0,
    clients: '',
    clientscarveout: '',
    mmsback: 0,
    states: '',
    statesgroups: '',
    topverticals: 0,
    qryname: '',
    username: '',
    c: this.ss.getCache('localStorage', 'pass', 'string'),
    env: this.gv.get('excelfilesave', 'excelfilesave')
  };
  user: UserInfo;
  sendtofooter: FooterInfo;
  showspinner: boolean;
  filenames: string[];
  showfile: boolean;
  form: FormGroup;
  Years: Array<Selection>;
  YearsHolder = 0;
  Months: Array<Selection>;
  Clients: Array<Selection>;
  ClientsCarveout: Array<Selection>;
  MonthsHolder = 0;
  States: Array<Selection>;
  StatesHolder = '';
  MonthsBackHolder = 60;
  ClientsHolder = '';
  ClientsCarveoutHolder = '';
  TopVerticalsHolder = 10;
  StatesGroupsHolder = 'CA,FL,NY,TX';
  server: string;
  image0: string;
  constructor(private ss: SharedServices, private gv: GlobalVariables, private urs: ActuarialServices) { }
  ngOnInit() {
    this.form = new FormGroup({});
    this.form.addControl('Year', new FormControl());
    this.form.addControl('Month', new FormControl());
    this.form.addControl('State', new FormControl());
    this.form.addControl('Client', new FormControl());
    this.form.addControl('ClientCarveout', new FormControl());
    this.form.addControl('MonthsBack', new FormControl());
    this.form.addControl('StatesGroups', new FormControl());
    this.form.addControl('TopVerticals', new FormControl());
    this.Years = this.ss.getYears();
    this.YearsHolder = +this.Years[0].label;
    this.YearsHolder = +this.ss.getYearsHolderSds();
    this.Months = this.ss.getMonths();
    this.Clients = this.ss.getClientsOptionSelection();
    this.ClientsCarveout = this.ss.getClientsCarveoutOptionSelection();
    this.ClientsHolder = this.Clients[0].label;
    this.ClientsCarveoutHolder = this.ClientsCarveout[0].label;
    this.MonthsHolder = +this.ss.getMonthsHolderSds();
    this.States = this.ss.getStatesOption();
    this.StatesHolder = this.States[0].label;
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.server = this.gv.get('api', 'api');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.user = this.ss.getCache('localStorage', 'user', 'object');
  }
  GetExcelFile(f: FormGroup): void {
    this.MainObject.env = this.gv.get('excelfilesave', 'excelfilesave');
    this.MainObject.username = this.user.name;
    this.MainObject.qryname = this.ss.getQueryName('AC', 'FR', 0);
    // this.MainObject.qryname = 'TEMPLP';
    this.MainObject.asofyr = +this.ss.getFormValue(f['Year'], this.YearsHolder, this.Years, 'value', 'label');
    this.MainObject.asofmm = +this.ss.getFormValue(f['Month'], this.MonthsHolder, this.Months, 'value', 'label');
    this.MainObject.states = this.ss.getFormValue(f['State'], this.StatesHolder, this.States, 'value', 'label');
    this.MainObject.clients = this.ss.getFormValue(f['Client'], this.ClientsHolder, this.Clients, 'value', 'label');
    this.MainObject.clientscarveout = this.ss.getFormValue(f['ClientCarveout'], this.ClientsCarveoutHolder,
      this.ClientsCarveout, 'value', 'label');
    if (this.MainObject.states === 'Benefit state') {
      this.MainObject.states = 'BNST';
    } else {
      this.MainObject.states = 'ACST';
    }

    this.MainObject.mmsback = +this.ss.getFormValueInputImproved(document.getElementById('mb')['value'], this.MonthsBackHolder);

    this.MainObject.topverticals = +this.ss.getFormValueInputImproved(document.getElementById('vt')['value'], this.TopVerticalsHolder);

    this.MainObject.statesgroups = this.ss.getFormValueInputImproved(document.getElementById('ca')['value'], this.StatesGroupsHolder)
      .replace(/;/g, ',').replace(/ /g, '');
    this.MainObject.c = this.ss.getPass();
    // // console.log(this.MainObject);
    this.showspinner = true;
    this.urs.getActuarialFiananceReporting(this.server, this.MainObject)
      .subscribe
      (
        res => {
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          // // console.log(res);
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            () => {
              this.showspinner = false;
              // --------------- Cleaning all - web and oracle - START
              for (let i = 0; i < res.length; i++) {
                if (res[i] !== null) {
                  /////////////////////////// Cleaning server and web folder
                  const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                  let vv: CleanFileAndServer;
                  if (i === 0) {
                    vv = {
                      fullfilename: res[i],
                      qryname: 'none',
                      c: 'none'
                    };
                  } else {
                    vv = {
                      fullfilename: res[i],
                      qryname: 'none',
                      c: 'none'
                    };
                  }
                  this.ss.cleanFileServer(this.server, vv).subscribe(
                    () => { }, () => { });
                }
              }
              // --------------- Cleaning all - web and oracle - END
            }, () => {
              this.showspinner = false;
            });
        }, () => {
          this.showspinner = false;
        });
  }
  focusFunction(): void {
    // // console.log(f);
  }
  receiveFromFileService($event) {
    this.filenames = $event;
    if (this.filenames.length === 0) {
      this.showfile = false;
    } else {
      this.showfile = true;
    }
  }
  normalizeMMB(v: number) {
    if (v > this.MonthsBackHolder) {

      document.getElementById('mb')['value'] = this.MonthsBackHolder;
    }
  }
  normalizeVERT(v: number) {
    if (v > this.TopVerticalsHolder) {

      document.getElementById('vt')['value'] = this.TopVerticalsHolder;
    }
  }
}
