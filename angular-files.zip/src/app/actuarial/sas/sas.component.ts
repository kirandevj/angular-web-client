import {
  Component, ViewEncapsulation, OnInit, NgZone, ChangeDetectionStrategy, Input, ChangeDetectorRef,
  AfterViewInit, OnChanges, SimpleChanges,
  Output,
  EventEmitter,
  DoCheck,
  AfterContentInit,
  AfterContentChecked,
  AfterViewChecked,
  OnDestroy
} from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { LossRatio, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { FileServices } from '../../components/files/file-action.service';
// import { HealthReportsData, RunProcess, LocalVariables } from '../../shared/datamodels';
import { FooterComponent } from '@app/common/index';
import { ChannelService, ChannelEvent } from '../../services/channel.sevice';
import { ActuarialServices } from '../shared/actuarial.services';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { BehaviorSubject } from 'rxjs';
@Component({
  templateUrl: './sas.html',
  styleUrls: ['./sas.css'],
  changeDetection: ChangeDetectionStrategy.Default
})
// Hooks / Methods
// https://codecraft.tv/courses/angular/components/lifecycle-hooks/
// 1) constructor / component
// 2) ngOnChanges / component
// 3) ngOnInit / component
// 4) ngDoCheck / component
// 5) ngAfterContentInit / children
// 6) ngAfterContentChecked / children
// 7) ngAfterViewInit / children
// 8) ngAfterViewChecked / children
// 9) ngOnDestroy / component
export class SASComponent implements OnInit, OnChanges {
  @Input() message: ChannelEvent = {
    Name: '',
    ChannelName: '',
    Timestamp: (new Date(Date.now() - ((new Date()).getTimezoneOffset() * 60000))).toISOString().slice(0, -1),
    Data: {
      State: 'Process info here',
      PercentComplete: 0,
      json: ''
    },
    Json: ''
  };
  // get runChangeDetection() {
  //   // console.log('Checking the view');
  //   return true;
  // }
  items: ChannelEvent[] = [];
  items$ = new BehaviorSubject(this.items);
  env = '';
  sentToSignalRChannel = 'sas';
  receivedFromService = '';
  showspinner = false;
  eventName: string;
  user: UserInfo;
  sendtofooter: FooterInfo;
  sendtofileloadermessages: any[] = ['', true];
  form: FormGroup;
  form2: FormGroup;
  filenames: string[];
  showfile: boolean;
  server: string;
  image0: string;
  image1: string;
  DataSets: Array<Selection>;
  PlaceholderDataSets: string;
  constructor(
    private zone: NgZone,
    private as: ActuarialServices,
    private ss: SharedServices,
    private gv: GlobalVariables,
    private route: ActivatedRoute,
    private fs: FileServices,
    private channelService: ChannelService,
    private cdr: ChangeDetectorRef
  ) {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.eventName = this.sentToSignalRChannel;
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.env = this.gv.get('excelfilesave', 'excelfilesave');
    this.sendtofileloadermessages[0] = this.server;
    this.sendtofileloadermessages[1] = true;
    this.sendtofileloadermessages[2] = 'SAS';
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - SAS issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
  }
  ngOnInit() {
    this.form = new FormGroup({});
    this.form2 = new FormGroup({});
    this.form2.addControl('DataSet', new FormControl());
    this.DataSets = this.ss.getDataSetsToLoad();
    this.PlaceholderDataSets = this.DataSets[0].label;
    // console.log('Initilized');
    // console.log(this.message);
  }
  ngOnChanges(changes: SimpleChanges) {
    // console.log(`ngOnChanges - data is ${this.message}`);
    // tslint:disable-next-line:forin
    for (const key in changes) {
      // console.log(`${key} changed. Current: ${changes[key].currentValue}. Previous: ${changes[key].previousValue}`);
    }
  }
  /////////////////// Data loads here
  receiveFromFileServiceProgress($event: ChannelEvent) {
    // this.ref.detectChanges();
    // // console.log($event);
    this.items.push($event);
    // console.log(this.items);
    this.message = $event;
    // setTimeout(() => {
    this.cdr.detectChanges();
    // }, 1);
  }
  connectToSASTest() {
    this.showspinner = true;
    this.eventName = 'sas';
    // this.showspinner = false;
    this.as.connectToSAS(this.server, this.channelService.connectionID$, this.user.name, this.user.machine, this.eventName, this.eventName,
      this.ss.getPass(), this.env).subscribe(
        res => {
          // console.log(res);
          this.showspinner = false;
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          // this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
          //   res1 => {
          //     ///////////////////////// Cleaning server and web folder
          //     for (let i = 0; i < res.length; i++) {
          //       if (res[i] !== null) {
          //         const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
          //         // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
          //         const filenamefullpath = env + filename;
          //         let vv: CleanFileAndServer;
          //         if (i === 0) {
          //           vv = {
          //             fullfilename: res[i],
          //             qryname: 'none',
          //             c: ''
          //           };
          //         } else {
          //           vv = {
          //             fullfilename: res[i],
          //             qryname: 'none',
          //             c: ''
          //           };
          //         }
          //         // // console.log(vv);
          //         this.ss.cleanFileServer(this.server, vv).subscribe(
          //           () => { }, err1 => { });
          //       }
          //     }
          //     ///////////////////////// --------------- Cleaning all - web and oracle - END
          //   }, err => {
          //   });
        },
        err => { });
  }
  ////////////////// Data loads end here
}
