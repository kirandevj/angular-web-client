import { Component, ViewEncapsulation, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { LossRatio, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
// import { HealthReportsData, RunProcess, LocalVariables } from '../../shared/datamodels';
// import { HealthServices } from '../../shared/health.services';
import { FooterComponent } from '@app/common/index';
import { ChannelEvent, ChannelService } from '@app/services/channel.sevice';
import { BehaviorSubject } from 'rxjs';
import { ActuarialServices } from '../shared/actuarial.services';
import { SASGenericReport } from '../shared/datamodels';

@Component({
  templateUrl: './wc-rate-loss-analysis.html',
  styleUrls: ['./wc-rate-loss-analysis.css']
})
export class SASWCRateLossAnalysisComponent implements OnInit {
  @Input() message: ChannelEvent = {
    Name: '',
    ChannelName: '',
    Timestamp: (new Date(Date.now() - ((new Date()).getTimezoneOffset() * 60000))).toISOString().slice(0, -1),
    Data: {
      State: 'Process info here',
      PercentComplete: 0,
      FileNames: [],
      json: ''
    },
    Json: ''
  };
  items: ChannelEvent[] = [];
  items$ = new BehaviorSubject(this.items);
  env = '';
  sentToSignalRChannel = 'saswcratelossanalysis';
  receivedFromService = '';
  eventName: string;
  report: SASGenericReport = {
    reportname: '',
    exchanges: [],
    asofyr: 0,
    asofmm: 0,
    id: '',
    qryname: '',
    username: '',
    machinename: '',
    env: '',
    c: '',
    channel: '',
    eventname: '',
    signalr: ''
  };
  showspinner = false;
  user: UserInfo;
  sendtofooter: FooterInfo;
  sendtofileloadermessages: any[] = ['', true];
  form: FormGroup;
  Products: Array<Selection>;
  PlaceHolderProducts: string;
  Years: Array<Selection>;
  PlaceholderYears: string;
  Months: Array<Selection>;
  PlaceholderMonths: string;
  PlaceholderStates = 'CA, FL, NY, TX';
  server: string;
  image0: string;
  image1: string;
  reportsInfo: boolean;
  theDateClient: Date;
  // ReportsArray: Array<RunProcess>;
  variablesHome: string;
  constructor(
    private ss: SharedServices,
    private gv: GlobalVariables,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef,
    private as: ActuarialServices,
    private channelService: ChannelService
  ) {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.variablesHome = this.sentToSignalRChannel;
    this.eventName = this.sentToSignalRChannel;
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - WC Rate & Loss Analysis page issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
  }
  ngOnInit() {
    this.form = new FormGroup({});
    this.form.addControl('Product', new FormControl());
    this.form.addControl('Year', new FormControl());
    this.form.addControl('Month', new FormControl());
    this.form.addControl('States', new FormControl());
    this.Years = this.ss.getYears();
    this.Months = this.ss.getMonths();
    this.PlaceholderYears = this.ss.getYearsHolderFds();
    this.PlaceholderMonths = this.ss.getMonthsHolderSds();
    this.sendtofileloadermessages[0] = this.server;
    this.sendtofileloadermessages[1] = true;
    this.Products = this.ss.getProductsMedicalAll();
    this.PlaceHolderProducts = this.Products[5].label;
    this.theDateClient = this.ss.getDateForCalendarString(+this.PlaceholderYears, +this.PlaceholderMonths, -17, 'start');
    document.getElementById('theDateClient')['valueAsDate'] = this.theDateClient;
    console.log(this.theDateClient);
    this.items.push(this.message);
  }
  /////////////////// Data loads here
  receiveFromFileServiceProgress($event: ChannelEvent) {
    this.items.push($event);
    console.log($event);
    this.message = $event;
    this.cdr.detectChanges();
    if ($event.Data.FileNames.length > 0) {
      const allowedfiles = ['xlsx', 'csv'];
      const env = this.gv.get('excelfiledownload', 'excelfiledownload');
      // console.log($event.Data.FileNames);
      this.showspinner = false;
      this.ss.downloadFilesFromSignalRService($event.Data.FileNames, env, allowedfiles, true, this.server);
    }
  }
  GetExcelFile(f: any): void {
    this.showspinner = true;
    this.report.qryname = this.ss.getQueryName('AC', 'FR', 0);
    this.report.reportname = 'WC Rate & Loss Analysis';
    this.report.exchanges = [this.ss.getFormValue(f.Product, this.PlaceHolderProducts, this.Products, 'value', 'label')];
    this.report.asofyr = +this.ss.getFormValue(f.Year, this.PlaceholderYears, this.Years, 'value', 'label');
    this.report.asofmm = +this.ss.getFormValue(f.Month, this.PlaceholderMonths, this.Months, 'value', 'label');
    this.report.id = (this.ss.getFormValueInputImproved(document.getElementById('states')['value'], '')).toLocaleUpperCase();
    this.report.clientdatesmaturity = this.ss.getDateFromHTMLInput(document.getElementById('theDateClient')['value']);
    this.report.username = this.user.name;
    this.report.machinename = this.user.machine;
    this.report.c = this.ss.getPass();
    this.report.env = this.gv.get('excelfilesave', 'excelfilesave');
    this.report.channel = this.eventName;
    this.report.eventname = this.eventName;
    this.report.signalr = this.channelService.connectionID$;
    if (this.report.id.length === 0) {
      this.report.id = this.PlaceholderStates;
    }
    // this.connectToSASTest();
    //////////////////// Subscribing to process here
    this.as.getSASActuarialGenericReporting(this.server, this.report).subscribe(
      res => { },
      err => { });
  }
}
