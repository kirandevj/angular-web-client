import { Component, ViewEncapsulation, OnInit, OnDestroy, ChangeDetectionStrategy } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActuarialServices } from '../shared/actuarial.services';
import { SharedServices, GlobalVariables, GlobalObservables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { LossRatio, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { LocalVariables, RunProcess } from '../shared/local.variables';
import { VizIncomingInitialInfo } from '@app/datamodels/index';
import { Subscription } from 'rxjs';

@Component({
  templateUrl: './visualized.html',
  styles: [`
  form {
    /* color: #0000ff;
    font-size: 14px;
    line-height: 1.42857143;
    background-color: #9999ff;
    background-image: none;
    */
    display: block;
    padding: 12px 12px;
    border: 4px solid #8080ff;
    border-radius: 10px;
  }
  .nav.navbar-nav {font-size: 15px;}
  li > a { color: aliceblue; }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class VisualizedComponent implements OnInit, OnDestroy {
  showspinner: boolean;
  option2: Selection[] = [
    { value: 0, label: 'PLAN_NAME_SHORT' }
  ];
  option2Medical: Selection[] = [
    { value: 0, label: 'PLAN_NAME_SHORT' }
  ];
  option2Dental: Selection[] = [
    { value: 0, label: 'BN_PLAN_NAME' }
  ];
  option2Elig: Selection[] = [
    { value: 0, label: 'By company ID' },
    { value: 1, label: 'By state' }
  ];
  plans: Selection[] = [
    { value: 0, label: 'ACO 1000' },
    { value: 1, label: 'ACO 25' },
    { value: 2, label: 'ACO 2500' },
    { value: 3, label: 'ACO 2750' },
    { value: 4, label: 'ACO 3500' },
    { value: 5, label: 'ACO 40' },
    { value: 6, label: 'ACO 6350' },
    { value: 7, label: 'ACO 6500' },
    { value: 8, label: 'Aetna HDHP' },
    { value: 9, label: 'Aetna HMO' },
    { value: 10, label: 'Aetna HNO' },
    { value: 11, label: 'Aetna IND' },
    { value: 12, label: 'Aetna MCPOS' },
    { value: 13, label: 'Aetna PPO' },
    { value: 14, label: 'BSCA HDHP' },
    { value: 15, label: 'BSCA HMO' },
    { value: 16, label: 'BSCA PPO' },
    { value: 17, label: 'Core 0' },
    { value: 18, label: 'Core 1000' },
    { value: 19, label: 'Core 1000 IL' },
    { value: 20, label: 'Core 2500' },
    { value: 21, label: 'Core 2500 IL' },
    { value: 22, label: 'Core 500' },
    { value: 23, label: 'Core 500 IL' },
    { value: 24, label: 'Core 5000' },
    { value: 25, label: 'Core 5000 IL' },
    { value: 26, label: 'CPOS 20' },
    { value: 27, label: 'CPOS 30' },
    { value: 28, label: 'EPO 0' },
    { value: 29, label: 'EPO 1000' },
    { value: 30, label: 'EPO 2000' },
    { value: 31, label: 'EPO 25' },
    { value: 32, label: 'EPO 30' },
    { value: 33, label: 'EPO 3000' },
    { value: 34, label: 'EPO 4000' },
    { value: 35, label: 'EPO 45' },
    { value: 36, label: 'EPO 500' },
    { value: 37, label: 'EPO SP 1000' },
    { value: 38, label: 'EPO SP 4000' },
    { value: 39, label: 'FLBLUE HDHP' },
    { value: 40, label: 'FLBLUE HMO' },
    { value: 41, label: 'FLBLUE PPO' },
    { value: 42, label: 'HDHP 2500' },
    { value: 43, label: 'HDHP 2600' },
    { value: 44, label: 'HDHP 2700' },
    { value: 45, label: 'HDHP 3000' },
    { value: 46, label: 'HDHP 5500' },
    { value: 47, label: 'HDHP 6350' },
    { value: 48, label: 'HMO 0' },
    { value: 49, label: 'HMO 1000' },
    { value: 50, label: 'HMO 20' },
    { value: 51, label: 'HMO 2000' },
    { value: 52, label: 'HMO 25' },
    { value: 53, label: 'HMO 2600' },
    { value: 54, label: 'HMO 30' },
    { value: 55, label: 'HMO 3000' },
    { value: 56, label: 'HMO 35' },
    { value: 57, label: 'HMO 35/1000' },
    { value: 58, label: 'HMO 35/1500' },
    { value: 59, label: 'HMO 3500' },
    { value: 60, label: 'HMO 40' },
    { value: 61, label: 'HMO 4500' },
    { value: 62, label: 'HMO 6350' },
    { value: 63, label: 'HMO HDHP 5000' },
    { value: 64, label: 'HMO Value 30' },
    { value: 65, label: 'HMO/HDHP 2600' },
    { value: 66, label: 'HMO/HDHP 4500' },
    { value: 67, label: 'HNO 0' },
    { value: 68, label: 'HNO 1000' },
    { value: 69, label: 'HNO 1500' },
    { value: 70, label: 'HNO 25 1' },
    { value: 71, label: 'HNO 35 2' },
    { value: 72, label: 'HNO 35 3' },
    { value: 73, label: 'HNO 35 4' },
    { value: 74, label: 'HNO 5000' },
    { value: 75, label: 'HNO 6350' },
    { value: 76, label: 'Indemnity 1000' },
    { value: 77, label: 'Indemnity 500' },
    { value: 78, label: 'Kaiser HMO' },
    { value: 79, label: 'KHN1' },
    { value: 80, label: 'KHS1' },
    { value: 81, label: 'KND1' },
    { value: 82, label: 'KNH1' },
    { value: 83, label: 'KSD1' },
    { value: 84, label: 'POS' },
    { value: 85, label: 'POS 1000' },
    { value: 86, label: 'POS 15' },
    { value: 87, label: 'POS 1500' },
    { value: 88, label: 'POS 20' },
    { value: 89, label: 'POS 2000' },
    { value: 90, label: 'POS 25 1' },
    { value: 91, label: 'POS 2500' },
    { value: 92, label: 'POS 30' },
    { value: 93, label: 'POS 30 Premier' },
    { value: 94, label: 'POS 35 2' },
    { value: 95, label: 'POS 35 3' },
    { value: 96, label: 'POS 4000' },
    { value: 97, label: 'POS 45 Smart' },
    { value: 98, label: 'POS 500' },
    { value: 99, label: 'POS/HDHP 2600' },
    { value: 100, label: 'PPO 0' },
    { value: 101, label: 'PPO 100' },
    { value: 102, label: 'PPO 1000' },
    { value: 103, label: 'PPO 1500' },
    { value: 104, label: 'PPO 2000' },
    { value: 105, label: 'PPO 250' },
    { value: 106, label: 'PPO 2500' },
    { value: 107, label: 'PPO 300' },
    { value: 108, label: 'PPO 3000' },
    { value: 109, label: 'PPO 3500' },
    { value: 110, label: 'PPO 4000' },
    { value: 111, label: 'PPO 500' },
    { value: 112, label: 'PPO 5000' },
    { value: 113, label: 'PPO 5000/30' },
    { value: 114, label: 'PPO 5000/35' },
    { value: 115, label: 'PPO 5500' },
    { value: 116, label: 'PPO 6350' },
    { value: 117, label: 'PPO 700' },
    { value: 118, label: 'PPO 750' },
    { value: 119, label: 'PPO/HDHP 3000' },
    { value: 120, label: 'Primary 1000' },
    { value: 121, label: 'Primary 1500' },
    { value: 122, label: 'Primary 2500' },
    { value: 123, label: 'Primary 500' },
    { value: 124, label: 'Primary 5000' },
    { value: 125, label: 'QPOS 35 2' },
    { value: 126, label: 'QPOS 35 3' },
    { value: 127, label: 'UA00' },
    { value: 128, label: 'UE00' },
    { value: 129, label: 'UF00' },
    { value: 130, label: 'UH00' },
    { value: 131, label: 'UHCBPPO1000' },
    { value: 132, label: 'UHCBPPO2500' },
    { value: 133, label: 'UHCBPPO500' },
    { value: 134, label: 'UI00' },
    { value: 135, label: 'UK00' },
    { value: 136, label: 'UL00' },
    { value: 137, label: 'UM00' },
    { value: 138, label: 'UN00' },
    { value: 139, label: 'UP00' },
    { value: 140, label: 'UR00' },
    { value: 141, label: 'USPR' },
    { value: 142, label: 'Value HMO 40' }
  ];
  plansMedical: Selection[] = [
    { value: 0, label: 'ACO 1000' },
    { value: 1, label: 'ACO 25' },
    { value: 2, label: 'ACO 2500' },
    { value: 3, label: 'ACO 2750' },
    { value: 4, label: 'ACO 3500' },
    { value: 5, label: 'ACO 40' },
    { value: 6, label: 'ACO 6350' },
    { value: 7, label: 'ACO 6500' },
    { value: 8, label: 'Aetna HDHP' },
    { value: 9, label: 'Aetna HMO' },
    { value: 10, label: 'Aetna HNO' },
    { value: 11, label: 'Aetna IND' },
    { value: 12, label: 'Aetna MCPOS' },
    { value: 13, label: 'Aetna PPO' },
    { value: 14, label: 'BSCA HDHP' },
    { value: 15, label: 'BSCA HMO' },
    { value: 16, label: 'BSCA PPO' },
    { value: 17, label: 'Core 0' },
    { value: 18, label: 'Core 1000' },
    { value: 19, label: 'Core 1000 IL' },
    { value: 20, label: 'Core 2500' },
    { value: 21, label: 'Core 2500 IL' },
    { value: 22, label: 'Core 500' },
    { value: 23, label: 'Core 500 IL' },
    { value: 24, label: 'Core 5000' },
    { value: 25, label: 'Core 5000 IL' },
    { value: 26, label: 'CPOS 20' },
    { value: 27, label: 'CPOS 30' },
    { value: 28, label: 'EPO 0' },
    { value: 29, label: 'EPO 1000' },
    { value: 30, label: 'EPO 2000' },
    { value: 31, label: 'EPO 25' },
    { value: 32, label: 'EPO 30' },
    { value: 33, label: 'EPO 3000' },
    { value: 34, label: 'EPO 4000' },
    { value: 35, label: 'EPO 45' },
    { value: 36, label: 'EPO 500' },
    { value: 37, label: 'EPO SP 1000' },
    { value: 38, label: 'EPO SP 4000' },
    { value: 39, label: 'FLBLUE HDHP' },
    { value: 40, label: 'FLBLUE HMO' },
    { value: 41, label: 'FLBLUE PPO' },
    { value: 42, label: 'HDHP 2500' },
    { value: 43, label: 'HDHP 2600' },
    { value: 44, label: 'HDHP 2700' },
    { value: 45, label: 'HDHP 3000' },
    { value: 46, label: 'HDHP 5500' },
    { value: 47, label: 'HDHP 6350' },
    { value: 48, label: 'HMO 0' },
    { value: 49, label: 'HMO 1000' },
    { value: 50, label: 'HMO 20' },
    { value: 51, label: 'HMO 2000' },
    { value: 52, label: 'HMO 25' },
    { value: 53, label: 'HMO 2600' },
    { value: 54, label: 'HMO 30' },
    { value: 55, label: 'HMO 3000' },
    { value: 56, label: 'HMO 35' },
    { value: 57, label: 'HMO 35/1000' },
    { value: 58, label: 'HMO 35/1500' },
    { value: 59, label: 'HMO 3500' },
    { value: 60, label: 'HMO 40' },
    { value: 61, label: 'HMO 4500' },
    { value: 62, label: 'HMO 6350' },
    { value: 63, label: 'HMO HDHP 5000' },
    { value: 64, label: 'HMO Value 30' },
    { value: 65, label: 'HMO/HDHP 2600' },
    { value: 66, label: 'HMO/HDHP 4500' },
    { value: 67, label: 'HNO 0' },
    { value: 68, label: 'HNO 1000' },
    { value: 69, label: 'HNO 1500' },
    { value: 70, label: 'HNO 25 1' },
    { value: 71, label: 'HNO 35 2' },
    { value: 72, label: 'HNO 35 3' },
    { value: 73, label: 'HNO 35 4' },
    { value: 74, label: 'HNO 5000' },
    { value: 75, label: 'HNO 6350' },
    { value: 76, label: 'Indemnity 1000' },
    { value: 77, label: 'Indemnity 500' },
    { value: 78, label: 'Kaiser HMO' },
    { value: 79, label: 'KHN1' },
    { value: 80, label: 'KHS1' },
    { value: 81, label: 'KND1' },
    { value: 82, label: 'KNH1' },
    { value: 83, label: 'KSD1' },
    { value: 84, label: 'POS' },
    { value: 85, label: 'POS 1000' },
    { value: 86, label: 'POS 15' },
    { value: 87, label: 'POS 1500' },
    { value: 88, label: 'POS 20' },
    { value: 89, label: 'POS 2000' },
    { value: 90, label: 'POS 25 1' },
    { value: 91, label: 'POS 2500' },
    { value: 92, label: 'POS 30' },
    { value: 93, label: 'POS 30 Premier' },
    { value: 94, label: 'POS 35 2' },
    { value: 95, label: 'POS 35 3' },
    { value: 96, label: 'POS 4000' },
    { value: 97, label: 'POS 45 Smart' },
    { value: 98, label: 'POS 500' },
    { value: 99, label: 'POS/HDHP 2600' },
    { value: 100, label: 'PPO 0' },
    { value: 101, label: 'PPO 100' },
    { value: 102, label: 'PPO 1000' },
    { value: 103, label: 'PPO 1500' },
    { value: 104, label: 'PPO 2000' },
    { value: 105, label: 'PPO 250' },
    { value: 106, label: 'PPO 2500' },
    { value: 107, label: 'PPO 300' },
    { value: 108, label: 'PPO 3000' },
    { value: 109, label: 'PPO 3500' },
    { value: 110, label: 'PPO 4000' },
    { value: 111, label: 'PPO 500' },
    { value: 112, label: 'PPO 5000' },
    { value: 113, label: 'PPO 5000/30' },
    { value: 114, label: 'PPO 5000/35' },
    { value: 115, label: 'PPO 5500' },
    { value: 116, label: 'PPO 6350' },
    { value: 117, label: 'PPO 700' },
    { value: 118, label: 'PPO 750' },
    { value: 119, label: 'PPO/HDHP 3000' },
    { value: 120, label: 'Primary 1000' },
    { value: 121, label: 'Primary 1500' },
    { value: 122, label: 'Primary 2500' },
    { value: 123, label: 'Primary 500' },
    { value: 124, label: 'Primary 5000' },
    { value: 125, label: 'QPOS 35 2' },
    { value: 126, label: 'QPOS 35 3' },
    { value: 127, label: 'UA00' },
    { value: 128, label: 'UE00' },
    { value: 129, label: 'UF00' },
    { value: 130, label: 'UH00' },
    { value: 131, label: 'UHCBPPO1000' },
    { value: 132, label: 'UHCBPPO2500' },
    { value: 133, label: 'UHCBPPO500' },
    { value: 134, label: 'UI00' },
    { value: 135, label: 'UK00' },
    { value: 136, label: 'UL00' },
    { value: 137, label: 'UM00' },
    { value: 138, label: 'UN00' },
    { value: 139, label: 'UP00' },
    { value: 140, label: 'UR00' },
    { value: 141, label: 'USPR' },
    { value: 142, label: 'Value HMO 40' }
  ];
  plansDental: Selection[] = [
    { value: 0, label: 'MetLife Voluntary Dental' },
    { value: 1, label: 'MetLife Vol Dental TX/MT/MS/LA' },
    { value: 2, label: 'MetLife Standard' },
    { value: 3, label: 'MetLife Premium' },
    { value: 4, label: 'MetLife Enhanced TX/MT/MS/LA' },
    { value: 5, label: 'MetLife Enhanced' },
    { value: 6, label: 'MetLife Dental 50 Optional' },
    { value: 7, label: 'MetLife Dental 50 Opt NV/VA' },
    { value: 8, label: 'MetLife Dental 50 Group NV/VA' },
    { value: 9, label: 'MetLife Dental 50 Group' },
    { value: 10, label: 'MetLife Dental 100 Optional' },
    { value: 11, label: 'MetLife Dental 100 Opt NV/VA' },
    { value: 12, label: 'MetLife Dental 100 Group NV/VA' },
    { value: 13, label: 'MetLife Dental 100 Group' },
    { value: 14, label: 'Guardian Low PPO Optional NTL' },
    { value: 15, label: 'Guardian Low PPO Optional' },
    { value: 16, label: 'Guardian Low PPO Opt NV/VA' },
    { value: 17, label: 'Guardian Low PPO Group NV/VA' },
    { value: 18, label: 'Guardian Low PPO Group NTL' },
    { value: 19, label: 'Guardian Low PPO Group' },
    { value: 20, label: 'Guardian High PPO Optional NTL' },
    { value: 21, label: 'Guardian High PPO Optional' },
    { value: 22, label: 'Guardian High PPO Opt VA' },
    { value: 23, label: 'Guardian High PPO Opt NV/VA' },
    { value: 24, label: 'Guardian High PPO Opt NV' },
    { value: 25, label: 'Guardian High PPO Opt' },
    { value: 26, label: 'Guardian High PPO Grp VA' },
    { value: 27, label: 'Guardian High PPO Grp NV' },
    { value: 28, label: 'Guardian High PPO Group NV/VA' },
    { value: 29, label: 'Guardian High PPO Group NTL' },
    { value: 30, label: 'Guardian High PPO Group' },
    { value: 31, label: 'Guardian Dental Optional NV VA' },
    { value: 32, label: 'Guardian Dental Optional' },
    { value: 33, label: 'Guardian Dental Group NV VA' },
    { value: 34, label: 'Guardian Dental Group' },
    { value: 35, label: 'Guardian Dental EPO Optional' },
    { value: 36, label: 'Guardian Dental EPO Group' },
    { value: 37, label: 'Guardian Dental EPO' },
    { value: 38, label: 'Guardian Dental 50 Optional' },
    { value: 39, label: 'Guardian Dental 50 Group' },
    { value: 40, label: 'Guardian Dental 100 Optional' },
    { value: 41, label: 'Guardian Dental 100 Group' },
    { value: 42, label: 'DeltaDentalEnhancedTX/MT/MS/LA' },
    { value: 43, label: 'Delta Dental Voluntary VA' },
    { value: 44, label: 'Delta Dental Voluntary' },
    { value: 45, label: 'Delta Dental Vol TX/MT/MS/LA' },
    { value: 46, label: 'Delta Dental Standard VA' },
    { value: 47, label: 'Delta Dental Standard NV' },
    { value: 48, label: 'Delta Dental Standard' },
    { value: 49, label: 'Delta Dental Premium VA' },
    { value: 50, label: 'Delta Dental Premium NV' },
    { value: 51, label: 'Delta Dental Premium' },
    { value: 52, label: 'Delta Dental Enhanced VA' },
    { value: 53, label: 'Delta Dental Enhanced NV' },
    { value: 54, label: 'Delta Dental Enhanced' },
    { value: 55, label: 'Delta Dental DMO Optional' },
    { value: 56, label: 'Delta Dental DMO Group' },
    { value: 57, label: 'Delta Dental 50 VA Optional' },
    { value: 58, label: 'Delta Dental 50 VA Group' },
    { value: 59, label: 'Delta Dental 50 Optional' },
    { value: 60, label: 'Delta Dental 50 Opt VA' },
    { value: 61, label: 'Delta Dental 50 Opt NV/VA' },
    { value: 62, label: 'Delta Dental 50 Opt NV' },
    { value: 63, label: 'Delta Dental 50 Group VA' },
    { value: 64, label: 'Delta Dental 50 Group NV/VA' },
    { value: 65, label: 'Delta Dental 50 Group NV' },
    { value: 66, label: 'Delta Dental 50 Group' },
    { value: 67, label: 'Delta Dental 50 FL Optional' },
    { value: 68, label: 'Delta Dental 50 FL Group' },
    { value: 69, label: 'Delta Dental 100 VA Optional' },
    { value: 70, label: 'Delta Dental 100 VA Group' },
    { value: 71, label: 'Delta Dental 100 Optional' },
    { value: 72, label: 'Delta Dental 100 Opt VA' },
    { value: 73, label: 'Delta Dental 100 Opt NV/VA' },
    { value: 74, label: 'Delta Dental 100 Opt NV' },
    { value: 75, label: 'Delta Dental 100 Group VA' },
    { value: 76, label: 'Delta Dental 100 Group NV/VA' },
    { value: 77, label: 'Delta Dental 100 Group NV' },
    { value: 78, label: 'Delta Dental 100 Group' },
    { value: 79, label: 'Delta Dental 100 FL Optional' },
    { value: 80, label: 'Delta Dental 100 FL Group' },
    { value: 81, label: 'Aetna Dental EPP Optional' },
    { value: 82, label: 'Aetna Dental EPP Group' },
    { value: 83, label: 'Aetna Dental DMO Optional' },
    { value: 84, label: 'Aetna Dental DMO Group' },
    { value: 85, label: 'Aetna Dental 50 Optional' },
    { value: 86, label: 'Aetna Dental 50 Opt NV/VA' },
    { value: 87, label: 'Aetna Dental 50 Group NV/VA' },
    { value: 88, label: 'Aetna Dental 50 Group' },
    { value: 89, label: 'Aetna Dental 100 Optional' },
    { value: 90, label: 'Aetna Dental 100 Opt NV/VA' },
    { value: 91, label: 'Aetna Dental 100 Group NV/VA' },
    { value: 92, label: 'Aetna Dental 100 Group' }
  ];
  plansElig: Selection[] = [{ value: 0, label: 'n/a' }];
  data: Selection[] = [
    { value: 0, label: 'MEMBER_COUNT' },
    { value: 1, label: 'EE_PREMIUM_COST' },
    { value: 2, label: 'CO_PREMIUM_COST' },
    { value: 3, label: 'RATEBOOK_PREMIUM' },
    { value: 4, label: 'PAYIN_AMOUNT' },
    { value: 5, label: 'RATEBOOK_PAYIN_RATE' },
    { value: 6, label: 'DIFFERENCE' },
    { value: 7, label: 'PAYIN_DIFFERENCE' },
    { value: 8, label: 'TOTAL_PREMIUM' }
  ];
  dataElig: Selection[] = [
    { value: 0, label: 'Participation Rates' }
    // ,
    // { value: 1, label: 'Profitability' }
  ];
  sendtochartinfo: VizIncomingInitialInfo = {
    Product: '',
    InfoToPresent: '',
    ID: '',
    StartDate: '',
    EndDate: '',
    Option1: '',
    Option2: '',
    Source: '',
    qryname: '',
    username: '',
    c: '',
    env: '',
    transportedinfo: ['']
  };
  user: UserInfo;
  sendtofooter: FooterInfo;
  form: FormGroup;
  Products: Array<Selection>;
  PlaceholderProducts: string;
  Sources: Array<Selection>;
  PlaceholderSources: string;
  Options1: Array<Selection>;
  PlaceholderOptions1: string;
  Options2: Array<Selection>;
  Data: Array<Selection>;
  PlaceholderOptions2: string;
  Included: Array<Selection>;
  PlaceholderIncluded: string;
  PlaceholderData: string;
  startdate: Date;
  enddate: Date;
  ID: string;
  PlaceholderID = '';
  server: string;
  image0: string;
  image1: string;
  ////////////////////// Subscriptions
  vizInfoSubscription: Subscription;
  message: any;
  subscription: Subscription;
  constructor(private rfs: ActuarialServices, private ss: SharedServices,
    private gv: GlobalVariables, private route: ActivatedRoute, private lv: LocalVariables,
    private glo: GlobalObservables) {
    // this.vizInfoSubscription = this.glo.currentExchangeInfo.subscribe(x => {
    //   // // // console.log('Received within Visulized component on the subscription level');
    //   // // // console.log(x);
    // });
    this.subscription = this.glo.getMessage().subscribe(x => {
      if (x === 'true') {
        this.showspinner = false;
      }
    });
  }
  ngOnDestroy() {
    if (this.vizInfoSubscription) {
      this.vizInfoSubscription.unsubscribe();
    }
  }
  ngOnInit() {
    this.showspinner = false;
    // const dt = new Date();
    // this.startdate = new Date(dt.getFullYear(), 0, 1);
    // this.enddate = new Date(dt.getFullYear(), dt.getMonth(), this.ss.getLastDay(dt.getFullYear(), dt.getMonth()));
    this.startdate = new Date((new Date()).getTime() - (new Date()).getTimezoneOffset() * 60000);
    this.enddate = new Date((new Date()).getTime() - (new Date()).getTimezoneOffset() * 60000);
    this.startdate.setMonth(this.enddate.getMonth() - 12);
    document.getElementById('startdate')['valueAsDate'] = this.startdate;
    document.getElementById('enddate')['valueAsDate'] = this.enddate;

    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();

    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.form.addControl('Product', new FormControl());
    this.form.addControl('Source', new FormControl());
    this.form.addControl('Option1', new FormControl());
    this.form.addControl('Option2', new FormControl());
    this.form.addControl('Include', new FormControl());
    this.form.addControl('Data', new FormControl());
    this.form.addControl('ID', new FormControl());
    this.Products = this.ss.getProductsMedicalAll();
    this.PlaceholderProducts = this.Products[0].label;
    this.Sources = this.ss.getHealthOptionsData();
    this.PlaceholderSources = this.Sources[0].label;
    this.Options1 = this.ss.getHealthOptionsFPF();
    this.PlaceholderOptions1 = this.Options1[0].label;
    this.Options2 = this.option2;
    this.Data = this.data;
    this.PlaceholderOptions2 = this.Options2[0].label;
    this.Included = this.plans;
    this.PlaceholderIncluded = this.plans[0].label;
    this.PlaceholderData = this.data[0].label;
    // https://basvandenberg.github.io/ng-select/#/examples/option-template
    this.user = this.ss.getCache('localStorage', 'user', 'object');

  }
  getData(f: any) {
    this.pullDataFromMultiSelect(this.PlaceholderIncluded, f.Include, this.plans);
    this.sendtochartinfo.qryname = this.ss.getQueryName('V', 'CH', 0);
    this.sendtochartinfo.c = this.ss.getPass();
    this.sendtochartinfo.env = this.gv.get('excelfilesave', 'excelfilesave');
    this.sendtochartinfo.username = this.user.name;
    this.sendtochartinfo.ID = f.ID;
    this.sendtochartinfo.StartDate = this.ss.getDateFromHTMLInput(document.getElementById('startdate')['value']);
    this.sendtochartinfo.EndDate = this.ss.getDateFromHTMLInput(document.getElementById('enddate')['value']);
    this.sendtochartinfo.Product = this.ss.getFormValue(f.Product, this.PlaceholderProducts, this.Products, 'value', 'label');
    this.sendtochartinfo.Source = this.ss.getFormValue(f.Source, this.PlaceholderSources, this.Sources, 'value', 'label');
    this.sendtochartinfo.Option1 = this.ss.getFormValue(f.Option1, this.PlaceholderOptions1, this.Options1, 'value', 'label');
    this.sendtochartinfo.Option2 = this.ss.getFormValue(f.Option2, this.PlaceholderOptions2, this.Options2, 'value', 'label');
    this.sendtochartinfo.InfoToPresent = this.ss.getFormValue(f.Data, this.PlaceholderData, this.Data, 'value', 'label');
    this.sendtochartinfo.transportedinfo = this.pullDataFromMultiSelect(this.PlaceholderIncluded, f.Include, this.plans);
    if (this.sendtochartinfo.ID === null) {
      this.sendtochartinfo.ID = '';
    }
    // // console.log(this.sendtochartinfo);
    this.showspinner = true;
    this.glo.sendMessage(this.sendtochartinfo);
  }
  selected(v: any): void {
    // // console.log(v);
    if (v.label === 'Eligibility') {
      this.Options2 = this.option2Elig;
      this.PlaceholderOptions2 = this.Options2[0].label;
      this.Included = this.plansElig;
      this.Data = this.dataElig;
      this.PlaceholderIncluded = this.plansElig[0].label;
      this.PlaceholderData = this.dataElig[0].label;
    } else {
      if (v.label === 'Medical' || v.label === 'Dental') {
        this.form.reset();
        this.plans = this['plans' + v.label];
        this.Options2 = this['option2' + v.label];
        this.PlaceholderOptions2 = this['option2' + v.label][0].label;
        this.Included = this['plans' + v.label];
        this.PlaceholderIncluded = this['plans' + v.label][0].label;
      }
    }
  }
  pullDataFromMultiSelect(ph: string, arr: number[], arrmain: Selection[]): string[] {
    const r: string[] = [];
    let t: number[];
    // // console.log(ph);
    // // console.log(arr);
    if (arr === null) {
      r.push(ph);
    } else {
      if (arr.length !== 0) {
        t = JSON.parse(JSON.stringify(arr));
        t.map(x => {
          r.push(arrmain.filter(y => y.value > x)[0].label);
          return x;
        });
      } else {
        r.push(ph);
      }
    }
    return r;
  }
}
