import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SelectModule } from 'angular2-select';
import { ActNavBarComponent } from './nav/act-navbar.component';
import { ActuarialComponent } from './actuarial.component';
import { WCModelComponent } from './wcmodel/wc-model.component';
import { ActuarialTrianglesComponent } from './actuarialtriangles/actuarial-triangles.component';
import { WSEComponent } from './wse/wse.component';
import { ActuarialRoutes } from './actuarial.routes';
import { ActuarialServices } from './shared/actuarial.services';
import { ApiServices } from '@app/common/index';
import { LocalVariables } from './shared/local.variables';
import { FooterModule } from '@app/common/index';
import { SpinnerModule } from '@app/common/index';
import { FileActionModule } from '../components/files/file-action.module';
import { RiskFinanceServices } from '../riskfinance/shared/risk-finance.service';
import { AdminFeeComponent } from './admin-fee/admin-fee.component';
import { SASComponent } from './sas/sas.component';
import { PreLoadedModule } from '../components/preloaded/pre-loaded.module';
import { ProgressInfoModule } from '../components/progress-info/progress-info.module';
import { VisualizedComponent } from './visualized/visualized.component';
import { ChartModule } from '../components/chart/chart.module';
import { ChartServices } from '../components/chart/chart.services';
import { FinanceReportingComponent } from './finance-reporting/finance-reporting.components';
import { SASPremiumClaimsComponent } from './premium-claims/premium-claims.component';
import { SASMLRSComponent } from './mlrs/mlrs.component';
import { SASMRPSComponent } from './mrps/mrps.component';
import { SASWCRateLossAnalysisComponent } from './wc-rate-loss-analysis/wc-rate-loss-analysis.component';
@NgModule({
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(ActuarialRoutes),
    SelectModule,
    FooterModule,
    SpinnerModule,
    FileActionModule,
    PreLoadedModule,
    ChartModule,
    ProgressInfoModule
  ],
  declarations: [
    ActNavBarComponent,
    ActuarialComponent,
    WCModelComponent,
    ActuarialTrianglesComponent,
    WSEComponent,
    AdminFeeComponent,
    VisualizedComponent,
    FinanceReportingComponent,
    SASComponent,
    SASPremiumClaimsComponent,
    SASMLRSComponent,
    SASMRPSComponent,
    SASWCRateLossAnalysisComponent
  ],
  providers: [
    RiskFinanceServices,
    ActuarialServices,
    ApiServices,
    LocalVariables
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ActuarialModule {
  constructor(private _myService: ChartServices) { }
}
