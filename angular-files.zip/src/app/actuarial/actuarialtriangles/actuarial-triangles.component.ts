import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, ValidatorFn } from '@angular/forms';
import { ActuarialServices } from '../shared/actuarial.services';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { LossRatio, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { LocalVariables, RunProcess, RunProcessObject } from '../shared/local.variables';


@Component({
  templateUrl: './actuarial-triangles.html',
  styles: [`
  form {
    /* color: #0000ff;
    font-size: 14px;
    line-height: 1.42857143;
    background-color: #9999ff;
    background-image: none;
    */
    display: block;
    padding: 12px 12px;
    border: 4px solid #8080ff;
    border-radius: 10px;
  }
  `]
})
export class ActuarialTrianglesComponent implements OnInit {
  choicesR1: ActrTrOptions[] = [
    { id: 0, name: 'Paid', style: {}, r: 1 },
    { id: 1, name: 'Indemnity Paid', style: {}, r: 1 },
    { id: 2, name: 'Medical Paid', style: {}, r: 1 },
    { id: 3, name: 'Open Paid', style: {}, r: 1 },
    { id: 4, name: 'Closed Paid', style: {}, r: 1 },
    { id: 5, name: 'Claims', style: {}, r: 1 },
    { id: 6, name: 'Capped Incurred 1M', style: {}, r: 1 },
    { id: 7, name: 'Excess 1M 2M Incurred', style: {}, r: 1 },
    { id: 8, name: 'Indemnity Payments Bucket', style: {}, r: 1 }
  ];
  choicesR2: ActrTrOptions[] = [
    { id: 0, name: 'Net Paid', style: {}, r: 2 },
    { id: 1, name: 'Indemnity Net Paid', style: {}, r: 2 },
    { id: 2, name: 'Medical Net Paid', style: {}, r: 2 },
    { id: 3, name: 'Open Net Paid', style: {}, r: 2 },
    { id: 4, name: 'Closed Net Paid', style: {}, r: 2 },
    { id: 5, name: 'Claims Over Deductible', style: {}, r: 2 },
    { id: 6, name: 'Capped Incurred 750', style: {}, r: 2 },
    { id: 7, name: 'Excess 750 1M Incurred', style: {}, r: 2 },
    { id: 8, name: 'Indemnity Reserves Bucket', style: {}, r: 2 }
  ];
  choicesR3: ActrTrOptions[] = [
    { id: 0, name: 'Reserves', style: {}, r: 3 },
    { id: 1, name: 'Indemnity Reserves', style: {}, r: 3 },
    { id: 2, name: 'Medical Reserves', style: {}, r: 3 },
    { id: 3, name: 'Open Reserves', style: {}, r: 3 },
    { id: 4, name: 'Closed Reserves', style: {}, r: 3 },
    { id: 5, name: 'Open Claims', style: {}, r: 3 },
    { id: 6, name: 'Capped Incurred 500', style: {}, r: 3 },
    { id: 7, name: 'Excess 500 750 Incurred', style: {}, r: 3 },
    { id: 8, name: 'Indemnity Recoveries Bucket', style: {}, r: 3 }
  ];
  choicesR4: ActrTrOptions[] = [
    { id: 0, name: 'Incurred', style: {}, r: 4 },
    { id: 1, name: 'Indemnity Incurred', style: {}, r: 4 },
    { id: 2, name: 'Medical Incurred', style: {}, r: 4 },
    { id: 3, name: 'Open Incurred', style: {}, r: 4 },
    { id: 4, name: 'Closed Incurred', style: {}, r: 4 },
    { id: 5, name: 'Closed Claims', style: {}, r: 4 },
    { id: 6, name: 'Capped Incurred 250', style: {}, r: 4 },
    { id: 7, name: 'Excess 250 500 Incurred', style: {}, r: 4 },
    { id: 8, name: 'Medical Payments Bucket', style: {}, r: 4 }
  ];
  choicesR5: ActrTrOptions[] = [
    { id: 0, name: 'Capped Net Paid', style: {}, r: 5 },
    { id: 1, name: 'Indemnity Capped Net Paid', style: {}, r: 5 },
    { id: 2, name: 'Medical Capped Net Paid', style: {}, r: 5 },
    { id: 3, name: 'Open Capped Net Paid', style: {}, r: 5 },
    { id: 4, name: 'Closed Capped Net Paid', style: {}, r: 5 },
    { id: 5, name: 'Indemnity Claims', style: {}, r: 5 },
    { id: 6, name: 'Capped Paid 1M', style: {}, r: 5 },
    { id: 7, name: 'Excess 250 Incurred', style: {}, r: 5 },
    { id: 8, name: 'Medical Reserves Bucket', style: {}, r: 5 }
  ];
  choicesR6: ActrTrOptions[] = [
    { id: 0, name: 'Capped Reserves', style: {}, r: 6 },
    { id: 1, name: 'Indemnity Capped Reserves', style: {}, r: 6 },
    { id: 2, name: 'Medical Capped Reserves', style: {}, r: 6 },
    { id: 3, name: 'Open Capped Reserves', style: {}, r: 6 },
    { id: 4, name: 'Closed Capped Reserves', style: {}, r: 6 },
    { id: 5, name: 'Medical Claims', style: {}, r: 6 },
    { id: 6, name: 'Excess 1M 2M Paid', style: {}, r: 6 },
    { id: 7, name: 'Excess 250 Incurred', style: {}, r: 6 },
    { id: 8, name: 'Medical Recoveries Bucket', style: {}, r: 6 }
  ];
  choicesR7: ActrTrOptions[] = [
    { id: 0, name: 'Capped Incurred', style: {}, r: 7 },
    { id: 1, name: 'Indemnity Capped Incurred', style: {}, r: 7 },
    { id: 2, name: 'Medical Capped Incurred', style: {}, r: 7 },
    { id: 3, name: 'Open Capped Incurred', style: {}, r: 7 },
    { id: 4, name: 'Closed Capped Incurred', style: {}, r: 7 },
    { id: 5, name: 'Incidents Claims', style: {}, r: 7 },
    { id: 6, name: 'Capped Paid 500', style: {}, r: 7 },
    { id: 7, name: 'Excess 750 1M Paid', style: {}, r: 7 },
    { id: 8, name: 'Rehab Payments Bucket', style: {}, r: 7 }
  ];
  choicesR8: ActrTrOptions[] = [
    { id: 0, name: 'Average Capped Incurred', style: {}, r: 8 },
    { id: 1, name: 'Indemnity Average Capped Incurred', style: {}, r: 8 },
    { id: 2, name: 'Medical Average Capped Incurred', style: {}, r: 8 },
    { id: 3, name: 'Open Average Capped Incurred', style: {}, r: 8 },
    { id: 4, name: 'Closed Average Capped Incurred', style: {}, r: 8 },
    { id: 5, name: 'Ratio For Closure', style: {}, r: 8 },
    { id: 6, name: 'Capped Paid 250', style: {}, r: 8 },
    { id: 7, name: 'Excess 500 750 Paid', style: {}, r: 8 },
    { id: 8, name: 'Rehab Reserves Bucket', style: {}, r: 8 }
  ];
  choicesR9: ActrTrOptions[] = [
    { id: 0, name: 'Average Capped Net Paid', style: {}, r: 9 },
    { id: 1, name: 'Indemnity Average Capped Net Paid', style: {}, r: 9 },
    { id: 2, name: 'Medical Average Capped Net Paid', style: {}, r: 9 },
    { id: 3, name: 'Open Average Capped Net Paid', style: {}, r: 9 },
    { id: 4, name: 'Closed Average Capped Net Paid', style: {}, r: 9 },
    { id: 5, name: '', style: {}, r: 9 },
    { id: 6, name: 'Capped Reserves 1M', style: {}, r: 9 },
    { id: 7, name: 'Excess 250 500 Paid', style: {}, r: 9 },
    { id: 8, name: 'Rehab Recoveries Bucket', style: {}, r: 9 }
  ];
  choicesR10: ActrTrOptions[] = [
    { id: 0, name: 'Average Capped Reserves', style: {}, r: 10 },
    { id: 1, name: 'Indemnity Average Capped Reserves', style: {}, r: 10 },
    { id: 2, name: 'Medical Average Capped Reserves', style: {}, r: 10 },
    { id: 3, name: 'Open Average Capped Reserves', style: {}, r: 10 },
    { id: 4, name: 'Closed Average Capped Reserves', style: {}, r: 10 },
    { id: 5, name: '', style: {}, r: 10 },
    { id: 6, name: 'Capped Reserves 750', style: {}, r: 10 },
    { id: 7, name: 'Excess 250 Paid', style: {}, r: 10 },
    { id: 8, name: 'Expense Payments Bucket', style: {}, r: 10 }
  ];
  choicesR11: ActrTrOptions[] = [
    { id: 0, name: '', style: {}, r: 11 },
    { id: 1, name: '', style: {}, r: 11 },
    { id: 2, name: '', style: {}, r: 11 },
    { id: 3, name: '', style: {}, r: 11 },
    { id: 4, name: '', style: {}, r: 11 },
    { id: 5, name: '', style: {}, r: 11 },
    { id: 6, name: 'Capped Reserves 500', style: {}, r: 11 },
    { id: 7, name: '', style: {}, r: 11 },
    { id: 8, name: 'Expense Reserves Bucket', style: {}, r: 11 }
  ];
  choicesR12: ActrTrOptions[] = [
    { id: 0, name: '', style: {}, r: 12 },
    { id: 1, name: '', style: {}, r: 12 },
    { id: 2, name: '', style: {}, r: 12 },
    { id: 3, name: '', style: {}, r: 12 },
    { id: 4, name: '', style: {}, r: 12 },
    { id: 5, name: '', style: {}, r: 12 },
    { id: 6, name: 'Capped Reserves 250', style: {}, r: 12 },
    { id: 7, name: '', style: {}, r: 12 },
    { id: 8, name: 'Expense Recoveries Bucket', style: {}, r: 12 }
  ];
  user: UserInfo;
  sendtofooter: FooterInfo;
  form: FormGroup;
  formChoices: FormGroup;
  Products: Array<Selection>;
  Levels: Array<Selection>;
  Options: Array<Selection>;
  pycys: Array<Selection>;
  StartingMonth: number;
  EndingMonth: number;
  Increment: number;

  PlaceholderProducts: string;
  PlaceholderLevels: string;
  PlaceholderOptions: string;
  Placeholderpycys: string;

  PlaceholderClaimsAmounts: string;
  PlaceholderStartingMonth: number;
  PlaceholderEndingMonth: number;
  PlaceholderIncrement: number;

  server: string;
  image0: string;
  image1: string;
  reportsInfo: boolean;
  ReportsArray: Array<RunProcess>;
  variablesHome: string;
  d = new Date();
  dp = new Date(2000, 0, 1);
  dp_str: string;
  constructor(
    private afs: ActuarialServices,
    private formBuilder: FormBuilder,
    private ss: SharedServices,
    private gv: GlobalVariables, private route: ActivatedRoute, private lv: LocalVariables) {
    // https://coryrylan.com/blog/creating-a-dynamic-checkbox-list-in-angular
    const controls = this.choicesR1.map(c => new FormControl(false));
    // controls[0].setValue(true); // Set the first checkbox to true (checked)
    this.formChoices = this.formBuilder.group({
      choicesR1: new FormArray(controls)
    });
  }

  ngOnInit() {
    this.d.setMonth(this.d.getMonth() - 1);
    this.dp_str = ('0' + (this.dp.getUTCMonth() + 1).toString()).substr(-2, 2) + '/'
      + ('0' + (this.dp.getUTCDate()).toString()).substr(-2, 2) + '/' + this.dp.getUTCFullYear().toString();
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.variablesHome = 'actuarialtriangles';
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.form.addControl('Product', new FormControl());
    this.form.addControl('Level', new FormControl());
    this.form.addControl('Option', new FormControl());
    this.form.addControl('pycy', new FormControl());
    this.form.addControl('yesno', new FormControl());
    this.form.addControl('StartingMonth', new FormControl());
    this.form.addControl('EndingMonth', new FormControl());
    this.form.addControl('Increment', new FormControl());
    this.Products = this.ss.getProductsAll();
    this.Levels = this.ss.getActuarialTrianglesLevels();
    this.Options = this.ss.getActuarialTrianglesOptions();
    this.pycys = this.ss.getPyCy();
    this.StartingMonth = 12;
    this.Increment = 12;
    this.EndingMonth = this.d.getMonth() - this.dp.getMonth()
      + (12 * (this.d.getFullYear() - this.dp.getFullYear()));
    this.PlaceholderProducts = this.Products[4].label;
    this.PlaceholderLevels = this.Levels[0].label;
    this.PlaceholderOptions = this.Options[0].label;
    this.Placeholderpycys = this.pycys[0].label;

    this.PlaceholderStartingMonth = this.StartingMonth;
    this.PlaceholderEndingMonth = this.EndingMonth;
    this.PlaceholderIncrement = this.Increment;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  onSubmit(formValues: any) {
    const Initials = this.user.name.split(' ');
    // GIVEMEACTUARIAL_VIEWS('ACTUARIAL','LP','ALL','INDIVIDUALS','NONE','POLICY YEAR',12,216,12,'PAID,NETPAID','LYUDMILPETROVLPETROV')
    const rr: RunProcessObject = {
      asofyr: this.d.getUTCFullYear(),
      asofmm: this.d.getUTCMonth() + 1,
      report: this.variablesHome,
      qryname: this.ss.getQueryName('A', 'T', +this.ReportsArray.length + 1),
      transport:
        this.ss.getQueryNameShort(this.user.name) + '|' +
        'ACTUARIAL|' + Initials[0].substring(0, 1) + Initials[1].substring(0, 1) + '|' +
        this.ss.getFormValue(formValues.Product, this.PlaceholderProducts, this.Products, 'value', 'label') + '|' +
        this.ss.getFormValue(formValues.Level, this.PlaceholderLevels, this.Levels, 'value', 'label') + '|' +
        this.ss.getFormValue(formValues.Option, this.PlaceholderOptions, this.Options, 'value', 'label') + '|' +
        this.ss.getFormValue(formValues.pycy, this.Placeholderpycys, this.pycys, 'value', 'label') + '|' +
        this.ss.getFormValueInputImproved(this.form.controls.StartingMonth.value, this.PlaceholderStartingMonth) + '|' +
        this.ss.getFormValueInputImproved(this.form.controls.EndingMonth.value, this.PlaceholderEndingMonth) + '|' +
        this.ss.getFormValueInputImproved(this.form.controls.Increment.value, this.PlaceholderIncrement) + '|' +
        'REPLACEOPTIONSHERE' + '|' +
        this.user.name,
      c: this.ss.getPass(),
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      imageprocess: this.image1
    };
    rr.name = this.user.name;
    const x = this.convertToString();
    if (x.length > 0) {
      rr.transport = rr.transport.replace('REPLACEOPTIONSHERE', x);
      rr.fingerprint = rr.asofyr.toString() + rr.asofmm.toString() + rr.transport;
      rr.filenameshort = 'Actuarial_Triangles_Package_'
        + this.ss.getNumberToString(rr.asofmm, 2) + '_' + rr.asofyr.toString() + '_' + rr.name.replace(' ', '_');
      rr.filename = rr.env + rr.filenameshort;
      // // console.log(rr);
      const p: RunProcess = {
        name: rr.filenameshort,
        run: true,
        object: rr
      };
      this.lv.add(this.variablesHome, p, rr.fingerprint);
      this.ReportsArray = this.lv.get(this.variablesHome);
      if (this.ReportsArray.length !== 0) {
        this.reportsInfo = false;
      } else {
        this.reportsInfo = true;
      }
      // console.log(rr);
    }
  }
  runReport(r: RunProcessObject) {
    this.ReportsArray.forEach((e: RunProcess, i: number) => {
      if (e.object.fingerprint === r.fingerprint) {
        e.object.imageprocess = e.object.imageprocess.replace('.png', '.gif');
        this.getReport(e.object);
      }
    });
  }
  deleteReport(r: RunProcessObject) {
    this.lv.remove(this.variablesHome, r.fingerprint);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  getReport(v: RunProcessObject) {
    this.afs.getRiskGenericReporting(this.server, v)
      .subscribe(
        res => {
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
              ///////////////////////// Cleaning server and web folder
              for (let i = 0; i < res.length; i++) {
                if (res[i] !== null) {
                  const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                  // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
                  // const filenamefullpath = env + filename;
                  let vv: CleanFileAndServer;
                  if (i === 0) {
                    vv = {
                      fullfilename: res[i],
                      qryname: v.qryname,
                      c: v.c
                    };
                  } else {
                    vv = {
                      fullfilename: res[i],
                      qryname: 'none',
                      c: v.c
                    };
                  }
                  // // console.log(vv);
                  this.ss.cleanFileServer(this.server, vv).subscribe(
                    () => { }, err1 => { });
                }
              }
              ///////////////////////// --------------- Cleaning all - web and oracle - END
            }, err => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
            });
        },
        err => { });
  }
  AddIt(o: ActrTrOptions) {
    if (o.name !== '') {
      if (this.isObjectEmpty(o.style)) {
        o.style = { 'background-color': 'green' };
      } else {
        o.style = {};
      }
    }
  }
  isObjectEmpty(obj: object) {
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        return false;
      }
    }
    return true;
  }
  convertToString(): string {
    const t = this;
    let r;
    r = '';
    this.choicesR1.forEach((o: ActrTrOptions) => {
      if (o.name !== '') {
        if (!t.isObjectEmpty(o.style)) {
          r = r + o.name.replace(/\s/g, '').toLocaleUpperCase() + ',';
        }
      }
    });
    this.choicesR2.forEach((o: ActrTrOptions) => {
      if (o.name !== '') {
        if (!t.isObjectEmpty(o.style)) {
          r = r + o.name.replace(/\s/g, '').toLocaleUpperCase() + ',';
        }
      }
    });
    this.choicesR3.forEach((o: ActrTrOptions) => {
      if (o.name !== '') {
        if (!t.isObjectEmpty(o.style)) {
          r = r + o.name.replace(/\s/g, '').toLocaleUpperCase() + ',';
        }
      }
    });
    this.choicesR4.forEach((o: ActrTrOptions) => {
      if (o.name !== '') {
        if (!t.isObjectEmpty(o.style)) {
          r = r + o.name.replace(/\s/g, '').toLocaleUpperCase() + ',';
        }
      }
    });
    this.choicesR5.forEach((o: ActrTrOptions) => {
      if (o.name !== '') {
        if (!t.isObjectEmpty(o.style)) {
          r = r + o.name.replace(/\s/g, '').toLocaleUpperCase() + ',';
        }
      }
    });
    this.choicesR6.forEach((o: ActrTrOptions) => {
      if (o.name !== '') {
        if (!t.isObjectEmpty(o.style)) {
          r = r + o.name.replace(/\s/g, '').toLocaleUpperCase() + ',';
        }
      }
    });
    this.choicesR7.forEach((o: ActrTrOptions) => {
      if (o.name !== '') {
        if (!t.isObjectEmpty(o.style)) {
          r = r + o.name.replace(/\s/g, '').toLocaleUpperCase() + ',';
        }
      }
    });
    this.choicesR8.forEach((o: ActrTrOptions) => {
      if (o.name !== '') {
        if (!t.isObjectEmpty(o.style)) {
          r = r + o.name.replace(/\s/g, '').toLocaleUpperCase() + ',';
        }
      }
    });
    this.choicesR9.forEach((o: ActrTrOptions) => {
      if (o.name !== '') {
        if (!t.isObjectEmpty(o.style)) {
          r = r + o.name.replace(/\s/g, '').toLocaleUpperCase() + ',';
        }
      }
    });
    this.choicesR10.forEach((o: ActrTrOptions) => {
      if (o.name !== '') {
        if (!t.isObjectEmpty(o.style)) {
          r = r + o.name.replace(/\s/g, '').toLocaleUpperCase() + ',';
        }
      }
    });
    this.choicesR11.forEach((o: ActrTrOptions) => {
      if (o.name !== '') {
        if (!t.isObjectEmpty(o.style)) {
          r = r + o.name.replace(/\s/g, '').toLocaleUpperCase() + ',';
        }
      }
    });
    this.choicesR12.forEach((o: ActrTrOptions) => {
      if (o.name !== '') {
        if (!t.isObjectEmpty(o.style)) {
          r = r + o.name.replace(/\s/g, '').toLocaleUpperCase() + ',';
        }
      }
    });
    return r.substring(0, r.length - 1);
  }
  updateDate(v: number) {
    const dt = new Date();
    dt.setMonth(dt.getMonth() - v);
    this.dp_str = ('0' + (dt.getUTCMonth() + 1).toString()).substr(-2, 2) + '/'
      + ('0' + (dt.getUTCDate()).toString()).substr(-2, 2) + '/' + dt.getUTCFullYear().toString();
  }
}
interface ActrTrOptions {
  id: number;
  name: string;
  style: object;
  r: number;
}
