import { ActuarialComponent } from './actuarial.component';
import { WCModelComponent } from './wcmodel/wc-model.component';
import { ActuarialTrianglesComponent } from './actuarialtriangles/actuarial-triangles.component';
import { WSEComponent } from './wse/wse.component';
import { AdminFeeComponent } from './admin-fee/admin-fee.component';
import { VisualizedComponent } from './visualized/visualized.component';
import { FinanceReportingComponent } from './finance-reporting/finance-reporting.components';
import { SASComponent } from './sas/sas.component';
import { SASPremiumClaimsComponent } from './premium-claims/premium-claims.component';
import { SASMLRSComponent } from './mlrs/mlrs.component';
import { SASMRPSComponent } from './mrps/mrps.component';
import { SASWCRateLossAnalysisComponent } from './wc-rate-loss-analysis/wc-rate-loss-analysis.component';
export const ActuarialRoutes = [
    { path: '', component: ActuarialComponent },
    { path: 'wcmodel', component: WCModelComponent },
    { path: 'triangles', component: ActuarialTrianglesComponent },
    { path: 'wse', component: WSEComponent },
    { path: 'admin-fee', component: AdminFeeComponent },
    { path: 'visualized', component: VisualizedComponent },
    { path: 'finance-reporting', component: FinanceReportingComponent },
    { path: 'premium-claims', component: SASPremiumClaimsComponent },
    { path: 'mlrs', component: SASMLRSComponent },
    { path: 'mrps', component: SASMRPSComponent },
    { path: 'sas', component: SASComponent },
    { path: 'wc-rate-loss-analysis', component: SASWCRateLossAnalysisComponent }
];
