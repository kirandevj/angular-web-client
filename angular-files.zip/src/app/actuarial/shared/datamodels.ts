
export interface SASGenericReport {
    reportname?: string;
    exchanges?: string[];
    category?: string;
    carriers?: string[];
    asofyr?: number;
    asofmm?: number;
    startdate?: string;
    enddate?: string;
    clientdatesmaturity?: string;
    id?: string;
    qryname?: string;
    username?: string;
    machinename?: string;
    env?: string;
    c?: string;
    channel?: string;
    eventname?: string;
    signalr?: string;
}
