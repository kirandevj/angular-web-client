import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActuarialWCModelReport } from '@app/datamodels/index';
import { ActuarialFiananceReporting } from '../shared/local.variables';
import { map, filter, scan, catchError, mergeMap } from 'rxjs/operators';
import { RunProcessObject } from '../shared/local.variables';
import { SASGenericReport } from './datamodels';
@Injectable()
export class ActuarialServices {
    constructor(private http: HttpClient, private ss: SharedServices) { }
    getActuarialWCModelData(api: string, v: ActuarialWCModelReport): Observable<string[]> {
        const apiPoint = api + 'api/Actuarial?WCModel=wcm';
        return this.http.post(apiPoint, v).pipe(map((r: string[]) => {
            // // console.log('observable returning');
            // // console.log(r);
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
    getRiskGenericReporting(api: string, v: RunProcessObject): Observable<string[]> {
        return this.http.post(api + 'api/MainAPI?riskgenericreporting=r', v).pipe(map((r: string[]) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
    getActuarialFiananceReporting(api: string, v: ActuarialFiananceReporting): Observable<string[]> {
        const apiPoint = api + 'api/Actuarial?ActuarialFiananceReporting=wcm';
        return this.http.post(apiPoint, v).pipe(map((r: string[]) => {
            // // console.log('observable returning');
            // // console.log(r);
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
    getSASActuarialGenericReporting(api: string, v: SASGenericReport): Observable<string[]> {
        // console.log('Called');
        const apiPoint = api + 'api/SAS?sasgenericreport=sgr';
        return this.http.post(apiPoint, v).pipe(map((r: string[]) => {
            // console.log('observable returning');
            // console.log(r);
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
    connectToSAS(api: string, connectionid: string,
        username: string, machinename: string, channel: string, eventname: string, encrk: string, env: string) {
        // api/DataLoad?processclients={processclients}&signalr={signalr}
        const apiPoint = api + 'api/SAS?username=' + encodeURIComponent(username.trim()) +
            '&machinename=' + machinename + '&channel=' + channel + '&eventname=' + eventname
            + '&signalr=' + connectionid + '&encrk=' + encrk + '&env=' + env;
        // console.log(apiPoint);
        return this.http.post(apiPoint, '').pipe(map((r: string[]) => {
            // console.log('observable returning');
            // console.log(r);
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
}
