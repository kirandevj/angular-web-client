import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { GENServices } from '../shared/gen.services';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { PAW, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { LocalVariables, RunProcess } from '../shared/local.variables';
import { SpinnerComponent } from '@app/common/index';
@Component({
  templateUrl: './paw.html',
  styles: [`
  form {
    /* color: #0000ff;
    font-size: 14px;
    line-height: 1.42857143;
    background-color: #9999ff;
    background-image: none;
    */
    display: block;
    padding: 12px 12px;
    border: 4px solid #8080ff;
    border-radius: 10px;
  }
  .nav.navbar-nav {font-size: 15px;}
  li > a { color: aliceblue; }
  `]
})
export class PAWComponent implements OnInit {
  user: UserInfo;
  server: string;
  sendtofooter: FooterInfo;
  form: FormGroup;
  Products: Array<Selection>;
  AsOfYrs: Array<Selection>;
  AsOfMms: Array<Selection>;
  Carveouts: Array<Selection>;
  PlaceholderProducts: string;
  PlaceholderAsOfYrs: string;
  PlaceholderAsOfMms: string;
  PlaceholderCarveouts: string;
  PlaceholderStates: string;
  PlaceholderCOIDs: string;
  image0: string;
  showspinner: boolean;
  constructor(private rfs: GENServices, private ss: SharedServices,
    private gv: GlobalVariables, private route: ActivatedRoute, private lv: LocalVariables) { }
  ngOnInit() {
    this.showspinner = false;
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.server = this.gv.get('api', 'api');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.form = new FormGroup({});
    this.form.addControl('Product', new FormControl());
    this.form.addControl('AsOfYr', new FormControl());
    this.form.addControl('AsOfMm', new FormControl());
    this.form.addControl('Carveout', new FormControl());
    this.form.addControl('State', new FormControl());
    this.form.addControl('COID', new FormControl());
    this.Products = this.ss.getProductsMedicalAll();
    this.AsOfYrs = this.ss.getYears();
    this.AsOfMms = this.ss.getMonths();
    this.Carveouts = this.ss.getCarveOutOptions();
    this.PlaceholderProducts = this.Products[5].label;
    this.PlaceholderAsOfYrs = this.ss.getYearsHolderSds();
    this.PlaceholderAsOfMms = this.ss.getMonthsHolderSds();
    this.PlaceholderStates = 'OH';
    this.PlaceholderCOIDs = '';
  }
  onSubmit(formValues: any) {
    const r: PAW = {
      product: this.ss.getFormValue(formValues.Product, this.PlaceholderProducts, this.Products, 'value', 'label'),
      asofyr: this.ss.getFormValue(formValues.AsOfYr, this.PlaceholderAsOfYrs, this.AsOfYrs, 'value', 'label'),
      asofmm: this.ss.getFormValue(formValues.AsOfMm, this.PlaceholderAsOfMms,
        this.AsOfMms, 'value', 'label'),
      states: this.PlaceholderStates,
      coids: this.PlaceholderCOIDs,
      qryname: this.ss.getQueryName('P', 'W', 0),
      username: this.user.name,
      c: this.ss.getPass(),
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      fileloaded: ''
    };
    // // console.log(r);
    this.showspinner = true;
    this.getFile(r);
  }
  getFile(v: PAW) {
    this.rfs.getRiskPAW(this.server, v)
      .subscribe(
        res => {
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              this.showspinner = false;
              // // console.log(res1);
              // // console.log(res);
              // /////////////////////////// Cleaning server and web folder
              // for (let i = 0; i < res.length; i++) {
              //   if (res[i] !== null) {
              //     const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
              //     // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
              //     const filenamefullpath = env + filename;
              //     let vv: CleanFileAndServer;
              //     if (i === 0) {
              //       vv = {
              //         fullfilename: res[i],
              //         qryname: v.qryname,
              //         c: v.c
              //       };
              //     } else {
              //       vv = {
              //         fullfilename: res[i],
              //         qryname: 'none',
              //         c: v.c
              //       };
              //     }
              //     this.ss.cleanFileServer(this.server, vv).subscribe(
              //       () => { }, err1 => { });
              //   }
              // }
              // /////////////////////////// Cleaning all - web and oracle - END
            }, err => {
              // // console.log(err);
            });
        },
        err => { });
  }

  updateInfo(v: string, e: string) {
    this[e] = v.toLocaleUpperCase().trim();
  }
}
