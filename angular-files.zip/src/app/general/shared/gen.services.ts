import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SharedServices, GlobalVariables } from '@app/common/index';
// Import RxJs required methods
import { map, filter, scan, catchError, mergeMap } from 'rxjs/operators';
import { ESAC, PAW } from '@app/datamodels/index';
@Injectable()
export class GENServices {
    constructor(private http: HttpClient, private ss: SharedServices) { }
    getRiskESAC(api: string, v: ESAC): Observable<string[]> {
        return this.http.post(api + 'api/MainAPI?riskesac=riskesac', v).pipe(map((r: string[]) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
    getRiskPAW(api: string, v: PAW): Observable<string[]> {
        return this.http.post(api + 'api/MainAPI?riskpaw=riskpaw', v).pipe(map((r: string[]) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
}

