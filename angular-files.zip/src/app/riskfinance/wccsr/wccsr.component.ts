import { Component, ViewEncapsulation, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { RiskFinanceServices } from '../shared/risk-finance.service';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { Wccsr, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { LocalVariables, RunProcess } from '../shared/local.variables';

@Component({
  templateUrl: './wccsr.html',
  styles: [`
  form {
    /* color: #0000ff;
    font-size: 14px;
    line-height: 1.42857143;
    background-color: #9999ff;
    background-image: none;
    */
    display: block;
    padding: 12px 12px;
    border: 4px solid #8080ff;
    border-radius: 10px;
  }
  .nav.navbar-nav {font-size: 15px;}
  li > a { color: aliceblue; }
  `]
})
export class WCCSRComponent implements OnInit {
  @ViewChild('input') input: ElementRef;
  user: UserInfo;
  sendtofooter: FooterInfo;
  form: FormGroup;
  Years: Array<Selection>;
  Months: Array<Selection>;
  yesnos: Array<Selection>;
  yesnoslr: Array<Selection>;
  yesnoscy: Array<Selection>;
  ascdesc: Array<Selection>;
  ClaimsAmounts: Array<Selection>;
  ExceedingAmount: number;
  PlaceholderYears: string;
  PlaceholderMonths: string;
  Placeholderyesnos: string;
  Placeholderyesnoslr: string;
  Placeholderyesnoscy: string;
  Placeholderascdesc: string;
  PlaceholderClaimsAmounts: string;
  PlaceholderExceedingAmount: number;
  servercalled: boolean;
  image0: string;
  image1: string;
  server: string;
  loadingImage: boolean;
  reportsInfo: boolean;
  ReportsArray: Array<RunProcess>;
  variablesHome: string;
  constructor(
    private rfs: RiskFinanceServices,
    private ss: SharedServices,
    private gv: GlobalVariables,
    private route: ActivatedRoute,
    private lv: LocalVariables) { }

  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.variablesHome = 'wccsr';
    this.loadingImage = true;
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.form.addControl('asofyr', new FormControl());
    this.form.addControl('asofmm', new FormControl());
    this.form.addControl('legalopt', new FormControl());
    this.form.addControl('includelossratio', new FormControl());
    this.form.addControl('includecalendaryear', new FormControl());
    this.form.addControl('yearsorder', new FormControl());
    this.form.addControl('groupopt', new FormControl());
    this.form.addControl('maxamount', new FormControl());
    this.Years = this.ss.getYears();
    this.Months = this.ss.getMonths();
    this.yesnos = this.ss.getYesNo();
    this.yesnoslr = this.ss.getYesNo();
    this.yesnoscy = this.ss.getYesNo();
    this.ascdesc = this.ss.getAscendingDescending();
    this.ClaimsAmounts = this.ss.getClaimsAmountsStructure();
    this.ExceedingAmount = 100000;
    this.PlaceholderYears = this.ss.getYearsHolderSds();
    this.PlaceholderMonths = this.ss.getMonthsHolderSds();
    this.Placeholderyesnos = this.yesnos[1].label;
    this.Placeholderyesnoslr = this.yesnoslr[1].label;
    this.Placeholderyesnoscy = this.yesnoscy[0].label;
    this.Placeholderascdesc = this.ascdesc[0].label;
    this.PlaceholderClaimsAmounts = this.ClaimsAmounts[0].label;
    this.PlaceholderExceedingAmount = this.ExceedingAmount;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
    // console.log(this.ReportsArray);
  }
  onSubmit(formValues: Wccsr) {
    this.loadingImage = false;
    const rr: Wccsr = {
      qryname: this.ss.getQueryName('', '', this.ReportsArray.length),
      asofyr: +this.ss.getFormValue(formValues.asofyr, this.PlaceholderYears, this.Years, 'value', 'label'),
      asofmm: +this.ss.getFormValue(formValues.asofmm, this.PlaceholderMonths, this.Months, 'value', 'label'),
      groupopt: this.ss.getFormValue(formValues.groupopt, this.PlaceholderClaimsAmounts, this.ClaimsAmounts, 'value', 'label'),
      maxamount: +this.ss.getFormValueInput(+formValues.maxamount, this.PlaceholderExceedingAmount, 0),
      yearsorder: this.ss.getFormValue(formValues.yearsorder, this.Placeholderascdesc, this.ascdesc, 'value', 'label'),
      legalopt: this.ss.getFormValue(formValues.legalopt, this.Placeholderyesnos, this.yesnos, 'value', 'label'),
      includelossratio: this.ss.getFormValue(formValues.includelossratio, this.Placeholderyesnoslr, this.yesnoslr, 'value', 'label'),
      includecalendaryear: this.ss.getFormValue(formValues.includecalendaryear, this.Placeholderyesnoscy, this.yesnoscy, 'value', 'label'),
      username: this.user.name,
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      c: this.ss.getPass(),
      fingerprint: '',
      filename: '',
      filenameshort: '',
      imageprocess: this.image1
    };
    rr.fingerprint = rr.asofyr + rr.asofmm + rr.groupopt + rr.maxamount + rr.yearsorder + rr.legalopt;
    rr.filenameshort = 'WCCSR_' + this.ss.getNumberToString(rr.asofmm, 2) + '_' + rr.asofyr.toString() + '.xlsx';
    rr.filename = rr.env + rr.filenameshort;
    const p: RunProcess = {
      name: rr.filenameshort,
      run: true,
      object: rr
    };
    this.lv.add(this.variablesHome, p, rr.fingerprint);
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
    if (this.user.machine === 'Jessica Villasenor') {
      rr.qryname = this.user.machine + this.ReportsArray.length;
    }
    // console.log(rr);
  }
  runReport(r: Wccsr) {
    this.ReportsArray.forEach((e: RunProcess, i: number) => {
      if (e.object.fingerprint === r.fingerprint) {
        e.object.imageprocess = e.object.imageprocess.replace('.png', '.gif');
        this.getWCCSR(e.object);
      }
    });
  }
  deleteReport(r: Wccsr) {
    this.lv.remove(this.variablesHome, r.fingerprint);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  getWCCSR(v: Wccsr) {
    // // console.log(v);
    this.rfs.getWCCSR(this.server, v)
      .subscribe(
        res => {
          // // console.log(res);
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
              // --------------- Cleaning all - web and oracle - START
              for (let i = 0; i < res.length; i++) {
                if (res[i] !== null) {
                  // /////////////////////////// Cleaning server and web folder
                  const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                  // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
                  // const filenamefullpath = env + filename;
                  let vv: CleanFileAndServer;
                  if (i === 0) {
                    vv = {
                      fullfilename: res[i],
                      qryname: v.qryname,
                      c: v.c
                    };
                  } else {
                    vv = {
                      fullfilename: res[i],
                      qryname: 'none',
                      c: v.c
                    };
                  }
                  this.ss.cleanFileServer(this.server, vv).subscribe(
                    () => { }, err1 => { });
                }
              }
              // --------------- Cleaning all - web and oracle - END
            }, err => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
            });
        },
        err => { });
  }
}
