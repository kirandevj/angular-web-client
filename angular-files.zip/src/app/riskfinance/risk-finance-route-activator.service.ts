import { Router, ActivatedRouteSnapshot, CanActivate } from '@angular/router';
import { Injectable } from '@angular/core';
import { RiskFinanceServices } from './shared/risk-finance.service';

@Injectable()
export class RiskFinanceRouteActivator implements CanActivate {
  loading = true;
  constructor(private rfs: RiskFinanceServices, private router: Router) {
  }
  canActivate(router: ActivatedRouteSnapshot) {
    const routExists = !!this.rfs.getRout(router.url[0].toString());
    // // console.log(router.url);
    // tslint:disable-next-line:curly
    if (!routExists) this.router.navigate(['/404']);
    return routExists;
  }
}
