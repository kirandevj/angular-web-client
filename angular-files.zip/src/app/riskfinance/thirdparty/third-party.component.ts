import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { RiskFinanceServices } from '../shared/risk-finance.service';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { ThirdPartyDeliverables, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { LocalVariables, RunProcess } from '../shared/local.variables';

@Component({
  templateUrl: './third-party.html',
  styles: [`form {
    /* color: #0000ff;
    font-size: 14px;
    line-height: 1.42857143;
    background-color: #9999ff;
    background-image: none;
    */
    display: block;
    padding: 12px 12px;
    border: 4px solid #8080ff;
    border-radius: 10px;
  }
  .nav.navbar-nav {font-size: 15px;}
  li > a { color: aliceblue; }
  `]
})
export class ThridPartyComponent implements OnInit {
  user: UserInfo;
  sendtofooter: FooterInfo;
  form: FormGroup;
  Deliverables: Array<Selection>;
  Years: Array<Selection>;
  Months: Array<Selection>;
  selectedSelection: Selection;
  AdditionalVariable0Visible: boolean;
  PlaceholderDeliverables: string;
  PlaceholderYears: string;
  PlaceholderMonths: string;
  PlaceholderAdditionalVariable: number;
  server: string;
  image0: string;
  image1: string;
  reportsInfo: boolean;
  ReportsArray: Array<RunProcess>;
  variablesHome: string;
  constructor(private rfs: RiskFinanceServices, private ss: SharedServices,
    private gv: GlobalVariables, private route: ActivatedRoute, private lv: LocalVariables) {
    this.selectedSelection = this.ss.getDeliverablesAll()[0];
  }

  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.variablesHome = 'thirdpartydeliverables';
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.form.addControl('Deliverable', new FormControl());
    this.form.addControl('Year', new FormControl());
    this.form.addControl('Month', new FormControl());
    this.form.addControl('AdditionalVariable0', new FormControl());
    this.form.addControl('AdditionalVariable1', new FormControl());
    this.Deliverables = this.ss.getDeliverablesAll();
    this.Years = this.ss.getYears();
    this.Months = this.ss.getMonths();
    this.PlaceholderYears = this.ss.getYearsHolderFds();
    this.PlaceholderMonths = this.ss.getMonthsHolderSds();
    this.PlaceholderDeliverables = this.Deliverables[0].label;
    this.selected(this.Deliverables[0]);
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  onSubmit(formValues: any) {
    const rr: ThirdPartyDeliverables = {
      qryname: this.ss.getQueryNameShort(this.user.name) + this.ReportsArray.length,
      deliverable: this.ss.getFormValue(formValues.Deliverable, this.PlaceholderDeliverables, this.Deliverables, 'value', 'label'),
      asofyr: +this.ss.getFormValue(formValues.Year, this.PlaceholderYears, this.Years, 'value', 'label'),
      asofmm: +this.ss.getFormValue(formValues.Month, this.PlaceholderMonths, this.Months, 'value', 'label'),
      // monthsback: formValues.AdditionalVariable0.value,
      // statesplit: this.selectedSelection.additional1lable,
      username: this.user.name,
      c: this.ss.getPass(),
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      fingerprint: '',
      process: '',
      imageprocess: this.image1
    };

    rr.process = rr.deliverable + ' as of '
      + this.ss.getNumberToString(rr.asofmm, 2) + ' ' + rr.asofyr.toString() + ' actuarial process run by '
      + rr.username + '.package';
    const p: RunProcess = {
      name: rr.process,
      run: true,
      object: rr
    };
    if (formValues.AdditionalVariable0 === null) {
      if (typeof this.selectedSelection.additional0lable === 'undefined') {
        rr.statesplit = 'NY';
      } else {
        rr.statesplit = this.selectedSelection.additional0lable;
      }
    } else {
      rr.statesplit = formValues.AdditionalVariable0;
    }
    if (formValues.AdditionalVariable1 === null) {
      if (typeof this.selectedSelection.additional1lable === 'undefined') {
        rr.monthsback = '1';
      } else {
        rr.monthsback = this.selectedSelection.additional1lable;
      }
    } else {
      rr.monthsback = formValues.AdditionalVariable1;
    }
    // // console.log(formValues);
    // console.log(rr);
    rr.fingerprint = rr.deliverable.toString() + rr.asofyr.toString() + rr.asofmm.toString()
      + rr.monthsback.toString() + rr.statesplit.toString();
    this.lv.add(this.variablesHome, p, rr.fingerprint);
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  selected(value: any): void {
    // this.selectedSelection = this.Deliverables.filter(d => (Boolean(d.additional0info)) && d.label === value.label)[0];
    this.selectedSelection = this.Deliverables.filter(d => d.label === value.label)[0];
    this.AdditionalVariable0Visible = !(typeof this.selectedSelection === 'undefined');
    // const emptyselection: Selection = {
    //   value: value.value,
    //   label: value.lable,
    //   additional0info: '', additional0lable: ''
    // };
    // if (!this.AdditionalVariable0Visible) {
    //   this.selectedSelection = emptyselection;
    // }
  }
  runReport(r: ThirdPartyDeliverables) {
    this.ReportsArray.forEach((e: RunProcess, i: number) => {
      if (e.object.fingerprint === r.fingerprint) {
        e.object.imageprocess = e.object.imageprocess.replace('.png', '.gif');
        this.getThirdPartyDeliverables(e.object);
      }
    });
  }
  deleteReport(r: ThirdPartyDeliverables) {
    this.lv.remove(this.variablesHome, r.fingerprint);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  getThirdPartyDeliverables(v: ThirdPartyDeliverables) {
    this.rfs.getThirdPartyDeliverables(this.server, v)
      .subscribe(
        res => {
          // console.log(res);
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
              for (let i = 0; i < res.length; i++) {
                if (res[i] !== null) {
                  /////////////////////////// Cleaning server and web folder
                  const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                  // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
                  // const filenamefullpath = env + filename;
                  let vv: CleanFileAndServer;
                  if (i === 0) {
                    vv = {
                      fullfilename: res[i],
                      qryname: v.qryname,
                      c: v.c
                    };
                  } else {
                    vv = {
                      fullfilename: res[i],
                      qryname: 'none',
                      c: v.c
                    };
                  }
                  this.ss.cleanFileServer(this.server, vv).subscribe(
                    () => { }, err1 => { });
                }
              }
              // --------------- Cleaning all - web and oracle - END
            }, err => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
            });
        },
        err => { });
  }
}
