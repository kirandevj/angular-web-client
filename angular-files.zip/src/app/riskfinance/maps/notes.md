https://bost.ocks.org/mike/map/
https://bl.ocks.org/mbostock/5562380
https://www.census.gov/geo/maps-data/data/cbf/cbf_zcta.html
https://bl.ocks.org/mbostock
http://www1.nyc.gov/site/planning/data-maps/usa/open-data/districts-download-metadata.page
http://learnjsdata.com/index.html
`[my file](\C:\\my_file.pdf)`

command executed before shp file moved it needs to be with all other files
`ogr2ogr -f GeoJson "D:\angular 2\maps\uszipsraw.json" "C:\Users\ljudm\Downloads\usazipdata\cb_2016_us_zcta510_500k.shp"`

Filtering shape file for NYC
### NYC
`ogr2ogr -f GeoJson "C:\Users\lpetrov\Documents\Visual Studio 2015\Projects\trinet\app\riskfinance\maps\usa\nyczipsraw.json" "C:\Users\lpetrov\Downloads\cb_2016_us_zcta510_500k\cb_2016_us_zcta510_500k.shp" -where "ZCTA5CE10 in ('10453','10457','10460','10458','10467','10468','10451','10452','10456','10454','10455','10459','10474','10463','10471','10466','10469','10470','10475','10461','10462','10464','10465','10472','10473','11212','11213','11216','11233','11238','11209','11214','11228','11204','11218','11219','11230','11234','11236','11239','11223','11224','11229','11235','11201','11205','11215','11217','11231','11203','11210','11225','11226','11207','11208','11211','11222','11220','11232','11206','11221','11237','10026','10027','10030','10037','10039','10001','10011','10018','10019','10020','10036','10029','10035','10010','10016','10017','10022','10012','10013','10014','10004','10005','10006','10007','10038','10280','10002','10003','10009','10021','10028','10044','10065','10075','10128','10023','10024','10025','10031','10032','10033','10034','10040','11361','11362','11363','11364','11354','11355','11356','11357','11358','11359','11360','11365','11366','11367','11412','11423','11432','11433','11434','11435','11436','11101','11102','11103','11104','11105','11106','11374','11375','11379','11385','11691','11692','11693','11694','11695','11697','11004','11005','11411','11413','11422','11426','11427','11428','11429','11414','11415','11416','11417','11418','11419','11420','11421','11368','11369','11370','11372','11373','11377','11378','10302','10303','10310','10306','10307','10308','10309','10312','10301','10304','10305','10314')`
Converting to topojson
`geo2topo -o app/riskfinance/maps/usa/us-nyc.json app/riskfinance/maps/usa/nyczipsraw.json`
### Manhattan
`ogr2ogr -f GeoJson "C:\Users\lpetrov\Documents\Visual Studio 2015\Projects\trinet\app\riskfinance\maps\usa\nycmanhattanzipsraw.json" "C:\Users\lpetrov\Downloads\cb_2016_us_zcta510_500k\cb_2016_us_zcta510_500k.shp" -where "ZCTA5CE10 in ('10026','10027','10030','10037','10039','10001','10011','10018','10019','10020','10036','10029','10035','10010','10016','10017','10022','10012','10013','10014','10004','10005','10006','10007','10038','10280','10002','10003','10009','10021','10028','10044','10065','10075','10128','10023','10024','10025','10031','10032','10033','10034','10040')"`
Converting to topojson
`geo2topo -o app/riskfinance/maps/usa/us-nyc-manhattan.json app/riskfinance/maps/usa/nycmanhattanzipsraw.json`
### Brooklyn
`ogr2ogr -f GeoJson "C:\Users\lpetrov\Documents\Visual Studio 2015\Projects\trinet\app\riskfinance\maps\usa\nycbrooklynzipsraw.json" "C:\Users\lpetrov\Downloads\cb_2016_us_zcta510_500k\cb_2016_us_zcta510_500k.shp" -where "ZCTA5CE10 in ('11212','11213','11216','11233','11238','11209','11214','11228','11204','11218','11219','11230','11234','11236','11239','11223','11224','11229','11235','11201','11205','11215','11217','11231','11203','11210','11225','11226','11207','11208','11211','11222','11220','11232','11206','11221','11237','10025','10031','10032','10033','10034','10040')"`
Converting to topojson
`geo2topo -o app/riskfinance/maps/usa/us-nyc-brooklyn.json app/riskfinance/maps/usa/nycbrooklynzipsraw.json`
### Staten Island
`ogr2ogr -f GeoJson "C:\Users\lpetrov\Documents\Visual Studio 2015\Projects\trinet\app\riskfinance\maps\usa\nycstatenislandzipsraw.json" "C:\Users\lpetrov\Downloads\cb_2016_us_zcta510_500k\cb_2016_us_zcta510_500k.shp" -where "ZCTA5CE10 in ('10302','10303','10310','10306','10307','10308','10309','10312','10301','10304','10305','10314')"`
Converting to topojson
`geo2topo -o app/riskfinance/maps/usa/us-nyc-statenisland.json app/riskfinance/maps/usa/nycstatenislandzipsraw.json`
### Queens
`ogr2ogr -f GeoJson "C:\Users\lpetrov\Documents\Visual Studio 2015\Projects\trinet\app\riskfinance\maps\usa\nycqueenszipsraw.json" "C:\Users\lpetrov\Downloads\cb_2016_us_zcta510_500k\cb_2016_us_zcta510_500k.shp" -where "ZCTA5CE10 in ('11361','11362','11363','11364','11354','11355','11356','11357','11358','11359','11360','11365','11366','11367','11412','11423','11432','11433','11434','11435','11436','11101','11102','11103','11104','11105','11106','11374','11375','11379','11385','11691','11692','11693','11694','11695','11697','11004','11005','11411','11413','11422','11426','11427','11428','11429','11414','11415','11416','11417','11418','11419','11420','11421','11368','11369','11370','11372','11373','11377','11378')"`
Converting to topojson
`geo2topo -o app/riskfinance/maps/usa/us-nyc-queens.json app/riskfinance/maps/usa/nycqueenszipsraw.json`
### Bronx
`ogr2ogr -f GeoJson "C:\Users\lpetrov\Documents\Visual Studio 2015\Projects\trinet\app\riskfinance\maps\usa\nycbronxzipsraw.json" "C:\Users\lpetrov\Downloads\cb_2016_us_zcta510_500k\cb_2016_us_zcta510_500k.shp" -where "ZCTA5CE10 in ('10453','10457','10460','10458','10467','10468','10451','10452','10456','10454','10455','10459','10474','10463','10471','10466','10469','10470','10475','10461','10462','10464','10465','10472','10473')"`
Converting to topojson
`geo2topo -o app/riskfinance/maps/usa/us-nyc-bronx.json app/riskfinance/maps/usa/nycbronxzipsraw.json`

Mergin CSV with topojson
geo2topo -e NYCBoroughsZipCodes.csv --id-property='GEOID10,id' -p -o nycziptf.json -- cb_2016_us_zcta510_500k.shp

