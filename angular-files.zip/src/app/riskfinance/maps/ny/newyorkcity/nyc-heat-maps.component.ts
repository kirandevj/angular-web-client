import {
  Component, OnInit, OnChanges, ViewChild, ElementRef,
  Input, ViewEncapsulation, ChangeDetectionStrategy
} from '@angular/core';
import { Map } from '@app/datamodels/index';
import { SharedServices } from '@app/common/index';
import { GetNYCHeatMapsService } from './nyc-heat-maps.service';

@Component({
  templateUrl: './nyc-heat-maps.html',
  styleUrls: ['./nyc-heat-maps.css'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NYCHeatMapsComponent implements OnInit, OnChanges {
  @ViewChild('mapNYC') public mapContainer: ElementRef;
  // map: map;
  // public mapmultiplicator: number;
  // public mapcolor: string;
  // public mapmultiplicatorclient: number;
  // public mapcolorclient: string;
  // public margin: any = { top: 20, bottom: 20, left: 20, right: 20 };
  // public webapiendpoint: string;
  // public mapjson: string;
  // public csvstatesinfo: string;
  // public csvstatesinfoclient: string;
  // public mapcolorindex: number;

  constructor(private gds: GetNYCHeatMapsService, private ss: SharedServices) {
  }
  ngOnInit() {
    // // console.log('in');
    this.gds.createMap();
  }
   ngOnChanges(changes: any) {
  }
  // getUSAMap() {
  //   this.ss.getJsonData('us-states.json', 'get', 'text', this.server)
  //     .subscribe(
  //     m => {
  //       this.ss.setCache('localStorage', 'usamap', JSON.parse(m['_body']), 'object');
  //     },
  //     err => {
  //       // // console.log(err);
  //     });
  // }

}

