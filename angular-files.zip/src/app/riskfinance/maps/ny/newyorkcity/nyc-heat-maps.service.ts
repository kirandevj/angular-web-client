// path : d3/d3.service.ts
import { Injectable, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs';
// import { Subject } from 'rxjs/Subject';
import { HttpClient, HttpResponse, HttpHeaders, HttpRequest, HttpClientModule } from '@angular/common/http';
// import 'rxjs/add/operator/map';
// import 'rxjs/add/operator/catch';
// import 'rxjs/add/operator/toPromise';
// import 'rxjs/add/operator/debounce';
import * as d3 from 'd3';
// const topojson = require('topojson');
// const colorbrewer = require('colorbrewer');
import { topojson } from 'topojson';
import { colorbrewer } from 'colorbrewer';
import { Map } from '@app/datamodels/index';
import { SharedServices, GlobalVariables } from '@app/common/index';
@Injectable()
export class GetNYCHeatMapsService {
  constructor(private http: HttpClient, private ss: SharedServices, private gv: GlobalVariables) { }

  createMap() {
    this.ss.getJsonData(this.gv.get('api', 'api'), 'nyc.json', 'get', 'text')
      .subscribe(
      m => {
        // tslint:disable-next-line:no-string-literal
        const map: any = JSON.parse(m['_body'])['features'];
        // building the map
        const width = 1000;
        const height = 900;
        d3.selectAll('#svgNYCMap0').remove();
        const path: any = d3.geoPath().projection(d3.geoAlbersUsa());
        const svg: any = d3.select('#nycheatmap0').append('svg')
          .attr('id', 'svgNYCMap0')
          .attr('width', width)
          .attr('height', height);
        // // console.log('added');
        // svg.selectAll('path')
        //   .data(map)
        //   .enter()
        //   .append('path')
        //   .attr('d', path);
        // .on('click', function (d: any) {
        //   // // console.log(d);
        //   d3.event.stopPropagation();
        // })
        // .style('stroke', '#fff')
        // .style('stroke-width', '1')
        // .style('fill', function (d: any) {
        //   // tslint:disable-next-line:max-line-length
        //   let color = d3.scaleLinear().domain([-+d.properties.statemin * multiplicator, +d.properties.statemax * multiplicator]).range(
        //     colorbrewer[tempmap.color][tempmap.colorindex]);
        //   return color(+d.properties.stateinfo * multiplicator).toString();
        // });
      },
      err => {
        // // console.log(err);
      });
  }


  //                 svg.selectAll('text')
  //                   .data(dataMap3)
  //                   .enter()
  //                   .append('svg:text')
  //                   .text(function (d: any) {
  //                     return d.properties.stateabrv;
  //                   })
  //                   .attr('x', function (d: any) {
  //                     return path.centroid(d)[0];
  //                   })
  //                   .attr('y', function (d: any) {
  //                     return path.centroid(d)[1];
  //                   })
  //                   .attr('text-anchor', 'middle')
  //                   .attr('font-size', '6pt');
  //                 // .on('click', function (d: any) {
  //                 //   // // console.log(d);
  //                 // });
  //                 // building the map end
  //                 // building inside data
  //                 svg.append('g')
  //                   .attr('class', 'bubble')
  //                   .selectAll('circle')
  //                   .data(dataMapClient)
  //                   .enter().append('circle')
  //                   .attr('transform', function (d: any) {
  //                     return 'translate(' + d3.geoAlbersUsa()([d.clientlong, d.clientlat]) + ')';
  //                   })
  //                   .attr('r', function (d: any) {
  //                     return Math.sqrt(30);
  //                   })
  //                   .style('fill', function (d: any) {
  //                     // tslint:disable-next-line:max-line-length
  // tslint:disable-next-line:max-line-length
  //                     let color = d3.scaleLinear().domain([-+d.clientvaluemin * tempmap.multiplicatorClient, +d.clientvaluemax * tempmap.multiplicatorClient]).range(
  //                       colorbrewer[tempmap.colorClient][tempmap.colorindex]);
  //                     return color(+d.clientvalue * tempmap.multiplicatorClient).toString();
  //                   })
  //                   .style('opacity', 0.85);
  //                 // building inside data end

  //                 // Append credit at bottom
  //                 svg.append('text')
  //                   .attr('class', 'credit')
  //                   .attr('x', width / 2)
  //                   .attr('y', height - 50)
  //                   .style('text-anchor', 'middle')
  //                   .text('For internal distribution only');
  //                 // Extra scale since the color scale is interpolated
  //                 let colorScale2 = d3.scaleLinear()
  //                   .domain([0, 5, 10])
  //                   .range(colorbrewer[tempmap.color][tempmap.colorindex]);
  //                 let colorScale = d3.scaleLinear()
  //                   .domain([0, 5, 10])
  //                   .range(colorbrewer[tempmap.color][tempmap.colorindex]);
  //                 // .range(<any>['#FFFFDD', '#3E9583', '#1F2D86']);
  //                 let countScale = d3.scaleLinear()
  //                   .domain([0, 10])
  //                   .range([0, width]);
  //                 // Calculate the variables for the temp gradient
  //                 let numStops = 10;
  //                 let countRange = countScale.domain();
  //                 countRange[2] = countRange[1] - countRange[0];
  //                 let countPoint = <any>[];
  //                 for (let ii = 0; ii < numStops; ii++) {
  //                   countPoint.push(ii * countRange[2] / (numStops - 1) + countRange[0]);
  //                 }
  //                 // Create the gradient
  //                 svg.append('defs')
  //                   .append('linearGradient')
  //                   .attr('id', 'legend-map')
  //                   .attr('x1', '0%').attr('y1', '0%')
  //                   .attr('x2', '100%').attr('y2', '0%')
  //                   .selectAll('stop')
  //                   .data(d3.range(numStops))
  //                   .enter().append('stop')
  //                   .attr('offset', function (d: any, iii: any) {
  //                     return countScale(countPoint[iii]) / width;
  //                   })
  //                   .attr('stop-color', function (d: any, iii: any) {
  //                     return colorScale(countPoint[iii]);
  //                   });
  //                 ///////////////////////////////////////////////////////////////////////////
  //                 ////////////////////////// Draw the legend ////////////////////////////////
  //                 ///////////////////////////////////////////////////////////////////////////
  //                 let legendWidth = Math.min(width * 0.8, 400);
  //                 // Color Legend container
  //                 let legendsvg = svg.append('g')
  //                   .attr('class', 'legendWrapper')
  //                   .attr('transform', 'translate(' + (width / 2) + ',' + (height - 30) + ')');
  //                 // Draw the Rectangle
  //                 legendsvg.append('rect')
  //                   .attr('class', 'legendRect')
  //                   .attr('x', -legendWidth / 2)
  //                   .attr('y', 0)
  //                   // .attr("rx", hexRadius*1.25/2)
  //                   .attr('width', legendWidth)
  //                   .attr('height', 10)
  //                   .style('fill', 'url(#legend-map)');
  //                 // Set scale for x-axis
  //                 let xScale = d3.scaleLinear()
  //                   .range([-legendWidth / 2, legendWidth / 2])
  //                   .domain([dataMap3[0].properties.statemin, dataMap3[0].properties.statemax]);
  //                 // Define x-axis
  //                 let xAxis = d3.axisBottom(xScale)
  //                   .ticks(5)
  //                   // .tickFormat(formatPercent)
  //                   .scale(xScale);
  //                 // Set up X axis
  //                 legendsvg.append('g')
  //                   .attr('class', 'axis')
  //                   .attr('transform', 'translate(0,' + (10) + ')')
  //                   .call(xAxis);




  //                 // Slider
  //                 // https://bl.ocks.org/mbostock/6499018


  //               },
  //               (err: any) => {
  //                 return err;
  //               });
  //           },
  //           (err: any) => {
  //             return err;
  //           });
  //       },
  //       (err: any) => {
  //         return err;
  //       });
  //   }
  //   public handleError(error: Response) {
  //     return Observable.throw(error.statusText);
  //   };
}
