import {
  Component, OnInit, OnChanges, ViewChild, ElementRef,
  Input, ViewEncapsulation, ChangeDetectionStrategy, ChangeDetectorRef, ViewChildren, QueryList, AfterViewInit
} from '@angular/core';
import { Map } from '@app/datamodels/index';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { GetUsaMapService } from './usa-get-data.service';
// https://www.techiediaries.com/angular-dom-queries-viewchild/
@Component({
  // moduleId: module.id,
  selector: './app-usa-map',
  templateUrl: './usa-map.html',
  styleUrls: ['./usa-map.css'],
  // encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UsaMapComponent implements OnInit, OnChanges, AfterViewInit {
  numberOfTicks = 0;
  @Input() mapoption: string;
  // @ViewChild('map') mapContainer: ElementRef;
  // @ViewChild('map') private mapContainer: any;
  @ViewChild('map', { static: true }) mapContainer: ElementRef;
  // @ViewChildren('map') mapContainer: QueryList<'map'>;
  map: Map;
  mapNYC: Map;
  mapmultiplicator: number;
  mapcolor: string;
  mapmultiplicatorclient: number;
  mapcolorclient: string;
  margin: any = { top: 20, bottom: 20, left: 20, right: 20 };
  webapiendpoint: string;
  mapjson: string;
  csvstatesinfo: string;
  csvstatesinfoclient: string;
  mapcolorindex: number;

  constructor(private ref: ChangeDetectorRef, private gds: GetUsaMapService, private ss: SharedServices, private gv: GlobalVariables) {
  }
  ngOnInit() {
    // // console.log(['From ngOnInit', this.mapContainer]);
    this.webapiendpoint = this.gv.get('map', 'map');
    this.mapjson = this.webapiendpoint + 'us-states.json';
    this.csvstatesinfo = this.webapiendpoint + 'states-info.csv';
    this.csvstatesinfoclient = this.webapiendpoint + 'clients-info.csv';
    this.mapmultiplicator = 10000;
    this.mapmultiplicatorclient = 13;
    this.mapcolor = 'Reds';
    this.mapcolorclient = 'PuBuGn';
    this.mapcolorindex = 3;
    this.map = {
      element: this.mapContainer.nativeElement,
      // element: this.mapHTML,
      width: 1000,
      height: 600,
      margin: this.margin,
      option: this.mapoption,
      urlMap: this.mapjson,
      urlCSV0: this.csvstatesinfo,
      urlCSV1: this.csvstatesinfoclient,
      multiplicator: this.mapmultiplicator,
      color: this.mapcolor,
      colorClient: this.mapcolorclient,
      multiplicatorClient: this.mapmultiplicatorclient,
      colorindex: this.mapcolorindex,
      svgId: 'maphere',
      mapkey: 'features',
      mapNameCache: 'usamap'
    };
    if (this.ss.getCache('localStorage', 'tempMap', 'object') === false) {
      const m: Map = this.map;
      m.colorClient = 'PuRd';
      m.urlMap = this.map.urlMap.replace('us-states', 'us-nyc');
      m.urlCSV0 = this.map.urlCSV0.replace('states-info', 'nyc-clients-info');
      m.urlCSV1 = this.map.urlCSV1.replace('clients-info', 'nyc-zips');
      m.color = 'Reds';
      m.colorindex = 3;
      m.mapkey = 'nyczipsraw';
      m.nycCenterX = 0;
      m.nycCenterY = 40.7;
      m.nycRotateX = 74;
      m.nycRotateY = 0;
      m.nycTranslateW = 2.1;
      m.nycTranslateH = 2.1;
      m.nycScale = 70000;
      m.nycBorough = 'All';
      m.mapNameCache = 'usanycmap';
      this.gds.createNYCMap(m, this.gds, false);
    }
    this.initilizeMap();
  }
  ngOnChanges(changes: any) {
    // // console.log(['From ngOnChanges', this.mapContainer]);
    // // console.log(changes.mapoption.currentValue);
    this.webapiendpoint = this.gv.get('map', 'map');
    this.mapjson = this.webapiendpoint + 'us-states.json';
    this.csvstatesinfo = this.webapiendpoint + 'states-info.csv';
    this.csvstatesinfoclient = this.webapiendpoint + 'clients-info.csv';
    this.mapmultiplicator = 10000;
    this.mapmultiplicatorclient = 13;
    this.mapcolor = 'Reds';
    this.mapcolorclient = 'PuBuGn';
    this.mapcolorindex = 3;
    this.map = {
      element: this.mapContainer.nativeElement,
      width: 1000,
      height: 600,
      margin: this.margin,
      option: changes.mapoption.currentValue,
      urlMap: this.mapjson,
      urlCSV0: this.csvstatesinfo,
      urlCSV1: this.csvstatesinfoclient,
      multiplicator: this.mapmultiplicator,
      color: this.mapcolor,
      colorClient: this.mapcolorclient,
      multiplicatorClient: this.mapmultiplicatorclient,
      colorindex: this.mapcolorindex,
      svgId: 'maphere',
      mapkey: 'features',
      mapNameCache: 'usamap'
    };
    if (this.map.option.indexOf('NYC') === -1) {
      this.gds.createMap(this.map);
    } else {
      const m: Map = this.map;
      m.colorClient = 'PuRd';
      m.urlMap = this.map.urlMap.replace('us-states', 'us-nyc');
      m.urlCSV0 = this.map.urlCSV0.replace('states-info', 'nyc-clients-info');
      m.urlCSV1 = this.map.urlCSV1.replace('clients-info', 'nyc-zips');
      m.color = 'Reds';
      m.colorindex = 3;
      m.mapkey = 'nyczipsraw';
      m.nycCenterX = 0;
      m.nycCenterY = 40.7;
      m.nycRotateX = 74;
      m.nycRotateY = 0;
      m.nycTranslateW = 2.1;
      m.nycTranslateH = 2.1;
      m.nycScale = 70000;
      m.nycBorough = 'All';
      m.mapNameCache = 'usanycmap';
      this.gds.createNYCMap(m, this.gds, true);
    }
  }
  initilizeMap() {
    this.gds.createMap(this.map);
  }
  public ngAfterViewInit(): void {
  }
}
 // https://blog.thoughtram.io/angular/2016/02/22/angular-2-change-detection-explained.html
