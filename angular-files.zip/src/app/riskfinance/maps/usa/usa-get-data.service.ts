// import { EDESTADDRREQ } from 'constants';
import { GetNYCHeatMapsService } from '../ny/newyorkcity/nyc-heat-maps.service';
import { Injectable, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpResponse, HttpHeaders, HttpRequest } from '@angular/common/http';
import { map, filter, scan, catchError, mergeMap, tap } from 'rxjs/operators';

// import { d3 } from 'd3';
// declare let d3: any;
import * as d3 from 'd3';
// const topojson = require('topojson');
// const colorbrewer = require('colorbrewer');
// import { topojson } from 'topojson';
// import { colorbrewer } from 'colorbrewer';
import * as topojson from 'topojson';
import * as colorbrewer from 'colorbrewer';
import { Map } from '@app/datamodels/index';
import { SharedServices } from '@app/common/index';
// http://reactivex.io/rxjs/class/es6/MiscJSDoc.js~ObserverDoc.html
// https://amdevblog.wordpress.com/2016/07/20/update-d3-js-scripts-from-v3-to-v4/
// https://xgrommx.github.io/rx-book/content/getting_started_with_rxjs/creating_and_querying_observable_sequences/bridging_to_promises.html
// https://angular-2-training-book.rangle.io/handout/observables/using_observables.html
// https://gist.github.com/staltz/868e7e9bc2a7b8c1f754
// http://blog.angular-university.io/functional-reactive-programming-for-angular-2-developers-rxjs-and-observables
// https://egghead.io/technologies/rx
// tslint:disable-next-line:max-line-length
// https://xgrommx.github.io/rx-book/content/getting_started_with_rxjs/creating_and_querying_observable_sequences/creating_and_subscribing_to_simple_observable_sequences.html
@Injectable()
export class GetUsaMapService {
  constructor(private http: HttpClient, private ss: SharedServices) { }
  getJsonFromFile(url: string): Observable<any> {
    // return this.http.get(url).map((response: Response) => {
    //   return <any>response.json();
    // }).catch(this.handleError);
    return this.http.get(url).pipe(map((response: Response) => {
      return response.json() as any;
    }
    ), catchError((e: any) => {
      // // console.log(e);
      return e;
    }));

  }
  getMapFromCache(mapname: string) {
    return new Observable((observer: any) => {
      observer.next(JSON.parse(this.ss.getCache('localStorage', mapname, 'object')));
    });
  }
  getCSV(url: string): Observable<any> {
    return this.http.get(url, { responseType: 'text' }).pipe(map((response) => {
      return response.split('\n');
    }
    ), catchError((e: any) => {
      // // console.log(e);
      return e;
    }));
  }
  createMap(tempmap: Map) {
    const width: number = tempmap.width - (tempmap.margin.left + tempmap.margin.right);
    const height: number = tempmap.height - (tempmap.margin.top + tempmap.margin.bottom);
    d3.selectAll('#' + tempmap.svgId).remove();
    const path: any = d3.geoPath().projection(d3.geoAlbersUsa());
    const svg: any = d3.select(tempmap.element).append('svg')
      .attr('id', tempmap.svgId)
      .attr('width', width)
      .attr('height', height);
    let dataMap: Array<any>;
    const dataMapClient: Array<any> = [];
    const dataMap2: Array<any> = [];
    const dataMap3: Array<any> = [];
    let dataCSV0: Array<string> = [];
    this.getMapFromCache(tempmap.mapNameCache).subscribe(
      // this.getJsonFromFile(tempmap.urlMap).subscribe(
      (i: any) => {
        dataMap = i[tempmap.mapkey];
        this.getCSV(tempmap.urlCSV0).subscribe(
          (x: any) => {
            // // console.log(x);
            dataCSV0 = x;
            // // console.log(dataCSV0[0]);
            // mixing json with csv
            // Loop through each state data value in the .csv file
            let i0 = 0;
            const optionsArr: Array<number> = [];
            let iopt = 0;
            dataCSV0[0].split(',').forEach((il0: string) => {
              if (il0.toLocaleUpperCase().indexOf(tempmap.option.toLocaleUpperCase()) > -1) {
                optionsArr.push(iopt);
              }
              iopt++;
            });
            // if (Array.isArray(dataCSV0)) {
            dataCSV0.forEach((ia0: any) => {
              if (i0 !== 0 && ia0.length !== 0) {
                const info = ia0.split(',');
                const StateName = info[0];
                const StateAbrv = info[1];
                const StateInfo = info[optionsArr[0]];
                const StateMin = info[optionsArr[1]];
                const StateMax = info[optionsArr[2]];
                // Combining json with csv
                let i1 = 0;
                dataMap.forEach((ia1: any) => {
                  if (StateName.trim().toLocaleUpperCase() === ia1.properties.name.trim().toLocaleUpperCase()) {
                    // Copy the data value into the JSON
                    ia1.properties.stateinfo = StateInfo;
                    ia1.properties.stateabrv = StateAbrv;
                    ia1.properties.statemin = StateMin;
                    ia1.properties.statemax = StateMax;
                    dataMap2.push(ia1);
                  }
                });
                i1++;
              }
              i0++;
            });
            // }
            this.getCSV(tempmap.urlCSV1).subscribe(
              (y: any) => {
                const optionsArrL1: Array<number> = [];
                let ioptL1 = 0;
                y[0].split(',').forEach((il1: string) => {
                  if (il1.toLocaleUpperCase().indexOf(tempmap.option.toLocaleUpperCase()) > -1) {
                    optionsArrL1.push(ioptL1);
                  }
                  ioptL1++;
                });
                /////// Plot client here
                // let i1l1 = 0;
                // y.forEach((ia0: any) => {
                //   if (i1l1 !== 0 && ia0.length !== 0) {
                //     const info = ia0.split(',');
                //     const objClient: Object = {
                //       statename: info[0],
                //       stateabrv: info[1],
                //       clientname: info[2],
                //       clientid: info[3],
                //       clientlat: info[4],
                //       clientlong: info[5],
                //       clientvalue: info[optionsArrL1[0]],
                //       clientvaluemin: info[optionsArrL1[1]],
                //       clientvaluemax: info[optionsArrL1[2]]
                //     };
                //     dataMapClient.push(objClient);
                //   }
                //   i1l1++;
                // });
                // Combine latest data with clients !!!!!!!!!!! may be exclude
                dataMap2.forEach((ia0: any) => {
                  ia0.properties.clients = [];
                  dataMapClient.forEach((ia1: any) => {
                    if (ia1.statename.trim().toLocaleUpperCase() === ia0.properties.name.trim().toLocaleUpperCase()) {
                      ia0.properties.clients.push(ia1);
                    }
                  });
                  dataMap3.push(ia0);
                });
                // building the map
                // const width: number = tempmap.width - (tempmap.margin.left + tempmap.margin.right);
                // const height: number = tempmap.height - (tempmap.margin.top + tempmap.margin.bottom);
                // d3.selectAll('#' + tempmap.svgId).remove();
                // const path: any = d3.geoPath().projection(d3.geoAlbersUsa());
                // const svg: any = d3.select(tempmap.element).append('svg')
                //   .attr('id', tempmap.svgId)
                //   .attr('width', width)
                //   .attr('height', height);
                svg.selectAll('path')
                  .data(dataMap3)
                  .enter()
                  .append('path')
                  .attr('d', path)
                  // .on('click', (d: any) => {
                  //   d3.event.stopPropagation();
                  // })
                  .style('stroke', '#004d99')
                  .style('stroke-width', '0.5')
                  .style('fill', (d: any) => {
                    const color = d3.scaleLinear().domain([-+d.properties.statemin * tempmap.multiplicator,
                    +d.properties.statemax * tempmap.multiplicator]).range(
                      colorbrewer[tempmap.color][tempmap.colorindex]);
                    if (!isNaN(+d.properties.stateinfo)) {
                      return color(+d.properties.stateinfo * tempmap.multiplicator).toString();
                    }
                  });
                svg.selectAll('text')
                  .data(dataMap3)
                  .enter()
                  .append('svg:text')
                  .text((d: any) => {
                    return d.properties.stateabrv;
                  })
                  .attr('x', (d: any) => {
                    return path.centroid(d)[0];
                  })
                  .attr('y', (d: any) => {
                    return path.centroid(d)[1];
                  })
                  .attr('text-anchor', 'middle')
                  .attr('font-size', '6pt');
                // building the map end
                // building inside data
                svg.append('g')
                  .attr('class', 'bubble')
                  .selectAll('circle')
                  .data(dataMapClient)
                  .enter().append('circle')
                  .attr('transform', (d: any) => {
                    return 'translate(' + d3.geoAlbersUsa()([d.clientlong, d.clientlat]) + ')';
                  })
                  .attr('r', (d: any) => {
                    return Math.sqrt(30);
                  })
                  .style('fill', (d: any) => {
                    // tslint:disable-next-line:max-line-length
                    const color = d3.scaleLinear().domain([-+d.clientvaluemin * tempmap.multiplicatorClient, +d.clientvaluemax * tempmap.multiplicatorClient]).range(
                      colorbrewer[tempmap.colorClient][tempmap.colorindex]);
                    return color(+d.clientvalue * tempmap.multiplicatorClient).toString();
                  })
                  .style('opacity', 0.85);
                // building inside data end
                // Append credit at bottom
                svg.append('text')
                  .attr('class', 'credit')
                  .attr('x', width / 2)
                  .attr('y', height - 50)
                  .style('text-anchor', 'middle')
                  .text('For internal distribution only');
                // Extra scale since the color scale is interpolated
                // let colorScale2 = d3.scaleLinear()
                //   .domain([0, 5, 10])
                //   .range(colorbrewer[tempmap.color][tempmap.colorindex]);
                const colorScale = d3.scaleLinear()
                  .domain([0, 5, 10])
                  .range(colorbrewer[tempmap.color][tempmap.colorindex]);
                // .range(<any>['#FFFFDD', '#3E9583', '#1F2D86']);
                const countScale = d3.scaleLinear()
                  .domain([0, 10])
                  .range([0, width]);
                // Calculate the letiables for the temp gradient
                const numStops = 10;
                const countRange = countScale.domain();
                countRange[2] = countRange[1] - countRange[0];
                const countPoint = [] as any;
                for (let ii = 0; ii < numStops; ii++) {
                  countPoint.push(ii * countRange[2] / (numStops - 1) + countRange[0]);
                }
                // Create the gradient
                svg.append('defs')
                  .append('linearGradient')
                  .attr('id', 'legend-map')
                  .attr('x1', '0%').attr('y1', '0%')
                  .attr('x2', '100%').attr('y2', '0%')
                  .selectAll('stop')
                  .data(d3.range(numStops))
                  .enter().append('stop')
                  .attr('offset', (d: any, iii: any) => {
                    return countScale(countPoint[iii]) / width;
                  })
                  .attr('stop-color', (d: any, iii: any) => {
                    return colorScale(countPoint[iii]);
                  });
                // // console.log(svg);
                ///////////////////////////////////////////////////////////////////////////
                ////////////////////////// Draw the legend ////////////////////////////////
                ///////////////////////////////////////////////////////////////////////////
                const legendWidth = Math.min(width * 0.8, 400);
                // Color Legend container
                const legendsvg = svg.append('g')
                  .attr('class', 'legendWrapper')
                  .attr('transform', 'translate(' + (width / 2) + ',' + (height - 30) + ')');
                // Draw the Rectangle
                legendsvg.append('rect')
                  .attr('class', 'legendRect')
                  .attr('x', -legendWidth / 2)
                  .attr('y', 0)
                  // .attr('rx', 1 * 1.25 / 2)
                  .attr('width', legendWidth)
                  .attr('height', 10)
                  .style('fill', 'url(#legend-map)');
                // Set scale for x-axis
                const xScale = d3.scaleLinear()
                  .range([-legendWidth / 2, legendWidth / 2])
                  .domain([dataMap3[0].properties.statemin, dataMap3[0].properties.statemax]);
                // Define x-axis
                const xAxis = d3.axisBottom(xScale)
                  .ticks(5)
                  // .tickFormat(formatPercent)
                  .scale(xScale);
                // Set up X axis
                legendsvg.append('g')
                  .attr('class', 'axis')
                  .attr('transform', 'translate(0,' + (10) + ')')
                  .call(xAxis);
                // Slider
                // https://bl.ocks.org/mbostock/6499018
                // // console.log(svg);
              },
              (err: any) => {
                // // console.log(err);
                // return err;
              });
          },
          (err: any) => {
            // // console.log(err);
            // return err;
          });
      },
      (err: any) => {
        // // console.log(err);
        // return err;
      });
    // // console.log(svg);
    // // console.log(tempmap);
  }
  // tslint:disable-next-line:ban-types
  createNYCDataObject(m: Map, data: string[], zips: string[], jsonMap: Object, ss: SharedServices): any {
    function findZipBorough(z: string[], zipStr: string) {
      let r = '';
      const l = z.length;
      for (let i = 1; i < l; i++) {
        if (z[i].split(',')[0] === zipStr) {
          r = z[i].split(',')[1];
          break;
        }
      }
      return r;
    }
    const zipsArry = [] as any;
    const zipsMap = [] as any;
    // tslint:disable-next-line:ban-types
    const nycmap: Object = jsonMap;
    return new Observable((observer: any) => {
      observer.next(
        (() => {
          //  Process 0 getting all zips from json map passed to process
          // tslint:disable-next-line:ban-types
          let zipTempObj: Object = {
            zip: '',
            borough: ''
          };
          // tslint:disable-next-line:no-string-literal
          nycmap['objects']['nyczipsraw']['geometries'].forEach((mz: any) => {
            zipTempObj = {
              // tslint:disable-next-line:no-string-literal
              zip: mz['properties']['GEOID10'],
              // tslint:disable-next-line:no-string-literal
              borough: findZipBorough(zips, mz['properties']['GEOID10'])
            };
            zipsMap.push(zipTempObj);
          });
        })()
      );
      observer.next(
        (() => {
          //  Combining info only for matching zips from zipsMap to data info csv and zips csv
          zipsMap.forEach((z: any) => {
            const lzips = zipsMap.length;
            const zipObject = {
              zip: '',
              borough: '',
              employeesAll: 0,
              minemployeesAll: 0,
              maxemployeesAll: 0,
              wagesAll: 0,
              minwagesAll: 0,
              maxwagesAll: 0,
              infoAll: [] as any,
              employeesPassport: 0,
              minemployeesPassport: 0,
              maxemployeesPassport: 0,
              wagesPassport: 0,
              minwagesPassport: 0,
              maxwagesPassport: 0,
              infoPassport: [] as any,
              employeesSOI: 0,
              minemployeesSOI: 0,
              maxemployeesSOI: 0,
              wagesSOI: 0,
              minwagesSOI: 0,
              maxwagesSOI: 0,
              infoSOI: [] as any,
              employeesAmbrose: 0,
              minemployeesAmbrose: 0,
              maxemployeesAmbrose: 0,
              wagesAmbrose: 0,
              minwagesAmbrose: 0,
              maxwagesAmbrose: 0,
              infoAmbrose: [] as any,
              employeesAccord: 0,
              minemployeesAccord: 0,
              maxemployeesAccord: 0,
              wagesAccord: 0,
              minwagesAccord: 0,
              maxwagesAccord: 0,
              infoAccord: [] as any,
              // up to here statistic by zip code
              // below stat by total zips and boroughs
              employees_For_Map: 0,
              minemployees_For_Map: 0,
              maxemployees_For_Map: 0,
              wages_For_Map: 0,
              minwages_For_Map: 0,
              maxwages_For_Map: 0,
              jsonMapZIPsCount: lzips
            };
            data.forEach((d: any) => {
              const ci: string[] = d.split(',');
              if (z.zip === ci[1]) {
                // only here addition
                zipObject.zip = z.zip;
                zipObject.borough = z.borough;
                // Getting All
                zipObject.employeesAll = zipObject.employeesAll + +ci[10];
                if (zipObject.minemployeesAll > +ci[10]) {
                  zipObject.minemployeesAll = +ci[10];
                }
                if (zipObject.maxemployeesAll < +ci[10]) {
                  zipObject.maxemployeesAll = +ci[10];
                }
                zipObject.wagesAll = zipObject.wagesAll + +ci[11];
                if (zipObject.minwagesAll > +ci[11]) {
                  zipObject.minwagesAll = +ci[11];
                }
                if (zipObject.maxwagesAll < +ci[11]) {
                  zipObject.maxwagesAll = +ci[11];
                }
                zipObject.infoAll.push(ci);
                // Getting All done
                // Getting Rest
                if (ci[0] === 'Passport') {
                  zipObject.employeesPassport = zipObject.employeesPassport + +ci[10];
                  if (zipObject.minemployeesPassport > +ci[10]) {
                    zipObject.minemployeesPassport = +ci[10];
                  }
                  if (zipObject.maxemployeesPassport < +ci[10]) {
                    zipObject.maxemployeesPassport = +ci[10];
                  }
                  zipObject.wagesPassport = zipObject.wagesPassport + +ci[11];
                  if (zipObject.minwagesPassport > +ci[11]) {
                    zipObject.minwagesPassport = +ci[11];
                  }
                  if (zipObject.maxwagesPassport < +ci[11]) {
                    zipObject.maxwagesPassport = +ci[11];
                  }
                  zipObject.infoPassport.push(ci);
                } else {
                  if (ci[0] === 'SOI') {
                    zipObject.employeesSOI = zipObject.employeesSOI + +ci[10];
                    if (zipObject.minemployeesSOI > +ci[10]) {
                      zipObject.minemployeesSOI = +ci[10];
                    }
                    if (zipObject.maxemployeesSOI < +ci[10]) {
                      zipObject.maxemployeesSOI = +ci[10];
                    }
                    zipObject.wagesSOI = zipObject.wagesSOI + +ci[11];
                    if (zipObject.minwagesSOI > +ci[11]) {
                      zipObject.minwagesSOI = +ci[11];
                    }
                    if (zipObject.maxwagesSOI < +ci[11]) {
                      zipObject.maxwagesSOI = +ci[11];
                    }
                    zipObject.infoSOI.push(ci);
                  } else {
                    if (ci[0] === 'Accord') {
                      zipObject.employeesAccord = zipObject.employeesAccord + +ci[10];
                      if (zipObject.minemployeesAccord > +ci[10]) {
                        zipObject.minemployeesAccord = +ci[10];
                      }
                      if (zipObject.maxemployeesAccord < +ci[10]) {
                        zipObject.maxemployeesAccord = +ci[10];
                      }
                      zipObject.wagesAccord = zipObject.wagesAccord + +ci[11];
                      if (zipObject.minwagesAccord > +ci[11]) {
                        zipObject.minwagesAccord = +ci[11];
                      }
                      if (zipObject.maxwagesAccord < +ci[11]) {
                        zipObject.maxwagesAccord = +ci[11];
                      }
                      zipObject.infoAccord.push(ci);
                    } else {
                      if (ci[0] === 'Ambrose') {
                        zipObject.employeesAmbrose = zipObject.employeesAmbrose + +ci[10];
                        if (zipObject.minemployeesAmbrose > +ci[10]) {
                          zipObject.minemployeesAmbrose = +ci[10];
                        }
                        if (zipObject.maxemployeesAmbrose < +ci[10]) {
                          zipObject.maxemployeesAmbrose = +ci[10];
                        }
                        zipObject.wagesAmbrose = zipObject.wagesAmbrose + +ci[11];
                        if (zipObject.minwagesAmbrose > +ci[11]) {
                          zipObject.minwagesAmbrose = +ci[11];
                        }
                        if (zipObject.maxwagesAmbrose < +ci[11]) {
                          zipObject.maxwagesAmbrose = +ci[11];
                        }
                        zipObject.infoAmbrose.push(ci);
                      } else {
                        // nothing
                      }
                    }
                  }
                }
                // Getting Passport Done
              }
            });
            if (zipObject.zip !== '') {
              zipsArry.push(zipObject);
            } else {
              zipObject.zip = z.zip;
              zipObject.borough = z.borough;
              zipsArry.push(zipObject);
            }
          });
          // getting info
          // Structuring data based on input of map.option
          const mo = m.option.replace('NYC ', '').replace(' ', '').split('&');
          // let emp_sum = 0;
          let emp_zip = 0;
          let wag_zip = 0;
          zipsArry.forEach((e: any) => {
            emp_zip = 0;
            wag_zip = 0;
            mo.forEach((ee: any) => {
              const elemEmp = 'employees' + ee.trim();
              const elemWag = 'wages' + ee.trim();
              emp_zip = emp_zip + e[elemEmp];
              wag_zip = wag_zip + e[elemWag];
            });
            e.employees = emp_zip;
            e.wages = wag_zip;
          });
          // applying info

          let emp_min = zipsArry[0].employees;

          let wag_min = zipsArry[0].wages;

          let emp_max = 0;

          let wag_max = 0;
          zipsArry.forEach((e: any) => {
            e.employees_For_Map = e.employees;
            e.wages_For_Map = e.wages;
            if (emp_min > e.employees) {
              emp_min = e.employees;
            }
            if (emp_max < e.employees) {
              emp_max = e.employees;
            }
            if (wag_min > e.wages) {
              wag_min = e.wages;
            }
            if (wag_max < e.wages) {
              wag_max = e.wages;
            }
          });
          // applying info
          zipsArry.forEach((e: any) => {
            e.maxemployees_For_Map = emp_max;
            e.maxwages_For_Map = wag_max;
            e.minemployees_For_Map = emp_min;
            e.minwages_For_Map = wag_min;
            // if (e.zip === '10001') {
            //   // // // console.log(e);
            // };
          });
        })()
      );
      observer.next(
        // combining map with info
        (() => {
          nycmap['objects']['nyczipsraw']['geometries'].forEach((mz: any) => {
            zipsArry.forEach((zz: any) => {
              if (mz['properties']['GEOID10'] === zz.zip) {
                mz['properties'].info = zz;
              }
            });
          });
        })()
      );
      observer.next(
        // fixing missing zips
        (() => {
          nycmap['objects']['nyczipsraw']['geometries'].forEach((mz: any) => {
            if (typeof mz['properties']['info'] === 'undefined') {
              mz['properties']['info'] = 'none';
            }
          });
        })()
      );
      observer.next(
        // logging the map
        (() => {
          ss.setCache('localStorage', 'tempMap', nycmap, 'object');
        })()
      );
    });
  }
  createNYCMap(tempmap: Map, ms: any, drawing: boolean) {
    function formatNumber(n: number) {
      let r = n.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '1,');
      r = r.substring(0, r.length - 3);
      return r;
    }
    this.getCSV(tempmap.urlCSV0).subscribe(
      (i: any) => {
        this.getCSV(tempmap.urlCSV1).subscribe(
          (ii: any) => {
            // Fix move this to observable passing raw map
            this.getMapFromCache(tempmap.mapNameCache).subscribe(
              // this.getJsonFromFile(tempmap.urlMap).subscribe(
              (iii: any) => {
                //  let z = this.createNYCDataObject(tempmap, i, ii);
                this.createNYCDataObject(tempmap, i, ii, iii, this.ss).subscribe(
                  (iiii: any) => {
                    if (drawing) {
                      const nycmap = this.ss.getCache('localStorage', 'tempMap', 'object');
                      // building the map
                      const width: number = tempmap.width - (tempmap.margin.left + tempmap.margin.right);
                      const height: number = tempmap.height - (tempmap.margin.top + tempmap.margin.bottom);
                      d3.selectAll('#' + tempmap.svgId).remove();
                      const projection = d3.geoAlbers()
                        .center([tempmap.nycCenterX, tempmap.nycCenterY])
                        .rotate([tempmap.nycRotateX, tempmap.nycRotateY])
                        .translate([width / tempmap.nycTranslateW, height / tempmap.nycTranslateH])
                        .scale(tempmap.nycScale);
                      const path = d3.geoPath().projection(projection);
                      const svg: any = d3.select(tempmap.element).append('svg')
                        .attr('id', tempmap.svgId)
                        .attr('width', width)
                        .attr('height', height);
                      // hoover element
                      const barTooltip = d3.select(tempmap.element).append('div')
                        .attr('class', 'tooltip')
                        .style('opacity', 0)
                        .style('width', 600);
                      // draw base
                      svg.selectAll('path')
                        .data(topojson.feature(nycmap, nycmap.objects.nyczipsraw).features)
                        .enter()
                        .append('path')
                        .on('click', (e: any) => {
                          barTooltip.transition()
                            .style('opacity', 0);
                          const prBr = tempmap.nycBorough.toLocaleLowerCase();
                          const crBr = e.properties.info.borough.replace(' ', '').toLocaleLowerCase();
                          if (prBr !== crBr) {
                            tempmap.nycBorough = e.properties.info.borough;
                            tempmap.urlMap = tempmap.urlMap.replace('us-nyc.json', 'us-nyc-' + crBr + '.json');
                          } else {
                            tempmap.nycBorough = 'All';
                            tempmap.urlMap = tempmap.urlMap.replace('us-nyc-' + crBr + '.json', 'us-nyc.json');
                          }
                          if (tempmap.nycBorough.trim().toLocaleLowerCase() === 'all') {
                            tempmap.mapNameCache = 'usanycmap';
                            tempmap.nycCenterX = 0;
                            tempmap.nycCenterY = 40.7;
                            tempmap.nycScale = 70000;
                          } else {
                            if (tempmap.nycBorough.trim().toLocaleLowerCase() === 'manhattan') {
                              tempmap.mapNameCache = 'usanycmapmanhattan';
                              tempmap.nycCenterX = 0.02;
                              tempmap.nycCenterY = 40.7801;
                              tempmap.nycScale = 153000;
                            } else {
                              if (tempmap.nycBorough.trim().toLocaleLowerCase() === 'bronx') {
                                tempmap.mapNameCache = 'usanycmapbronx';
                                tempmap.nycCenterX = 0.135;
                                tempmap.nycCenterY = 40.8555;
                                tempmap.nycScale = 250000;
                              } else {
                                if (tempmap.nycBorough.trim().toLocaleLowerCase() === 'statenisland') {
                                  tempmap.mapNameCache = 'usanycmapstatenisland';
                                  tempmap.nycCenterX = -0.17;
                                  tempmap.nycCenterY = 40.571;
                                  tempmap.nycScale = 195000;
                                } else {
                                  if (tempmap.nycBorough.trim().toLocaleLowerCase() === 'brooklyn') {
                                    tempmap.mapNameCache = 'usanycmapbrooklyn';
                                    tempmap.nycCenterX = 0.052;
                                    tempmap.nycCenterY = 40.652;
                                    tempmap.nycScale = 175000;
                                  } else {
                                    if (tempmap.nycBorough.trim().toLocaleLowerCase() === 'queens') {
                                      tempmap.mapNameCache = 'usanycmapqueens';
                                      tempmap.nycCenterX = 0;
                                      tempmap.nycCenterY = 40.7;
                                      tempmap.nycScale = 70000;
                                    } else {
                                      tempmap.nycCenterX = 0;
                                      tempmap.nycCenterY = 40.7;
                                      tempmap.nycScale = 70000;
                                    }
                                  }
                                }
                              }
                            }
                          }
                          ms.createNYCMap(tempmap, ms, true);
                          d3.event.stopPropagation();
                        }).attr('class', 'nycland')
                        .attr('d', path)
                        .style('stroke', '#004d99')
                        .style('stroke-width', '0.03')
                        .style('fill', (d: any) => {
                          // tslint:disable-next-line:max-line-length
                          const color = d3.scaleLinear().domain([-+d.properties.info.minemployees_For_Map * tempmap.multiplicator, +d.properties.info.maxemployees_For_Map * tempmap.multiplicator]).range(
                            colorbrewer[tempmap.color][tempmap.colorindex]);
                          return color(+d.properties.info.employees * tempmap.multiplicator).toString();
                        })
                        // add dynamic tooltip
                        .on('mouseenter', (d: any) => {
                          barTooltip.transition()
                            .duration(500)
                            .style('opacity', .7);
                          let tip = '<strong>ZIP:</strong> ' + d.properties.GEOID10 + '<br/>';
                          tip = tip + '<strong>Employees:</strong> ' + formatNumber(d.properties.info.employees) + '<br/>';
                          tip = tip + '<strong>Wages:</strong> $ ' + formatNumber(d.properties.info.wages) + '<br/>';
                          barTooltip.html(tip)
                            .style('left', (d3.event.pageX) + 'px')
                            .style('top', (d3.event.pageY - 150) + 'px');
                          barTooltip.append('svg')
                            .attr('width', width + tempmap.margin.left + tempmap.margin.right)
                            .attr('height', height + tempmap.margin.top + tempmap.margin.bottom)
                            .append('g')
                            .attr('transform', 'translate(' + tempmap.margin.left + ',' + tempmap.margin.top + ')');
                        })
                        .on('mouseleave', (d: any) => {
                          barTooltip.transition()
                            .duration(500)
                            .style('opacity', 0);
                        });
                      svg.selectAll('text')
                        .data(topojson.feature(nycmap, nycmap.objects.nyczipsraw).features)
                        .enter()
                        .append('svg:text')
                        .text((d: any) => {
                          return d.properties.info.employees;
                        })
                        .attr('x', (d: any) => {
                          return path.centroid(d)[0];
                        })
                        .attr('y', (d: any) => {
                          return path.centroid(d)[1];
                        })
                        .attr('text-anchor', 'end')
                        .attr('startOffset', '100%')
                        .attr('font-size', '1.3pt');
                      // building the map end
                      // Extra scale since the color scale is interpolated
                      const colorScale = d3.scaleLinear()
                        .domain([0, 5, 10])
                        .range(colorbrewer[tempmap.color][tempmap.colorindex]);
                      const countScale = d3.scaleLinear()
                        .domain([0, 10])
                        .range([0, width]);
                      const numStops = 10;
                      const countRange = countScale.domain();
                      countRange[2] = countRange[1] - countRange[0];
                      const countPoint = [] as any;
                      for (let x = 0; x < numStops; x++) {
                        countPoint.push(x * countRange[2] / (numStops - 1) + countRange[0]);
                      }
                      // Create the gradient
                      svg.append('defs')
                        .append('linearGradient')
                        .attr('id', 'legend-map')
                        .attr('x1', '0%').attr('y1', '0%')
                        .attr('x2', '100%').attr('y2', '0%')
                        .selectAll('stop')
                        .data(d3.range(numStops))
                        .enter().append('stop')
                        .attr('offset', (d: any, xx: any) => {
                          return countScale(countPoint[xx]) / width;
                        })
                        .attr('stop-color', (d: any, xx: any) => {
                          return colorScale(countPoint[xx]);
                        });
                      ///////////////////////////////////////////////////////////////////////////
                      ////////////////////////// Draw the legend ////////////////////////////////
                      ///////////////////////////////////////////////////////////////////////////
                      const legendWidth = Math.min(width * 0.8, 400);
                      // Color Legend container
                      const legendsvg = svg.append('g')
                        .attr('class', 'legendWrapper')
                        .attr('transform', 'translate(' + (width / 2) + ',' + (height - 30) + ')');
                      // Draw the Rectangle
                      legendsvg.append('rect')
                        .attr('class', 'legendRect')
                        .attr('x', -legendWidth / 2)
                        .attr('y', 0)
                        // .attr('rx', 1 * 1.25 / 2)
                        .attr('width', legendWidth)
                        .attr('height', 10)
                        .style('fill', 'url(#legend-map)');
                      // Set scale for x-axis
                      const xScale = d3.scaleLinear()
                        .range([-legendWidth / 2, legendWidth / 2])
                        .domain([nycmap.objects.nyczipsraw.geometries[0].properties.info.minemployees_For_Map,
                        nycmap.objects.nyczipsraw.geometries[0].properties.info.maxemployees_For_Map]);
                      // Define x-axis
                      const xAxis = d3.axisBottom(xScale)
                        .ticks(5)
                        // .tickFormat(formatPercent)
                        .scale(xScale);
                      // Set up X axis
                      legendsvg.append('g')
                        .attr('class', 'axis')
                        .attr('transform', 'translate(0,' + (10) + ')')
                        .call(xAxis);
                    }
                  },
                  (err: any) => {
                    return err;
                  });
              },
              (err: any) => {
                return err;
              });
          },
          (err: any) => {
          });
      },
      (err: any) => {
      });
  }
  public handleError(error: Response) {
    // // console.log(error);
    // return Observable.throw(error.statusText);
  }
}
