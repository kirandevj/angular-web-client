import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { GetData, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { LocalVariables, RunProcess } from '../shared/local.variables';
import { SpinnerComponent } from '@app/common/index';

@Component({
  templateUrl: './discount-comparsion.html',
  styles: [`
  form {
    /* color: #0000ff;
    font-size: 14px;
    line-height: 1.42857143;
    background-color: #9999ff;
    background-image: none;
    */
    display: block;
    padding: 12px 12px;
    border: 4px solid #8080ff;
    border-radius: 10px;
  }
  .nav.navbar-nav {font-size: 15px;}
  li > a { color: aliceblue; }
  `]
})
export class DiscountComparisonComponent implements OnInit {
  user: UserInfo;
  serverInfoCalled: boolean;
  fdstime: Date;
  sdstime: Date;
  showspinner: boolean;
  sendtofooter: FooterInfo;
  form: FormGroup;
  Products: Array<Selection>;
  Options: Array<Selection>;
  Years: Array<Selection>;
  Months: Array<Selection>;
  MonthBack: number;
  PlaceholderProducts: string;
  PlaceholderOptions: string;
  PlaceholderYears: string;
  PlaceholderMonths: string;
  PlaceholderMonthBack: number;
  server: string;
  image0: string;
  image1: string;
  reportsInfo: boolean;
  ReportsArray: Array<RunProcess>;
  variablesHome: string;
  showspinner2: boolean;
  constructor(
    private ss: SharedServices,
    private gv: GlobalVariables, private route: ActivatedRoute,
    private lv: LocalVariables
  ) { }

  ngOnInit() {
    this.fdstime = new Date();
    this.sdstime = new Date();
    this.fdstime.setDate(this.sdstime.getDate() - 364);
    document.getElementById('FdsDate')['valueAsDate'] = this.fdstime;
    document.getElementById('SdsDate')['valueAsDate'] = this.sdstime;
    this.serverInfoCalled = false;
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.server = this.gv.get('api', 'api');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.variablesHome = 'discountcomparison';
    this.form = new FormGroup({});
    // this.form.addControl('Product', new FormControl());
    // this.form.addControl('Option', new FormControl());
    // this.form.addControl('Year', new FormControl());
    // this.form.addControl('Month', new FormControl());
    // this.form.addControl('MonthBack', new FormControl());
    // this.Products = this.ss.getProducts();
    // this.Options = this.ss.getDataIntegrityList(this.Products[0].label);
    // this.Years = this.ss.getYears();
    // this.Months = this.ss.getMonths();
    // this.MonthBack = 1;
    // this.PlaceholderProducts = this.Products[0].label;
    // this.PlaceholderOptions = this.Options[0].label;
    // this.PlaceholderYears = this.ss.getYearsHolderSds();
    // this.PlaceholderMonths = this.ss.getMonthsHolderSds();
    // this.PlaceholderMonthBack = this.MonthBack;
    // this.user = this.ss.getCache('localStorage', 'user', 'object');
    // this.ReportsArray = this.lv.get(this.variablesHome);
    // if (this.ReportsArray.length !== 0) {
    //   this.reportsInfo = false;
    // } else {
    //   this.reportsInfo = true;
    // }
  }
  onSubmit(formValues: any) {
    const rr: GetData = {
      product: this.ss.getFormValue(formValues.Product, this.PlaceholderProducts, this.Products, 'value', 'label')
        .replace(/–/g, '').replace(/\s+/g, '_'),
      option: this.ss.getFormValue(formValues.Option, this.PlaceholderOptions, this.Options, 'value', 'label'),
      asofyr: +this.ss.getFormValue(formValues.Year, this.PlaceholderYears, this.Years, 'value', 'label'),
      asofmm: +this.ss.getFormValue(formValues.Month, this.PlaceholderMonths, this.Months, 'value', 'label'),
      mmsback: +this.ss.getFormValueInputImproved(document.getElementById('mb')['value'], ''),
      qryname: this.ss.getQueryName('G', 'D', +this.ReportsArray.length + 1),
      username: this.user.name,
      c: this.ss.getPass(),
      fingerprint: '',
      filename: '',
      filenameshort: '',
      imageprocess: this.image1,
      timeframe: '',
      env: this.gv.get('excelfilesave', 'excelfilesave')
    };
    rr.fingerprint = rr.mmsback.toString() + rr.asofyr.toString() + rr.asofmm.toString() +
      rr.product + rr.option.replace(/\s+/g, '');
    rr.filenameshort = rr.product + '_' +
      rr.option.replace(/–/g, '').replace(/\s+/g, '_') + '_'
      + this.ss.getNumberToString(rr.asofmm, 2) + '_' + rr.asofyr.toString() + '_'
      + rr.username.replace(' ', '_') + '.csv';
    rr.filename = rr.env + rr.filenameshort;
    const p: RunProcess = {
      name: rr.filenameshort,
      run: true,
      object: rr
    };
    if (rr.option !== 'None') {
      this.lv.add(this.variablesHome, p, rr.fingerprint);
      this.ReportsArray = this.lv.get(this.variablesHome);
      if (this.ReportsArray.length !== 0) {
        this.reportsInfo = false;
      } else {
        this.reportsInfo = true;
      }
    }
  }
  runReport(r: GetData) {
    this.ReportsArray.forEach((e: RunProcess, i: number) => {
      if (e.object.fingerprint === r.fingerprint) {
        e.object.imageprocess = e.object.imageprocess.replace('.png', '.gif');
        this.getGetData(e.object);
      }
    });
  }
  deleteReport(r: GetData) {
    this.lv.remove(this.variablesHome, r.fingerprint);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  selected(value: any): void {
    this.Options = this.ss.getDataIntegrityList(value.label);
    this.PlaceholderOptions = this.Options[0].label;
  }
  getGetData(v: GetData) {
    this.ss.getDataIntegrityProcess(this.server, v)
      .subscribe(
        res1 => {
          if (res1 === 't') {
            const downloadfolder: string = this.gv.get('excelfiledownload', 'excelfiledownload') + v.filenameshort;
            this.ss.downloadFileObservable(downloadfolder, v.filenameshort)
              .subscribe(
                res2 => {
                  this.lv.remove(this.variablesHome, v.fingerprint);
                  this.ReportsArray = this.lv.get(this.variablesHome);
                  if (this.ReportsArray.length === 0) {
                    this.reportsInfo = true;
                  }
                  const v2: CleanFileAndServer = {
                    fullfilename: v.filename,
                    qryname: v.qryname,
                    c: v.c
                  };
                  this.ss.cleanFileServer(this.server, v2)
                    .subscribe(
                      () => { }, err => { });
                }, err => {
                  const v2: CleanFileAndServer = {
                    fullfilename: v.filename,
                    qryname: v.qryname,
                    c: v.c
                  };
                  this.ss.cleanFileServer(this.server, v2)
                    .subscribe(
                      () => { }, err1 => { });
                });
          }
        }, err => {
          const v2: CleanFileAndServer = {
            fullfilename: v.filename,
            qryname: v.qryname,
            c: v.c
          };
          this.ss.cleanFileServer(this.server, v2)
            .subscribe(
              () => { }, err1 => { });
        });
  }
  GetExcelFile(formValues: any) {

  }
}
