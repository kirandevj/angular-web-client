import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SharedServices } from '@app/common/index';
// Import RxJs required methods
import { map, filter, scan, catchError, mergeMap } from 'rxjs/operators';
import {
  routs, MonthlyVariance, LossRatio, InternalPricing, Wccsr, WageAnalysis, ThirdPartyDeliverables,
  PreloadedIDsInfoProcess, ESAC
} from '@app/datamodels/index';
import { RunProcessObject } from '../shared/local.variables';
@Injectable()
export class RiskFinanceServices {
  constructor(private http: HttpClient, private ss: SharedServices) { }
  getRouts = (): string[] => routs;
  getRout(r: string) {
    return routs.find(rout => rout.url === r);
  }
  getRiskMonthlyVariance(api: string, v: MonthlyVariance): Observable<string[]> {
    return this.http.post(api + 'api/MainAPI?riskMonthlyVariance=riskMonthlyVariance', v).pipe(map((r: string[]) => {
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));
  }
  getRiskInternalPricing(api: string, v: InternalPricing): Observable<string[]> {
    const obj: InternalPricing = {};
    obj.product = v.product;
    obj.qryname = v.qryname;
    obj.asofyr = v.asofyr;
    obj.asofmm = v.asofmm;
    obj.mmsback = v.mmsback;
    obj.states = v.states;
    obj.c = v.c;
    obj.username = v.username;
    obj.env = v.env;
    obj.filenameshort = v.filenameshort;
    // return this.http.post(api + 'api/MainAPI?riskInternalPricing=riskInternalPricing', obj).map((r: Response) => r
    // ).catch((e: any) => Observable.throw(e.error || 'Server error'));
    return this.http.post(api + 'api/MainAPI?riskInternalPricing=riskInternalPricing', obj).pipe(map((r: string[]) => {
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));
  }
  getRiskLossRatio(api: string, v: LossRatio): Observable<string[]> {
    return this.http.post(api + 'api/MainAPI?riskLossRatio=riskLossRatio', v).pipe(map((r: string[]) => {
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));
  }
  getRiskESAC(api: string, v: ESAC): Observable<string[]> {
    return this.http.post(api + 'api/MainAPI?riskesac=riskesac', v).pipe(map((r: string[]) => {
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));
  }
  getRiskGenericReporting(api: string, v: RunProcessObject): Observable<string[]> {
    return this.http.post(api + 'api/MainAPI?riskgenericreporting=r', v).pipe(map((r: string[]) => {
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));
  }
  getWageAnalysis(api: string, v: WageAnalysis): Observable<string[]> {
    const obj: WageAnalysis = {};
    obj.sources = v.sources;
    obj.asofyrfds = v.asofyrfds;
    obj.asofmmfds = v.asofmmfds;
    obj.asofyrsds = v.asofyrsds;
    obj.asofmmsds = v.asofmmsds;
    obj.levelanalysis = v.levelanalysis;
    obj.mmsback = v.mmsback;
    obj.qryname = v.qryname;
    obj.username = v.username;
    obj.c = v.c;
    obj.env = v.env;
    const apiPoint = api + 'api/MainAPI?wageanalysis=wageanalysis';
    // return this.http.post(apiPoint, obj).map((r: Response) => {
    //   return r;
    // }
    // ).catch((e: any) => Observable.throw(e.error || 'Server error'));
    return this.http.post(apiPoint, obj).pipe(map((r: string[]) => {
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));
  }
  getThirdPartyDeliverables(api: string, v: ThirdPartyDeliverables): Observable<string[]> {
    const apiPoint = api + 'api/MainAPI?thirdpartydeliverables=thirdpartydeliverables';
    // return this.http.post(apiPoint, v).map((r: Response) => {
    //   return r;
    // }
    // ).catch((e: any) => Observable.throw(e.error || 'Server error'));
    return this.http.post(apiPoint, v).pipe(map((r: string[]) => {
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));
  }
  getWCCSR(api: string, v: Wccsr): Observable<string[]> {
    const apiPoint = api + 'api/MainAPI?riskwccsr=riskwccsr';
    return this.http.post(apiPoint, v).pipe(map((r: string[]) => {
      // // console.log('observable returning');
      // // console.log(r);
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));
  }
  getPreloadedIDsInfoProcess(api: string, v: PreloadedIDsInfoProcess): Observable<string[]> {
    const apiPoint = api + 'api/MainAPI?preloadedidsinfoprocess=preloadedidsinfoprocess';
    return this.http.post(apiPoint, v).pipe(map((r: string[]) => {
      // // console.log('observable returning');
      // // console.log(r);
      return r;
    }
    ), catchError((e: any) => Observable.throw(e)));
  }
}




