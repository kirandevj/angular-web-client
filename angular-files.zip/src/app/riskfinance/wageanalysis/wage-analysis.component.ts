import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { RiskFinanceServices } from '../shared/risk-finance.service';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { WageAnalysis, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { LocalVariables, RunProcess } from '../shared/local.variables';

@Component({
  templateUrl: './wage-analysis.html',
  styles: [`form {
    /* color: #0000ff;
    font-size: 14px;
    line-height: 1.42857143;
    background-color: #9999ff;
    background-image: none;
    */
    display: block;
    padding: 12px 12px;
    border: 4px solid #8080ff;
    border-radius: 10px;
  }
  .nav.navbar-nav {font-size: 15px;}
  li > a { color: aliceblue; }
  `]
})
export class WageAnalysisComponent implements OnInit {
  user: UserInfo;
  sendtofooter: FooterInfo;
  form: FormGroup;
  Products: Array<Selection>;
  Yearsfds: Array<Selection>;
  Yearssds: Array<Selection>;
  Monthsfds: Array<Selection>;
  Monthssds: Array<Selection>;
  Levels: Array<Selection>;
  MonthBack: number;
  PlaceholderProducts: string;
  PlaceholderYearsfds: string;
  PlaceholderYearssds: string;
  PlaceholderMonthsfds: string;
  PlaceholderMonthssds: string;
  PlaceholderLevels: string;
  PlaceholderMonthBack: number;
  server: string;
  image0: string;
  image1: string;
  reportsInfo: boolean;
  ReportsArray: Array<RunProcess>;
  variablesHome: string;
  constructor(private rfs: RiskFinanceServices, private ss: SharedServices,
    private gv: GlobalVariables, private route: ActivatedRoute, private lv: LocalVariables) { }

  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.variablesHome = 'wagesanalysis';
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.form.addControl('Product', new FormControl());
    this.form.addControl('Yearfds', new FormControl());
    this.form.addControl('Monthfds', new FormControl());
    this.form.addControl('Yearsds', new FormControl());
    this.form.addControl('Monthsds', new FormControl());
    this.form.addControl('Level', new FormControl());
    this.form.addControl('State', new FormControl());
    this.form.addControl('pycy', new FormControl());
    this.form.addControl('yesno', new FormControl());
    this.form.addControl('ClaimAmount', new FormControl());
    this.form.addControl('MonthBack', new FormControl());
    this.form.addControl('CappingAmount', new FormControl());
    this.Products = this.ss.getProductsAll();
    this.Yearsfds = this.ss.getYears();
    this.Yearssds = this.Yearsfds;
    this.Monthsfds = this.ss.getMonths();
    this.Monthssds = this.Monthsfds;
    this.PlaceholderYearsfds = this.ss.getYearsHolderFds();
    this.PlaceholderYearssds = this.ss.getYearsHolderSds();
    this.PlaceholderMonthsfds = this.ss.getMonthsHolderFds();
    this.PlaceholderMonthssds = this.ss.getMonthsHolderSds();
    this.Levels = this.ss.getLevelOfDataAnalyses();
    this.MonthBack = 36;
    this.PlaceholderProducts = this.Products[0].label;
    this.PlaceholderLevels = this.Levels[0].label;
    this.PlaceholderMonthBack = this.MonthBack;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  onSubmit(formValues: any) {
    const rr: WageAnalysis = {
      sources: this.ss.getFormValue(formValues.Product, this.PlaceholderProducts, this.Products, 'value', 'label')
        .replace(/–/g, '').replace(/\s+/g, '_'),
      asofyrfds: +this.ss.getFormValue(formValues.Yearfds, this.PlaceholderYearsfds, this.Yearsfds, 'value', 'label'),
      asofmmfds: +this.ss.getFormValue(formValues.Monthfds, this.PlaceholderMonthsfds, this.Monthsfds, 'value', 'label'),
      asofyrsds: +this.ss.getFormValue(formValues.Yearsds, this.PlaceholderYearssds, this.Yearssds, 'value', 'label'),
      asofmmsds: +this.ss.getFormValue(formValues.Monthsds, this.PlaceholderMonthssds, this.Monthssds, 'value', 'label'),
      levelanalysis: this.ss.getFormValue(formValues.Level, this.PlaceholderLevels, this.Levels, 'value', 'label'),
      mmsback: +this.ss.getFormValueInputImproved(document.getElementById('mb')['value'], this.PlaceholderMonthBack),
      qryname: this.ss.getQueryName('W', 'A', + this.ReportsArray.length + 1),
      username: this.user.name,
      c: this.ss.getPass(),
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      fingerprint: '',
      process: '',
      imageprocess: this.image1
    };
    rr.fingerprint = rr.mmsback.toString() + rr.asofyrfds.toString() + rr.asofmmfds.toString()
      + rr.asofyrsds.toString() + rr.asofmmsds.toString() +
      rr.sources + rr.levelanalysis.replace(/\s+/g, '');
    rr.process = 'Wages_Analysis_' + rr.sources.replace(/-/g, '_').replace(/\s+/g, '_') + '_' +
      rr.levelanalysis.replace(/\s+/g, '_').replace(/-/g, '_') + '_' + this.ss.getMainTimeFrame() +
      '_' + rr.username.replace(' ', '_') + '.xlsx';
    const p: RunProcess = {
      name: rr.process,
      run: true,
      object: rr
    };
    this.lv.add(this.variablesHome, p, rr.fingerprint);
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  runReport(r: WageAnalysis) {
    this.ReportsArray.forEach((e: RunProcess, i: number) => {
      if (e.object.fingerprint === r.fingerprint) {
        e.object.imageprocess = e.object.imageprocess.replace('.png', '.gif');
        this.getWageAnalysis(e.object);
      }
    });
  }
  deleteReport(r: WageAnalysis) {
    this.lv.remove(this.variablesHome, r.fingerprint);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  getWageAnalysis(v: WageAnalysis) {
    this.rfs.getWageAnalysis(this.server, v)
      .subscribe(
        res => {
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
              for (let i = 0; i < res.length; i++) {
                if (res[i] !== null) {
                  /////////////////////////// Cleaning server and web folder
                  const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                  // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
                  // const filenamefullpath = env + filename;
                  let vv: CleanFileAndServer;
                  if (i === 0) {
                    vv = {
                      fullfilename: res[i],
                      qryname: v.qryname,
                      c: v.c
                    };
                  } else {
                    vv = {
                      fullfilename: res[i],
                      qryname: 'none',
                      c: v.c
                    };
                  }
                  this.ss.cleanFileServer(this.server, vv).subscribe(
                    () => { }, err1 => { });
                }
              }
              // --------------- Cleaning all - web and oracle - END
            }, err => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
            });
        },
        err => { });
  }
  normalizeMMB(v: number) {
    if (v > this.PlaceholderMonthBack) {
      document.getElementById('mb')['value'] = this.PlaceholderMonthBack;
    }
  }
}
