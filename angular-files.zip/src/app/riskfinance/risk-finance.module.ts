import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SelectModule } from 'angular2-select';
import { d3 } from 'd3';
import { GetUsaMapService } from './maps/usa/usa-get-data.service';
// import { CsvService } from 'angular2-json2csv';
import { GetNYCHeatMapsService } from './maps/ny/newyorkcity/nyc-heat-maps.service';
import { CurrencyPipe } from '@app/common/currency.pipe';
import { RiskNavBarComponent } from './nav/risk-navbar.component';
import { RiskFinanceComponent } from './risk-finance.component';
import { MonthlyVarianceComponent } from './monthlyvariance/monthly-variance.component';
import { LossRatioComponent } from './lossratio/loss-ratio.component';
import { ActuarialTrianglesComponent } from './actuarialtriangles/actuarial-triangles.component';
import { LossStratificationComponent } from './lossstratification/loss-stratification.component';
import { WageAnalysisComponent } from './wageanalysis/wage-analysis.component';
import { PricingComponent } from './pricing/pricing.component';
import { WCCSRComponent } from './wccsr/wccsr.component';
import { WCClaimsComponent } from './wcclaims/wc-claims.component';
import { UsaMapComponent } from './maps/usa/usa-map.component';
import { NYCHeatMapsComponent } from './maps/ny/newyorkcity/nyc-heat-maps.component';
import { RiskFinanceRoutes } from './risk-finance.routes';
import { LocalVariables } from './shared/local.variables';
import { RiskFinanceServices } from './shared/risk-finance.service';
import { GetDataComponent } from './getdata/getdata.component';
import { DataIntegrityComponent } from './dataintegrity/data-integrity.component';
import { ThridPartyComponent } from './thirdparty/third-party.component';
import { DiscountComparisonComponent } from './discountcomparison/discount-comparison.component';
import { SpinnerModule } from '@app/common/index';
import { RatesChangedComponent } from './rateschanged/rateschanged.component';
import { WorkHoursComponent } from './workhours/workhours.component';
import { DataLoadsComponent } from './dataload/dataload.component';
import { FileActionModule } from '../components/files/file-action.module';
import { PreLoadedModule } from '../components/preloaded/pre-loaded.module';
import { ProgressInfoModule } from '../components/progress-info/progress-info.module';
import { WseComparisonComponent } from './wsecomparison/wse-comparison.component';

@NgModule({
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(RiskFinanceRoutes),
    SelectModule,
    SpinnerModule,
    FileActionModule,
    PreLoadedModule,
    ProgressInfoModule
  ],
  declarations: [
    RiskFinanceComponent,
    RiskNavBarComponent,
    MonthlyVarianceComponent,
    LossRatioComponent,
    ActuarialTrianglesComponent,
    LossStratificationComponent,
    WageAnalysisComponent,
    PricingComponent,
    WCCSRComponent,
    UsaMapComponent,
    NYCHeatMapsComponent,
    CurrencyPipe,
    GetDataComponent,
    DataIntegrityComponent,
    ThridPartyComponent,
    DiscountComparisonComponent,
    RatesChangedComponent,
    WorkHoursComponent,
    DataLoadsComponent,
    WCClaimsComponent,
    WseComparisonComponent
  ],
  providers: [
    RiskFinanceServices,
    GetUsaMapService,
    GetNYCHeatMapsService,
    LocalVariables
  ]
})
export class RiskFinanceModule {
  selectedPro(): any {
  }
}
