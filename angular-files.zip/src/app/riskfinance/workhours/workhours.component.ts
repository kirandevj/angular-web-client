import { Component, ViewEncapsulation, OnInit, ChangeDetectionStrategy, Input, ChangeDetectorRef } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { PreloadedIDsInfoProcess, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { RiskFinanceServices } from '../shared/risk-finance.service';
import { ChannelService, ChannelEvent } from '../../services/channel.sevice';
import { BehaviorSubject } from 'rxjs';

@Component({
  templateUrl: './work-hours.html',
  styles: [`
  form {
    /* color: #0000ff;
    font-size: 14px;
    line-height: 1.42857143;
    background-color: #9999ff;
    background-image: none;
    */
    display: block;
    padding: 12px 12px;
    border: 4px solid #8080ff;
    border-radius: 10px;
  }
  .nav.navbar-nav {font-size: 15px;}
  li > a { color: aliceblue; }
  `],
  changeDetection: ChangeDetectionStrategy.Default
})
export class WorkHoursComponent implements OnInit {
  @Input() message: ChannelEvent = {
    Name: '',
    ChannelName: '',
    Timestamp: (new Date(Date.now() - ((new Date()).getTimezoneOffset() * 60000))).toISOString().slice(0, -1),
    Data: {
      State: 'Process info here',
      PercentComplete: 0,
      json: ''
    },
    Json: ''
  };
  items: ChannelEvent[] = [];
  items$ = new BehaviorSubject(this.items);
  env = '';
  sentToSignalRChannel = 'riskworkhours';
  receivedFromService = '';
  eventName: string;
  items2: string[] = [];
  dataprogressinfo = 'Progress info here';
  IDs: string;
  PlaceHolderIDs: string;
  Products: Array<Selection>;
  PlaceholderProducts: string;
  startdate: Date;
  enddate: Date;
  FirstTimes: Array<Selection>;
  PlaceholderFirstTimes: string;
  showspinner: boolean;
  filenames: string[];
  showfile: boolean;
  showbuttontoprocess: boolean;
  sendtofileloadermessages: any[] = ['', false];
  filetobeprocess: string;
  user: UserInfo;
  sendtofooter: FooterInfo;
  form: FormGroup;
  server: string;
  image0: string;
  image1: string;
  Servers: Array<Selection>;
  PlaceholderServers: string;
  constructor(private rfs: RiskFinanceServices, private ss: SharedServices,
    private gv: GlobalVariables, private route: ActivatedRoute,
    private channelService: ChannelService,
    private cdr: ChangeDetectorRef) {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.eventName = this.sentToSignalRChannel;
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.user = this.ss.getCache('localStorage', 'user', 'object');
  }
  ngOnInit() {
    this.startdate = new Date((new Date()).getTime() - (new Date()).getTimezoneOffset() * 60000);
    this.enddate = new Date((new Date()).getTime() - (new Date()).getTimezoneOffset() * 60000);
    this.startdate.setMonth(this.enddate.getMonth() - 3);
    // this.startdate.setDate(this.startdate.getDate());
    document.getElementById('startdate')['valueAsDate'] = this.startdate;
    document.getElementById('enddate')['valueAsDate'] = this.enddate;
    this.form = new FormGroup({});
    this.form.addControl('ID', new FormControl());
    this.form.addControl('FirstTime', new FormControl());
    this.IDs = 'Enter 3 or 4 digits company id';
    this.PlaceHolderIDs = this.IDs;
    this.form.addControl('Product', new FormControl());
    this.Products = this.ss.getProductsAllExtended();
    this.PlaceholderProducts = this.Products[2].label;
    this.form.addControl('Server', new FormControl());
    this.Servers = this.ss.getServers();
    this.PlaceholderServers = this.Servers[0].label;
    this.sendtofileloadermessages[0] = this.server;
    this.sendtofileloadermessages[1] = false;
    this.showbuttontoprocess = false;
    this.FirstTimes = this.ss.getYesNo();
    this.PlaceholderFirstTimes = this.FirstTimes[0].label;
  }
  RunProcess(formValues: any) {
    this.showbuttontoprocess = true;
    const rr: PreloadedIDsInfoProcess = {
      process: 'Risk - Work Hours',
      clientid: (this.ss.getFormValueInputImproved(document.getElementById('idn')['value'], '')).toLocaleUpperCase(),
      fileloaded: this.filetobeprocess,
      // server: this.ss.getFormValue(formValues.Server, this.PlaceholderServers, this.Servers, 'value', 'label'),
      server: 'HRLITER',
      product: this.ss.getFormValue(formValues.Product, this.PlaceholderProducts, this.Products, 'value', 'label'),
      startdate: this.ss.getDateFromHTMLInput(document.getElementById('startdate')['value']),
      enddate: this.ss.getDateFromHTMLInput(document.getElementById('enddate')['value']),
      firsttimerunprocess: this.ss.getFormValue(formValues.FirstTime, this.PlaceholderFirstTimes, this.FirstTimes, 'value', 'label'),
      qryname: this.user.machine + 'WH',
      username: this.user.name,
      c: this.ss.getPass(),
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      channel: this.eventName,
      eventname: this.eventName,
      signalr: this.channelService.connectionID$
    };
    // console.log(rr);
    this.getPreloadedIDsInfoProcess(rr);
  }
  getPreloadedIDsInfoProcess(v: PreloadedIDsInfoProcess) {
    this.rfs.getPreloadedIDsInfoProcess(this.server, v)
      .subscribe(
        res => {
          // console.log(res);
          this.showbuttontoprocess = false;
          this.sendtofileloadermessages[1] = false;
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              // /////////////////////////// Cleaning server and web folder
              // for (let i = 0; i < res.length; i++) {
              //   if (res[i] !== null) {
              //     const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
              //     // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
              //     const filenamefullpath = env + filename;
              //     let vv: CleanFileAndServer;
              //     if (i === 0) {
              //       vv = {
              //         fullfilename: res[i],
              //         qryname: v.qryname,
              //         c: v.c
              //       };
              //     } else {
              //       vv = {
              //         fullfilename: res[i],
              //         qryname: 'none',
              //         c: v.c
              //       };
              //     }
              //     this.ss.cleanFileServer(this.server, vv).subscribe(
              //       () => { }, err1 => { });
              //   }
              // }
              /////////////////////////// Cleaning all - web and oracle - END
            }, err => { });
        },
        err => {
          // // console.log(err);
          this.showbuttontoprocess = false;
          this.sendtofileloadermessages[1] = false;
        });
  }
  /////////////////// Data loads here
  receiveFromFileServiceLoad(files: string[]) {
    if (files.length > 0) {
      // this.sentToSignalRChannel = files[0].replace('.', '').replace(/\s+/g, '_');
      this.sendtofileloadermessages[4] = this.sentToSignalRChannel;
      this.sendtofileloadermessages[5] = this.sentToSignalRChannel;
      // this.items = [];
      // this.items2 = [];
    }
  }
  ////////////////// Data loads end here
  receiveFromFileServiceProgress($event: ChannelEvent) {
    this.items.push($event);
    // // console.log($event);
    this.message = $event;
    this.cdr.detectChanges();
    if ($event.Data.FileNames.length > 0) {
      const allowedfiles = ['xlsx', 'csv'];
      const env = this.gv.get('excelfiledownload', 'excelfiledownload');
      // console.log($event.Data.FileNames);
      this.showspinner = false;
      this.ss.downloadFilesFromSignalRService($event.Data.FileNames, env, allowedfiles, true, this.server);
    }
  }
}
