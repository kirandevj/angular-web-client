import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { PreloadedIDsInfoProcess, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { RiskFinanceServices } from '../shared/risk-finance.service';

@Component({
  templateUrl: './rates-changed.html',
  styles: [`
  form {
    /* color: #0000ff;
    font-size: 14px;
    line-height: 1.42857143;
    background-color: #9999ff;
    background-image: none;
    */
    display: block;
    padding: 12px 12px;
    border: 4px solid #8080ff;
    border-radius: 10px;
  }
  .nav.navbar-nav {font-size: 15px;}
  li > a { color: aliceblue; }
  `]
})
export class RatesChangedComponent implements OnInit {
  IDs: string;
  PlaceHolderIDs: string;
  Products: Array<Selection>;
  PlaceholderProducts: string;
  startdate: Date;
  enddate: Date;
  showspinner: boolean;
  filenames: string[];
  showfile: boolean;
  showbuttontoprocess: boolean;
  sendtofileloadermessages: any[] = ['', false];
  filetobeprocess: string;
  user: UserInfo;
  sendtofooter: FooterInfo;
  form: FormGroup;
  server: string;
  image0: string;
  image1: string;
  Servers: Array<Selection>;
  PlaceholderServers: string;
  constructor(private rfs: RiskFinanceServices, private ss: SharedServices,
    private gv: GlobalVariables, private route: ActivatedRoute) { }

  ngOnInit() {
    this.startdate = new Date((new Date()).getTime() - (new Date()).getTimezoneOffset() * 60000);
    this.enddate = new Date((new Date()).getTime() - (new Date()).getTimezoneOffset() * 60000);
    this.startdate.setMonth(this.enddate.getMonth() - 36);
    // this.startdate.setDate(this.startdate.getDate());
    document.getElementById('startdate')['valueAsDate'] = this.startdate;
    document.getElementById('enddate')['valueAsDate'] = this.enddate;
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.form.addControl('ID', new FormControl());
    this.IDs = 'Enter 3 or 4 digits company id';
    this.PlaceHolderIDs = this.IDs;
    this.form.addControl('Product', new FormControl());
    this.Products = this.ss.getProductsAllExtended();
    this.PlaceholderProducts = this.Products[2].label;
    this.form.addControl('Server', new FormControl());
    this.Servers = this.ss.getServers();
    this.PlaceholderServers = this.Servers[0].label;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.sendtofileloadermessages[0] = this.server;
    this.sendtofileloadermessages[1] = false;
    this.showbuttontoprocess = false;
  }
  RunProcess(formValues: any) {
    this.showbuttontoprocess = true;
    const rr: PreloadedIDsInfoProcess = {
      process: 'Risk - Rates changed',
      clientid: (this.ss.getFormValueInputImproved(document.getElementById('idn')['value'], '')).toLocaleUpperCase(),
      fileloaded: this.filetobeprocess,
      // server: this.ss.getFormValue(formValues.Server, this.PlaceholderServers, this.Servers, 'value', 'label'),
      server: 'HRLITER',
      product: this.ss.getFormValue(formValues.Product, this.PlaceholderProducts, this.Products, 'value', 'label'),
      startdate: this.ss.getDateFromHTMLInput(document.getElementById('startdate')['value']),
      enddate: this.ss.getDateFromHTMLInput(document.getElementById('enddate')['value']),
      qryname: this.ss.getQueryName('R', 'RC', 0),
      username: this.user.name,
      c: this.ss.getPass(),
      env: this.gv.get('excelfilesave', 'excelfilesave')
    };
    // console.log(rr);
    this.getPreloadedIDsInfoProcess(rr);
  }
  getPreloadedIDsInfoProcess(v: PreloadedIDsInfoProcess) {
    this.rfs.getPreloadedIDsInfoProcess(this.server, v)
      .subscribe(
        res => {
          // console.log(res);
          this.showbuttontoprocess = false;
          this.sendtofileloadermessages[1] = false;
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              // /////////////////////////// Cleaning server and web folder
              // for (let i = 0; i < res.length; i++) {
              //   if (res[i] !== null) {
              //     const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
              //     // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
              //     const filenamefullpath = env + filename;
              //     let vv: CleanFileAndServer;
              //     if (i === 0) {
              //       vv = {
              //         fullfilename: res[i],
              //         qryname: v.qryname,
              //         c: v.c
              //       };
              //     } else {
              //       vv = {
              //         fullfilename: res[i],
              //         qryname: 'none',
              //         c: v.c
              //       };
              //     }
              //     this.ss.cleanFileServer(this.server, vv).subscribe(
              //       () => { }, err1 => { });
              //   }
              // }
              /////////////////////////// Cleaning all - web and oracle - END
            }, err => { });
        },
        err => {
          // // console.log(err);
          this.showbuttontoprocess = false;
          this.sendtofileloadermessages[1] = false;
        });
  }
  /////////////////// Data loads here
  receiveFromFileService($event) {
    // // console.log($event);
    this.filenames = $event;
    if (this.filenames.length === 0) {
      this.showfile = false;
    } else {
      this.showfile = true;
    }
    this.filetobeprocess = this.filenames[0];
  }
  ////////////////// Data loads end here
}
