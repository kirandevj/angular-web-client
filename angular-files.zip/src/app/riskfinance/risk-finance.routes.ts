import { RiskFinanceComponent } from './risk-finance.component';
import { MonthlyVarianceComponent } from './monthlyvariance/monthly-variance.component';
import { LossRatioComponent } from './lossratio/loss-ratio.component';
import { WageAnalysisComponent } from './wageanalysis/wage-analysis.component';
import { PricingComponent } from './pricing/pricing.component';
import { WCCSRComponent } from './wccsr/wccsr.component';
import { GetDataComponent } from './getdata/getdata.component';
import { DataIntegrityComponent } from './dataintegrity/data-integrity.component';
import { ThridPartyComponent } from './thirdparty/third-party.component';
import { DiscountComparisonComponent } from './discountcomparison/discount-comparison.component';
import { RatesChangedComponent } from './rateschanged/rateschanged.component';
import { WorkHoursComponent } from './workhours/workhours.component';
import { DataLoadsComponent } from './dataload/dataload.component';
import { ActuarialTrianglesComponent } from './actuarialtriangles/actuarial-triangles.component';
import { LossStratificationComponent } from './lossstratification/loss-stratification.component';
import { WCClaimsComponent } from './wcclaims/wc-claims.component';
import { WseComparisonComponent } from './wsecomparison/wse-comparison.component';

export const RiskFinanceRoutes = [
  { path: '', component: RiskFinanceComponent },
  { path: 'riskfinance', component: RiskFinanceComponent },
  { path: 'monthlyvariance', component: MonthlyVarianceComponent },
  { path: 'lossratio', component: LossRatioComponent },
  { path: 'wageanalysis', component: WageAnalysisComponent },
  { path: 'wccsr', component: WCCSRComponent },
  { path: 'pricing', component: PricingComponent },
  { path: 'getdata', component: GetDataComponent },
  { path: 'dataintegrity', component: DataIntegrityComponent },
  { path: 'thirdparty', component: ThridPartyComponent },
  { path: 'rateschanged', component: RatesChangedComponent },
  { path: 'workhours', component: WorkHoursComponent },
  { path: 'dataloads', component: DataLoadsComponent },
  { path: 'actuarialtriangles', component: ActuarialTrianglesComponent },
  { path: 'lossstratification', component: LossStratificationComponent },
  { path: 'discountcomparison', component: DiscountComparisonComponent },
  { path: 'wcclaims', component: WCClaimsComponent },
  { path: 'wsecomparison', component: WseComparisonComponent }
];
