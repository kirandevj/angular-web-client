import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { RiskFinanceServices } from '../shared/risk-finance.service';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { InternalPricing, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { LocalVariables, RunProcess } from '../shared/local.variables';

@Component({
  templateUrl: './pricing.html',
  styles: [`
  form {
    /* color: #0000ff;
    font-size: 14px;
    line-height: 1.42857143;
    background-color: #9999ff;
    background-image: none;
    */
    display: block;
    padding: 12px 12px;
    border: 4px solid #8080ff;
    border-radius: 10px;
  }
  .nav.navbar-nav {font-size: 15px;}
  li > a { color: aliceblue; }
  `]
})
export class PricingComponent implements OnInit {
  user: UserInfo;
  form: FormGroup;
  Products: Array<Selection>;
  PlaceholderProducts: string;
  Years: Array<Selection>;
  PlaceholderYears: string;
  Months: Array<Selection>;
  PlaceholderMonths: string;
  MonthBack: number;
  PlaceholderMonthBack: number;
  States: Array<Selection>;
  PlaceholderStates: string;
  CappingAmount: number;
  server: string;
  image0: string;
  image1: string;
  reportsInfo: boolean;
  ReportsArray: Array<RunProcess>;
  variablesHome: string;
  constructor(private rfs: RiskFinanceServices, private ss: SharedServices,
    private gv: GlobalVariables, private route: ActivatedRoute, private lv: LocalVariables) { }

  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.variablesHome = 'pricing';
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.CappingAmount = 1000000;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }

    this.form = new FormGroup({});

    this.form.addControl('Product', new FormControl());
    this.Products = this.ss.getProductsAll();
    this.PlaceholderProducts = this.Products[0].label;

    this.form.addControl('Year', new FormControl());
    this.Years = this.ss.getYears();
    this.PlaceholderYears = this.ss.getYearsHolderSds();

    this.form.addControl('Month', new FormControl());
    this.Months = this.ss.getMonths();
    this.PlaceholderMonths = this.ss.getMonthsHolderSds();

    this.form.addControl('State', new FormControl());
    this.States = this.ss.getStatesOption();
    this.PlaceholderStates = this.States[0].label;

    this.form.addControl('MonthBack', new FormControl());
    this.MonthBack = 12;
    this.PlaceholderMonthBack = this.MonthBack;


  }
  onSubmit(formValues: any) {
    const rr: InternalPricing = {
      product: this.ss.getFormValue(formValues.Product, this.PlaceholderProducts, this.Products, 'value', 'label')
        .replace(/–/g, '').replace(/\s+/g, '_'),
      qryname: this.ss.getQueryName('M', 'V', +this.ReportsArray.length + 1),
      asofyr: +this.ss.getFormValue(formValues.Year, this.PlaceholderYears, this.Years, 'value', 'label'),
      asofmm: +this.ss.getFormValue(formValues.Month, this.PlaceholderMonths, this.Months, 'value', 'label'),
      mmsback: +this.ss.getFormValueInputImproved(document.getElementById('mb')['value'], this.PlaceholderMonthBack),
      states: this.ss.getServerStateOption(this.ss.getFormValue(formValues.State, this.PlaceholderStates, this.States, 'value', 'label')),
      cappingamount: this.CappingAmount,
      c: this.ss.getPass(),
      username: this.user.name,
      fingerprint: '',
      filename: '',
      filenameshort: '',
      imageprocess: this.image1,
      timeframe: this.ss.getMainTimeFrame(),
      env: this.gv.get('excelfilesave', 'excelfilesave')
    };
    rr.fingerprint = rr.product + rr.mmsback.toString() + rr.asofyr.toString() + rr.asofmm.toString() + rr.states;
    // rr.filenameshort = rr.product + '_IP_' + this.ss.getNumberToString(rr.asofmm, 2) + '_' + rr.asofyr.toString() + '_MB_' +
    //   rr.mmsback.toString() + '_' + this.user.name + '_TF_' + rr.timeframe + '.xlsx';
    rr.filenameshort = rr.product + '_IP_' + this.ss.getNumberToString(rr.asofmm, 2) + '_' + rr.asofyr.toString() + '_MB_' +
      rr.mmsback.toString() + '_' + this.user.name.replace(' ', '_') + '.xlsx';
    rr.filename = rr.env + rr.filenameshort;
    const p: RunProcess = {
      name: rr.filenameshort,
      run: true,
      object: rr
    };
    this.lv.add(this.variablesHome, p, rr.fingerprint);
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  runReport(r: InternalPricing) {
    this.ReportsArray.forEach((e: RunProcess, i: number) => {
      if (e.object.fingerprint === r.fingerprint) {
        e.object.imageprocess = e.object.imageprocess.replace('.png', '.gif');
        this.getRiskInternalPricingCall(e.object);
      }
    });
  }
  deleteReport(r: InternalPricing) {
    this.lv.remove(this.variablesHome, r.fingerprint);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  getRiskInternalPricingCall(v: InternalPricing) {
    this.rfs.getRiskInternalPricing(this.server, v)
      .subscribe(
        res => {
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
              // --------------- Cleaning all - web and oracle - START
              for (let i = 0; i < res.length; i++) {
                if (res[i] !== null) {
                  /////////////////////////// Cleaning server and web folder
                  const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                  // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
                  // const filenamefullpath = env + filename;
                  let vv: CleanFileAndServer;
                  if (i === 0) {
                    vv = {
                      fullfilename: res[i],
                      qryname: v.qryname,
                      c: v.c
                    };
                  } else {
                    vv = {
                      fullfilename: res[i],
                      qryname: 'none',
                      c: v.c
                    };
                  }
                  this.ss.cleanFileServer(this.server, vv).subscribe(
                    () => { }, err1 => { });
                }
              }
              // --------------- Cleaning all - web and oracle - END
            }, err => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
            });
        },
        err => { });
  }
  normalizeMMB(v: number) {
    if (v > this.PlaceholderMonthBack) {
      document.getElementById('mb')['value'] = this.PlaceholderMonthBack;
    }
  }
}
