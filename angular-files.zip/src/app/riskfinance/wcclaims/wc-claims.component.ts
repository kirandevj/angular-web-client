import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { RiskFinanceServices } from '../shared/risk-finance.service';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { LocalVariables, RunProcess, RunProcessObject } from '../shared/local.variables';

@Component({
  templateUrl: './wc-claims.html',
  styles: [`
  form {
    /* color: #0000ff;
    font-size: 14px;
    line-height: 1.42857143;
    background-color: #9999ff;
    background-image: none;
    */
    display: block;
    padding: 12px 12px;
    border: 4px solid #8080ff;
    border-radius: 10px;
  }
  .nav.navbar-nav {font-size: 15px;}
  li > a { color: aliceblue; }
  `]
})
export class WCClaimsComponent implements OnInit {
  user: UserInfo;
  sendtofooter: FooterInfo;
  form: FormGroup;
  Years: Array<Selection>;
  Months: Array<Selection>;
  States: Array<Selection>;
  pycys: Array<Selection>;
  ascdesc: Array<Selection>;
  yesnos: Array<Selection>;
  ClaimsAmounts: Array<Selection>;
  Stratifications: Array<Selection>;
  Ranges: string;
  StatesOptions: string;
  AmountForDrivers: number;

  PlaceholderYears: string;
  PlaceholderMonths: string;
  PlaceholderStates: string;
  Placeholderpycys: string;
  Placeholderyesnos: string;
  PlaceholderClaimsAmounts: string;
  PlaceholderRanges: string;
  PlaceholderStatesOptions: string;
  Placeholderascdesc: string;
  PlaceholderStratifications: string;
  PlaceholderAmountForDrivers: number;

  startdate: Date;

  server: string;
  image0: string;
  image1: string;
  reportsInfo: boolean;
  ReportsArray: Array<RunProcess>;
  variablesHome: string;
  constructor(private rfs: RiskFinanceServices, private ss: SharedServices,
    private gv: GlobalVariables, private route: ActivatedRoute, private lv: LocalVariables) { }

  ngOnInit() {
    const d = new Date();
    d.setMonth(d.getMonth() - 4);
    this.startdate = new Date(+new Date(d.getFullYear(), d.getMonth() + 1, 1) - (12 * 3600 * 1000));
    document.getElementById('startdate')['valueAsDate'] = this.startdate;
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.variablesHome = 'wcclaims';
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});

    this.form.addControl('Year', new FormControl());
    this.form.addControl('Month', new FormControl());
    this.form.addControl('Level', new FormControl());
    this.form.addControl('State', new FormControl());
    this.form.addControl('pycy', new FormControl());
    this.form.addControl('yesno', new FormControl());
    this.form.addControl('ClaimAmount', new FormControl());
    this.form.addControl('Ranges', new FormControl());
    this.form.addControl('StatesOptions', new FormControl());
    this.form.addControl('yearsorder', new FormControl());
    this.form.addControl('Stratification', new FormControl());
    this.form.addControl('AmountForDriver', new FormControl());

    this.ascdesc = this.ss.getAscendingDescending();
    this.Years = this.ss.getYears();
    this.Months = this.ss.getMonths();
    this.States = this.ss.getStatesOption();
    this.pycys = this.ss.getPyCy();
    this.yesnos = this.ss.getYesNo();
    this.ClaimsAmounts = this.ss.getClaimsAmountsStructure();
    this.Stratifications = this.ss.getLossStratificationOptions();
    this.Ranges = '0,1000,10000,50000,100000,500000,1000000';
    this.StatesOptions = 'CA,FL,NY,TX';
    this.AmountForDrivers = 75000;
    this.PlaceholderAmountForDrivers = this.AmountForDrivers;

    this.Placeholderascdesc = this.ascdesc[0].label;
    this.PlaceholderYears = this.ss.getYearsHolderSds();
    this.PlaceholderMonths = this.ss.getMonthsHolderSds();
    this.PlaceholderStates = this.States[0].label;
    this.Placeholderpycys = this.pycys[1].label;
    this.Placeholderyesnos = this.yesnos[0].label;
    this.PlaceholderClaimsAmounts = this.ClaimsAmounts[0].label;
    this.PlaceholderRanges = this.Ranges;
    this.PlaceholderStatesOptions = this.StatesOptions;
    this.PlaceholderStratifications = this.Stratifications[0].label;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  onSubmit(formValues: any) {
    const rr: RunProcessObject = {
      asofyr: +this.ss.getFormValue(formValues.Year, this.PlaceholderYears, this.Years, 'value', 'label'),
      asofmm: +this.ss.getFormValue(formValues.Month, this.PlaceholderMonths, this.Months, 'value', 'label'),
      report: this.variablesHome,
      qryname: this.ss.getQueryName('L', 'S', +this.ReportsArray.length + 1),
      transport:
        this.ss.getQueryName('L', 'S', 0) + '|' +
        +this.ss.getFormValue(formValues.Year, this.PlaceholderYears, this.Years, 'value', 'label') + '|' +
        +this.ss.getFormValue(formValues.Month, this.PlaceholderMonths, this.Months, 'value', 'label') + '|' +
        this.ss.getFormValue(formValues.ClaimAmount, this.PlaceholderClaimsAmounts, this.ClaimsAmounts, 'value', 'label') + '|' +
        this.ss.getServerStateOption(this.ss.getFormValue(formValues.State, this.PlaceholderStates, this.States, 'value', 'label')) + '|' +
        this.ss.getFormValueInputImproved(this.form.controls.StatesOptions.value, this.PlaceholderStatesOptions) + '|' +
        this.ss.getServerPolicyFiscalYear(this.ss.getFormValue(formValues.pycy, this.Placeholderpycys, this.pycys, 'value', 'label'))
        + '|' +
        this.ss.getServerAscendingDescending(this.ss.getFormValue(formValues.yearsorder,
          this.Placeholderascdesc, this.ascdesc, 'value', 'label')) + '|' +
        this.ss.getDateFromHTMLInput(document.getElementById('startdate')['value']) + '|' +
        this.ss.getFormValueInputImproved(this.form.controls.Ranges.value, this.PlaceholderRanges) + '|' +
        this.ss.getFormValue(formValues.Stratification,
          this.PlaceholderStratifications, this.Stratifications, 'value', 'label') + '|' +
        this.ss.getFormValue(formValues.yesno, this.Placeholderyesnos, this.yesnos, 'value', 'label') + '|' +
        this.ss.getFormValueInputImproved(this.form.controls.AmountForDriver.value, this.PlaceholderAmountForDrivers)
      ,
      c: this.ss.getPass(),
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      imageprocess: this.image1
    };
    rr.name = this.user.name;
    rr.fingerprint = rr.asofyr.toString() + rr.asofmm.toString() + rr.transport;
    rr.filenameshort = 'WC_Claims_Package_'
      + this.ss.getNumberToString(rr.asofmm, 2) + '_' + rr.asofyr.toString() + '_' + rr.name.replace(' ', '_');
    rr.filename = rr.env + rr.filenameshort;
    // console.log(rr);
    const p: RunProcess = {
      name: rr.filenameshort,
      run: true,
      object: rr
    };
    this.lv.add(this.variablesHome, p, rr.fingerprint);
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  runReport(r: RunProcessObject) {
    this.ReportsArray.forEach((e: RunProcess, i: number) => {
      if (e.object.fingerprint === r.fingerprint) {
        e.object.imageprocess = e.object.imageprocess.replace('.png', '.gif');
        this.getReport(e.object);
      }
    });
  }
  deleteReport(r: RunProcessObject) {
    this.lv.remove(this.variablesHome, r.fingerprint);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  getReport(v: RunProcessObject) {
    this.rfs.getRiskGenericReporting(this.server, v)
      .subscribe(
        res => {
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
              ///////////////////////// Cleaning server and web folder
              for (let i = 0; i < res.length; i++) {
                if (res[i] !== null) {
                  const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                  // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
                  // const filenamefullpath = env + filename;
                  let vv: CleanFileAndServer;
                  if (i === 0) {
                    vv = {
                      fullfilename: res[i],
                      qryname: v.qryname,
                      c: v.c
                    };
                  } else {
                    vv = {
                      fullfilename: res[i],
                      qryname: 'none',
                      c: v.c
                    };
                  }
                  this.ss.cleanFileServer(this.server, vv).subscribe(
                    () => { }, err1 => { });
                }
              }
              ///////////////////////// Cleaning all - web and oracle - END
            }, err => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
            });
        },
        err => { });
  }
}
