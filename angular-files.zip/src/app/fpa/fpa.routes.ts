import { FPAComponent } from './fpa.component';
import { GetDataComponent } from './getdata/getdata.component';
export const FPARoutes = [
    { path: '', component: FPAComponent },
    { path: 'getdata', component: GetDataComponent }
];
