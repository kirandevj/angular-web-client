import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SelectModule } from 'angular2-select';
import { FPANavBarComponent } from './nav/fpa-navbar.component';
import { FPAComponent } from './fpa.component';
import { FPARoutes } from './fpa.routes';
import { FPAServices } from './shared/fpa.services';
import { ApiServices } from '@app/common/index';
import { GetDataComponent } from './getdata/getdata.component';
import { LocalVariables } from './shared/local.variables';
import { FooterModule } from '@app/common/index';
import { SpinnerModule } from '@app/common/index';
import { SharedServices } from '@app/common/index';
import { ProgressInfoModule } from '@app/components/progress-info/progress-info.module';
@NgModule({
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(FPARoutes),
    SelectModule,
    FooterModule,
    SpinnerModule,
    ProgressInfoModule
  ],
  declarations: [
    FPANavBarComponent,
    FPAComponent,
    GetDataComponent
  ],
  providers: [
    FPAServices,
    ApiServices,
    LocalVariables,
    SharedServices
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class FPAModule {
  // selectedPro(): any {
  // }
}
