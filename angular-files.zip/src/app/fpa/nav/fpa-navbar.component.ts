import { Component, OnInit } from '@angular/core';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { UserInfo, FooterInfo } from '@app/datamodels/index';

@Component({
  selector: './app-fpa-nav-bar',
  templateUrl: './fpa-navbar.html',
  styles: [`
  .nav.navbar-nav {font-size: 15px;}
  li > a { color: aliceblue; }
`]
})
export class FPANavBarComponent implements OnInit {
  user: UserInfo;
  sendtofooter: FooterInfo;
  server: string;
  image0: string;
  constructor(private ss: SharedServices, private gv: GlobalVariables) {
  }
  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    if (!this.ss.getCache('localStorage', 'user', 'string')) {
      this.getUserInfo();
    } else {
      this.user = this.ss.getCache('localStorage', 'user', 'object');
    }
  }
  getUserInfo() {
    // Get all comments
    this.ss.getUserInfo()
      .subscribe(
      user => { this.user = user; this.ss.setCache('localStorage', 'user', this.user, 'object'); }, // Bind to view
      err => {
        // Log errors if any
        // // console.log(err);
      });
  }
}
