import { Component, ViewEncapsulation, OnInit, ElementRef } from '@angular/core';
import { UserInfo, mapProduct, FooterInfo } from '@app/datamodels/index';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { FooterComponent } from '@app/common/index';

@Component({
  // encapsulation: ViewEncapsulation.None,
  templateUrl: './fpa.html',
  styleUrls: ['./fpa.component.css']
})
export class FPAComponent implements OnInit {
  mapoption: string;
  user: UserInfo;
  sendtofooter: FooterInfo;
  server: string;
  mapNYCOptions: Array<string>;
  mapNYCOptionsTitle: string;
  showmap = false;
  constructor(private ss: SharedServices, private gv: GlobalVariables, private element: ElementRef
  ) {
    // this.parentNativeElement = element.nativeElement;
  }
  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - Accounting module landing page issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
  }
}
