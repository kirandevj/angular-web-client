import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SharedServices, GlobalVariables } from '@app/common/index';
// Import RxJs required methods
import { map, filter, scan, catchError, mergeMap } from 'rxjs/operators';

@Injectable()
export class FPAServices {
    constructor(private http: HttpClient, private ss: SharedServices) { }
    ProcessTempRequestFSPROD(api: string, v: Object): Observable<Object> {
        // return this.http.post(api + 'api/Accounting?MainModuleInfo=MainModuleInfo', v).map((r: Response) => r
        // ).catch((e: any) => Observable.throw(e.error || 'Server error'));
        return this.http.post(api + 'api/Accounting?MainModuleInfo=MainModuleInfo', v).pipe(map((r: Object) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
}
