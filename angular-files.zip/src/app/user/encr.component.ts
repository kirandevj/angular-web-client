import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { Router } from '@angular/router';
import { UserInfo, FooterInfo } from '@app/datamodels/index';
import { FooterComponent } from '@app/common/index';
import { SpinnerComponent } from '@app/common/index';

@Component({
  templateUrl: './encr.component.html',
  styleUrls: ['./encr.component.css']
})

export class EncrComponent implements OnInit {
  loading = true;
  sendtofooter: FooterInfo;
  showspinner: boolean;
  tempname = '';
  tempnameview = true;
  server: string;
  image0: string;
  image1: string;
  EncryptionKey: string;
  Machine: string;
  PlaceholderEncryptionKey: string;
  PlaceholderMachine: string;
  form: FormGroup;
  constructor(private ss: SharedServices, private gv: GlobalVariables, private route: Router) { }

  ngOnInit() {
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - Initial set up issue'
    };

    // console.log(window.location);
    // console.log(window.location.pathname);
    // console.log(window.location.origin);
    //////// This tread runs on latest
    // if (window.location.origin === 'http://localhost:4200') {
    //   this.server = 'test';
    // } else {
    //   //////// This tread runs on latest
    //   if (window.location.origin === 'http://localhost:4201') {
    //     this.server = 'test_latest';
    //   } else {
    //     this.server = 'pro';
    //   }
    // }
    switch (window.location.origin) {
      case 'http://localhost:4200':
        this.server = 'test';
        break;
      case 'http://brspwferiskd1.ad.corp.local':
        this.server = 'pro';
        break;
      case 'http://ausasmid01.ad.corp.local:99':
        this.server = 'pro_sas';
        break;
      default:
        this.server = 'pro';
        break;
    }
    this.ss.setCache('localStorage', 'server', this.server, 'string');

    this.gv.setenv(this.server);
    this.gv.setall();
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');

    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.PlaceholderEncryptionKey = 'Enter encryption key';
    this.PlaceholderMachine = 'Enter your windows login name';
    this.form.addControl('EncryptionKey', new FormControl());
    this.form.addControl('Machine', new FormControl());
  }
  onSubmit(v: FormGroup) {
    if (!this.showspinner) {
      this.showspinner = true;
      this.EncryptionKey = v['EncryptionKey'];
      this.Machine = v['Machine'];
      this.getUserInfo();
      let r = this.EncryptionKey;
      r = r.trim().replace(/ /g, '');
      this.ss.setCache('localStorage', 'pass', r, 'string');
    }
  }
  getUserInfo() {
    // Get all comments
    this.ss.getUserInfo(this.server, this.EncryptionKey, this.Machine)
      .subscribe(
        user => {
          // // console.log(user);
          this.showspinner = false;
          if (user.name !== 'Unregistered user') {
            this.ss.setCache('localStorage', 'version', this.ss.getCache('sessionStorage', 'version', 'string'), 'string');
            this.ss.setCache('localStorage', 'user', user, 'object');
            if (!this.ss.getCache('localStorage', 'usamap', 'object')) {
              this.getMap('us-states.json', 'usamap');
            }
            if (!this.ss.getCache('localStorage', 'usanycmap', 'object')) {
              this.getMap('us-nyc.json', 'usanycmap');
            }
            if (!this.ss.getCache('localStorage', 'usanycmapbronx', 'object')) {
              this.getMap('us-nyc-bronx.json', 'usanycmapbronx');
            }
            if (!this.ss.getCache('localStorage', 'usanycmapbrooklyn', 'object')) {
              this.getMap('us-nyc-brooklyn.json', 'usanycmapbrooklyn');
            }
            if (!this.ss.getCache('localStorage', 'usanycmapmanhattan', 'object')) {
              this.getMap('us-nyc-manhattan.json', 'usanycmapmanhattan');
            }
            if (!this.ss.getCache('localStorage', 'usanycmapqueens', 'object')) {
              this.getMap('us-nyc-queens.json', 'usanycmapqueens');
            }
            if (!this.ss.getCache('localStorage', 'usanycmapstatenisland', 'object')) {
              this.getMap('us-nyc-statenisland.json', 'usanycmapstatenisland');
            }
            this.route.navigateByUrl('/welcome');
          } else {
            const res = this.ss.getCache('sessionStorage', 'uertesting', 'string');
            if (res === 'System.Security.Claims.ClaimsPrincipal' || res === 'AD\lpetrov' || res === 'AD\bmuthuvelu') {
              this.ss.setCache('localStorage', 'version', this.ss.getCache('sessionStorage', 'version', 'string'), 'string');
              this.ss.setCache('localStorage', 'user', user, 'object');
            } else {
              this.tempname = user.name + ' or wrong encryption key, please try again';
              this.tempnameview = false;
            }
          }
        }, // Bind to view
        err => {
          this.showspinner = false;
        });
  }
  getMap(file: string, cache: string) {
    // console.log(this.server);
    this.ss.getJsonData(this.server, file, 'get', 'text')
      .subscribe(
        m => {
          // // console.log(m);
          // // console.log(JSON.parse(m));
          this.ss.setCache('localStorage', cache, JSON.stringify(JSON.parse(m)), 'object');
        },
        err => {
          // // console.log(err);
        });
  }
}
