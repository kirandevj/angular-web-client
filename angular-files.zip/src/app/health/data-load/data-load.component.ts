import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { LossRatio, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { FileServices } from '../../components/files/file-action.service';
// import { HealthReportsData, RunProcess, LocalVariables } from '../../shared/datamodels';
// import { HealthServices } from '../../shared/health.services';
import { FooterComponent } from '@app/common/index';

@Component({
  templateUrl: './data-load.html',
  styleUrls: ['./data-load.css']
})
export class HealthDataLoadComponent implements OnInit {
  user: UserInfo;
  sendtofooter: FooterInfo;
  sendtofileloadermessages: any[] = ['', true];
  form: FormGroup;
  TypeReports: Array<Selection>;
  PlaceholderTypeReports: string;
  Products: Array<Selection>;
  PlaceholderProducts: string;
  Years: Array<Selection>;
  PlaceHolderYears: string;
  Months: Array<Selection>;
  PlaceHolderMonths: string;
  IDs: string;
  PlaceHolderIDs: string;
  filenames: string[];
  showfile: boolean;
  server: string;
  image0: string;
  image1: string;
  reportsInfo: boolean;
  // ReportsArray: Array<RunProcess>;
  variablesHome: string;
  constructor(
    private ss: SharedServices,
    private gv: GlobalVariables,
    private route: ActivatedRoute,
    // private hs: HealthServices,
    private fs: FileServices,
    // private lv: LocalVariables
  ) { }
  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    // this.variablesHome = 'di_eligibility';
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.sendtofileloadermessages[0] = this.server;
    this.sendtofileloadermessages[1] = true;
    this.sendtofileloadermessages[2] = 'health data load';
    this.form = new FormGroup({});
    this.form.addControl('Product', new FormControl());
    this.Products = this.ss.getProductsMedicalAll();
    this.PlaceholderProducts = this.Products[0].label;
    this.form.addControl('Report', new FormControl());
    this.TypeReports = this.ss.getDIHealthEligibility();
    this.PlaceholderTypeReports = this.TypeReports[0].label;
    this.form.addControl('Year', new FormControl());
    this.Years = this.ss.getYears();
    this.PlaceHolderYears = this.ss.getYearsHolderSds();
    this.form.addControl('Month', new FormControl());
    this.Months = this.ss.getMonths();
    this.PlaceHolderMonths = this.ss.getMonthsHolderSds();
    this.form.addControl('MonthBack', new FormControl());
    this.form.addControl('ID', new FormControl());
    this.IDs = 'Enter three leter client id';
    this.PlaceHolderIDs = this.IDs;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - Health data load issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
  }
  /////////////////// Data loads here
  receiveFromFileService($event) {
    this.filenames = $event;
    if (this.filenames.length === 0) {
      this.showfile = false;
    } else {
      this.showfile = true;
    }
  }
  ////////////////// Data loads end here
}
