import { Injectable } from "@angular/core";

export interface HealthReportsData {
    report?: string;
    product?: string;
    asofyr?: number;
    asofmm?: number;
    mmsback?: number;
    levelofanalyses?: string;
    clientid?: string;
    qryname?: string;
    username?: string;
    env?: string;
    c?: string;
    filename?: string;
    fingerprint?: string;
    timeframe?: string;
    imageprocess?: string;
}
export class RunProcess {
    name: string;
    run: boolean;
    object: HealthReportsData;
}
@Injectable()
export class LocalVariables {
    public _healthreports: Array<RunProcess> = [];
    public _di_eligibility: Array<RunProcess> = [];
    public _di_truven: Array<RunProcess> = [];
    get(key: string) {
        const r = this['_' + key];
        return r;
    }
    add(key: string, value: Object, fingerprint: string): void {
        let exists = false;
        this['_' + key].forEach((e: RunProcess) => {
            if (e.object.fingerprint === fingerprint) {
                exists = true;
            }
        });
        if (!exists) {
            this['_' + key].push(value);
        }
    }
    remove(key: string, fingerprint: string): void {
        this['_' + key].forEach((e: RunProcess, i: number) => {
            if (e.object.fingerprint === fingerprint) {
                this['_' + key].splice(i, 1);
            }
        });
    }
}
