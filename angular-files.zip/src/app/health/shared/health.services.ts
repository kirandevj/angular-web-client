import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { HealthReportsData } from '../shared/datamodels';
import { Selection } from '@app/datamodels/index';
// Import RxJs required methods
import { map, filter, scan, catchError, mergeMap } from 'rxjs/operators';

@Injectable()
export class HealthServices {
    constructor(private http: HttpClient, private ss: SharedServices) { }
    getRouts = (): string[] => routs;
    getRout(r: string) {
        return routs.find(rout => rout.url === r);
    }
    getHealthReportDataProcess(api: string, v: Object): Observable<string[]> {
        return this.http.post(api + 'api/HealthAPI?healthreports=healthreports', v).pipe(map((r: string[]) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));
    }
    getHealthReportDIDataProcess(api: string, v: Object): Observable<string[]> {
        return this.http.post(api + 'api/HealthAPI?healthreportsdi=healthreportsdi', v).pipe(map((r: string[]) => {
            return r;
        }
        ), catchError((e: any) => Observable.throw(e)));

    }
    getHealthReports = (): Array<Selection> => HealthReportsOptions;
}

export const HealthReportsOptions: any[] = [
    { value: 0, label: 'Basic financials' }
];
export const routs: any[] = [
    { url: 'future' }, { url: 'future2' }
];
