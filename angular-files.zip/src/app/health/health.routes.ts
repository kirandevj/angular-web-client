import { HealthComponent } from './health.component';
import { ReportsComponent } from './reports/reports.component';
import { HealthDataLoadComponent } from './data-load/data-load.component';

export const HealthRoutes = [
    { path: '', component: HealthComponent },
    { path: 'reports', component: ReportsComponent },
    { path: 'healthdataload', component: HealthDataLoadComponent },
    { path: 'dataintegrity', loadChildren: () => import('@app/health/data-integrity/health-di.module').then(m => m.HealthDIModule) }
];
