import { HealthDIComponent } from './health-di.component';
import {DIEligibilityComponent} from './eligibility/eligibility.component';
import {DITruvenComponent} from './truven/truven.component';

export const HealthDIRoutes = [
  { path: '', component: HealthDIComponent },
  { path: 'eligibility', component: DIEligibilityComponent },
  { path: 'truven', component: DITruvenComponent }
];
