import { Router, ActivatedRouteSnapshot, CanActivate } from '@angular/router';
import { Injectable } from '@angular/core';
import { HealthServices } from '../shared/health.services';

@Injectable()
export class HealthRouteActivator implements CanActivate {
  loading = true;
  constructor(private rfs: HealthServices, private router: Router) {
  }
  canActivate(router: ActivatedRouteSnapshot) {
    const routExists = !!this.rfs.getRout(router.url[0].toString());
    // // console.log(router.url);
    // tslint:disable-next-line:curly
    if (!routExists) this.router.navigate(['/404']);
    return routExists;
  }
}
