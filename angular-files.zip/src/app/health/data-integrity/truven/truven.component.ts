import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { LossRatio, Selection, UserInfo, FooterInfo, CleanFileAndServer } from '@app/datamodels/index';
import { FileActionComponent } from '../../../components/files/file-action.component';
import { FileServices } from '../../../components/files/file-action.service';
import { HealthReportsData, RunProcess, LocalVariables } from '../../shared/datamodels';
import { HealthServices } from '../../shared/health.services';
import { FooterComponent } from '@app/common/index';

@Component({
  templateUrl: './truven.html',
  styleUrls: ['./truven.component.css']
})
export class DITruvenComponent implements OnInit {
  user: UserInfo;
  sendtofooter: FooterInfo;
  sendtofileloadermessages: any[] = ['', true];
  form: FormGroup;
  Products: Array<Selection>;
  PlaceholderProducts: string;
  Years: Array<Selection>;
  PlaceHolderYears: string;
  Months: Array<Selection>;
  PlaceHolderMonths: string;
  IDs: string;
  PlaceHolderIDs: string;
  filenames: string[];
  showfile: boolean;
  server: string;
  image0: string;
  image1: string;
  reportsInfo: boolean;
  ReportsArray: Array<RunProcess>;
  variablesHome: string;
  constructor(
    private ss: SharedServices,
    private gv: GlobalVariables,
    private route: ActivatedRoute,
    private hs: HealthServices,
    private fs: FileServices,
    private lv: LocalVariables
  ) { }
  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.variablesHome = 'di_truven';
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.sendtofileloadermessages[0] = this.server;
    this.sendtofileloadermessages[1] = true;
    this.form = new FormGroup({});
    this.form.addControl('Product', new FormControl());
    this.Products = this.ss.getProductsMedicalAll();
    this.PlaceholderProducts = this.Products[0].label;
    this.form.addControl('Year', new FormControl());
    this.Years = this.ss.getYears();
    this.PlaceHolderYears = this.ss.getYearsHolderSds();
    this.form.addControl('Month', new FormControl());
    this.Months = this.ss.getMonths();
    this.PlaceHolderMonths = this.ss.getMonthsHolderSds();
    this.form.addControl('MonthBack', new FormControl());
    this.form.addControl('ID', new FormControl());
    this.IDs = 'Enter company id';
    this.PlaceHolderIDs = this.IDs;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - Health truven page issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
  }
  /////////////////// Data loads here
  receiveFromFileService($event) {
    this.filenames = $event;
    if (this.filenames.length === 0) {
      this.showfile = false;
    } else {
      this.showfile = true;
    }
  }
  ////////////////// Data loads end here
  addReport(formValues: any) {
    const rr: HealthReportsData = {
      report: 'di elig vs fpf ' + this.ss.getFormValue(formValues.Product, this.PlaceholderProducts, this.Products, 'value', 'label'),
      asofyr: +this.ss.getFormValue(formValues.Year, this.PlaceHolderYears, this.Years, 'value', 'label'),
      asofmm: +this.ss.getFormValue(formValues.Month, this.PlaceHolderMonths, this.Months, 'value', 'label'),
      mmsback: 1,
      clientid: (this.ss.getFormValueInputImproved(document.getElementById('idn')['value'], '')).toLocaleUpperCase(),
      qryname: this.ss.getQueryName('HRDI', 'R', +this.ReportsArray.length + 1),
      username: this.user.name,
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      c: this.ss.getPass(),
      filename: '',
      fingerprint: '',
      imageprocess: this.image1,
      timeframe: this.ss.getMainTimeFrame()
    };

    rr.fingerprint = rr.mmsback.toString() + rr.asofyr.toString() + rr.asofmm.toString() +
      rr.report.replace(/–/g, '').replace(/\s+/g, '_') + rr.clientid;

    rr.filename = 'Health_DI_E_vs_F_'
      + this.ss.getNumberToString(rr.asofmm, 2) + '_' + rr.asofyr.toString() + '_'
      + rr.username.replace(' ', '_') + '_' + rr.timeframe + '_' + rr.report.replace(/–/g, '').replace(/\s+/g, '_') + '.csv';

    const p: RunProcess = {
      name: rr.filename,
      run: true,
      object: rr
    };
    this.lv.add(this.variablesHome, p, rr.fingerprint);
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
    // // console.log(rr);
  }
  runReport(r: HealthReportsData) {
    this.ReportsArray.forEach((e: RunProcess, i: number) => {
      if (e.object.fingerprint === r.fingerprint) {
        e.object.imageprocess = e.object.imageprocess.replace('.png', '.gif');
        this.getHealthReportData(e.object);
      }
    });
  }
  deleteReport(r: HealthReportsData) {
    this.lv.remove(this.variablesHome, r.fingerprint);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  getHealthReportData(v: HealthReportsData) {
    this.hs.getHealthReportDIDataProcess(this.server, v)
      .subscribe(
        res => {
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles)
            .subscribe(
              res1 => {
                this.lv.remove(this.variablesHome, v.fingerprint);
                this.ReportsArray = this.lv.get(this.variablesHome);
                if (this.ReportsArray.length === 0) {
                  this.reportsInfo = true;
                }
                // --------------- Cleaning all - web and oracle - START
                for (let i = 0; i < res.length; i++) {
                  if (res[i] !== null) {
                    /////////////////////////// Cleaning server and web folder
                    const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                    // // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
                    // const filenamefullpath = env + filename;
                    let vv: CleanFileAndServer;
                    if (i === 0) {
                      vv = {
                        fullfilename: res[i],
                        qryname: v.qryname,
                        c: v.c
                      };
                    } else {
                      vv = {
                        fullfilename: res[i],
                        qryname: 'none',
                        c: v.c
                      };
                    }
                    this.ss.cleanFileServer(this.server, vv).subscribe(
                      () => { }, err1 => { });
                  }
                }
                // --------------- Cleaning all - web and oracle - END
              }, err => {
                this.lv.remove(this.variablesHome, v.fingerprint);
                this.ReportsArray = this.lv.get(this.variablesHome);
                if (this.ReportsArray.length === 0) {
                  this.reportsInfo = true;
                }
              });
        },
        err => { });
  }
}
