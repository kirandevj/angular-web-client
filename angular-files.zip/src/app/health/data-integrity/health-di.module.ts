import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SelectModule } from 'angular2-select';
import { HealthDIComponent } from './health-di.component';
import { HelthDINavBarComponent } from './nav/hel-di-navbar.component';
import { HealthDIRoutes } from './health-di.routes';
import { RunProcessVariable } from '@app/datamodels/index';
import {DIEligibilityComponent} from './eligibility/eligibility.component';
import {DITruvenComponent} from './truven/truven.component';
import { FooterModule } from '@app/common/index';
import { FileActionModule } from '../../components/files/file-action.module';

@NgModule({
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(HealthDIRoutes),
    SelectModule,
    FooterModule,
    FileActionModule
  ],
  declarations: [
    HealthDIComponent,
    HelthDINavBarComponent,
    DIEligibilityComponent,
    DITruvenComponent
  ],
  providers: [ ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class HealthDIModule {

}
