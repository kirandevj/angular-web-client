import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SelectModule } from 'angular2-select';
import { HealthComponent } from './health.component';
import { ReportsComponent } from './reports/reports.component';
import { HelthNavBarComponent } from './nav/hel-navbar.component';
import { HealthRoutes } from './health.routes';
import { HealthServices } from './shared/health.services';
import { LocalVariables } from './shared/datamodels';
import { FooterModule } from '@app/common/index';
import { HealthDataLoadComponent } from './data-load/data-load.component';
import { FileActionModule } from '../components/files/file-action.module';

@NgModule({
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(HealthRoutes),
    SelectModule,
    FooterModule,
    FileActionModule
  ],
  declarations: [
    HelthNavBarComponent,
    HealthComponent,
    ReportsComponent,
    HealthDataLoadComponent
  ],
  providers: [
    HealthServices,
    LocalVariables
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class HealthModule {
  selectedPro(): any {
  }
}
