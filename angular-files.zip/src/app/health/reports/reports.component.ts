import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedServices, GlobalVariables } from '@app/common/index';
import { ActivatedRoute } from '@angular/router';
import { UserInfo, Selection, CleanFileAndServer, FooterInfo } from '@app/datamodels/index';
import { HealthReportsData, RunProcess, LocalVariables } from '../shared/datamodels';
import { HealthServices } from '../shared/health.services';
import { FooterComponent } from '@app/common/index';

@Component({
  templateUrl: './reports.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  user: UserInfo;
  sendtofooter: FooterInfo;
  form: FormGroup;
  ReportsName: Array<Selection>;
  PlaceHolderReportsName: string;
  Levels: Array<Selection>;
  PlaceHolderLevels: string;
  Years: Array<Selection>;
  PlaceHolderYears: string;
  Months: Array<Selection>;
  PlaceHolderMonths: string;
  MonthBack: number;
  PlaceHolderMonthBack: number;
  IDs: string;
  PlaceHolderIDs: string;
  server: string;
  image0: string;
  image1: string;
  reportsInfo: boolean;
  ReportsArray: Array<RunProcess>;
  variablesHome: string;
  constructor(private ss: SharedServices,
              private gv: GlobalVariables,
              private route: ActivatedRoute,
              private hs: HealthServices,
              private lv: LocalVariables
  ) { }
  ngOnInit() {
    this.server = this.ss.getCache('localStorage', 'server', 'string');
    this.gv.setenv(this.server);
    this.gv.setall();
    this.variablesHome = 'healthreports';
    this.image1 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imageearthstop');
    this.image0 = window.location.pathname + this.gv.get('image', 'image') + this.gv.get('shortnames', 'imagelogo');
    this.server = this.gv.get('api', 'api');
    this.form = new FormGroup({});
    this.form.addControl('ReportName', new FormControl());
    this.ReportsName = this.hs.getHealthReports();
    this.PlaceHolderReportsName = this.ReportsName[0].label;
    this.form.addControl('Level', new FormControl());
    this.Levels = this.ss.getLevelOfDataAnalysesHealth();
    this.PlaceHolderLevels = this.Levels[0].label;
    this.form.addControl('Year', new FormControl());
    this.Years = this.ss.getYears();
    this.PlaceHolderYears = this.ss.getYearsHolderSds();
    this.form.addControl('Month', new FormControl());
    this.Months = this.ss.getMonths();
    this.PlaceHolderMonths = this.ss.getMonthsHolderSds();
    this.form.addControl('MonthBack', new FormControl());
    this.MonthBack = 12;
    this.PlaceHolderMonthBack = this.MonthBack;
    this.form.addControl('ID', new FormControl());
    this.IDs = 'Enter Company ID';
    this.PlaceHolderIDs = this.IDs;
    this.user = this.ss.getCache('localStorage', 'user', 'object');
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
    this.sendtofooter = {
      email: 'mailto:lyudmil.petrov@trinet.com',
      text: 'This module is supported by Actuarial and Risk departments - for support click here',
      modulesender: 'Website - Health reports issue'
    };
    this.sendtofooter.subjectline = this.sendtofooter.email + '?Subject=' + this.sendtofooter.modulesender;
    this.sendtofooter.subjectline = this.sendtofooter.subjectline.replace(/\s+/g, '%20');
  }
  onSubmit(formValues: any) {
    const rr: HealthReportsData = {
      report: this.ss.getFormValueInput(+formValues.ReportName, this.PlaceHolderReportsName, 0),
      product: 'All',
      asofyr: +this.ss.getFormValue(formValues.Year, this.PlaceHolderYears, this.Years, 'value', 'label'),
      asofmm: +this.ss.getFormValue(formValues.Month, this.PlaceHolderMonths, this.Months, 'value', 'label'),
      mmsback: +this.ss.getFormValueInputImproved(document.getElementById('mb')['value'], ''),
      levelofanalyses: this.ss.getFormValue(formValues.Level, this.PlaceHolderLevels, this.Levels, 'value', 'label'),
      clientid: (this.ss.getFormValueInputImproved(document.getElementById('idn')['value'], '')).toLocaleUpperCase(),
      qryname: this.ss.getQueryName('HR', 'R', +this.ReportsArray.length + 1),
      username: this.user.name,
      env: this.gv.get('excelfilesave', 'excelfilesave'),
      c: this.ss.getPass(),
      filename: '',
      fingerprint: '',
      imageprocess: this.image1,
      timeframe: this.ss.getMainTimeFrame()
    };
    if (rr.mmsback === 0) { rr.mmsback = +this.PlaceHolderMonths; }
    rr.fingerprint = rr.report + rr.mmsback + rr.asofyr + rr.asofmm + rr.levelofanalyses + rr.clientid;
    if (rr.clientid === '') {
      rr.filename = 'Health_'
        + this.ss.getNumberToString(rr.asofmm, 2) + '_' + rr.asofyr.toString() + '_' +
        rr.levelofanalyses.replace(/–/g, '').replace(/\s+/g, '_') + '_' + rr.username.replace(' ', '_') + '_' + rr.timeframe + '.csv';
    } else {
      rr.filename = 'Health_'
        + this.ss.getNumberToString(rr.asofmm, 2) + '_' + rr.asofyr.toString() + '_' +
        rr.levelofanalyses.replace(/–/g, '').replace(/\s+/g, '_')
        + '_' + rr.clientid + '_' + rr.username.replace(' ', '_') + '_' + rr.timeframe + '.xlsx';
    }
    const p: RunProcess = {
      name: rr.filename,
      run: true,
      object: rr
    };
    this.lv.add(this.variablesHome, p, rr.fingerprint);
    this.ReportsArray = this.lv.get(this.variablesHome);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  runReport(r: HealthReportsData) {
    this.ReportsArray.forEach((e: RunProcess, i: number) => {
      if (e.object.fingerprint === r.fingerprint) {
        e.object.imageprocess = e.object.imageprocess.replace('.png', '.gif');
        this.getHealthReportData(e.object);
      }
    });
  }
  deleteReport(r: HealthReportsData) {
    this.lv.remove(this.variablesHome, r.fingerprint);
    if (this.ReportsArray.length !== 0) {
      this.reportsInfo = false;
    } else {
      this.reportsInfo = true;
    }
  }
  getHealthReportData(v: HealthReportsData) {
    this.hs.getHealthReportDataProcess(this.server, v)
      .subscribe(
        res => {
          const allowedfiles = ['xlsx', 'csv'];
          const env = this.gv.get('excelfiledownload', 'excelfiledownload');
          this.ss.downloadFilesObservable(res, env, allowedfiles).subscribe(
            res1 => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
              // --------------- Cleaning all - web and oracle - START
              for (let i = 0; i < res.length; i++) {
                if (res[i] !== null) {
                  /////////////////////////// Cleaning server and web folder
                  const filename = res[i].slice(res[i].lastIndexOf('\\') + 1);
                  // // const file_extension = filename.slice(filename.lastIndexOf('.') + 1);
                  // const filenamefullpath = env + filename;
                  let vv: CleanFileAndServer;
                  if (i === 0) {
                    vv = {
                      fullfilename: res[i],
                      qryname: v.qryname,
                      c: v.c
                    };
                  } else {
                    vv = {
                      fullfilename: res[i],
                      qryname: 'none',
                      c: v.c
                    };
                  }
                  this.ss.cleanFileServer(this.server, vv).subscribe(
                    () => { }, err1 => { });
                }
              }
              // --------------- Cleaning all - web and oracle - END
            }, err => {
              this.lv.remove(this.variablesHome, v.fingerprint);
              this.ReportsArray = this.lv.get(this.variablesHome);
              if (this.ReportsArray.length === 0) {
                this.reportsInfo = true;
              }
            });
        },
        err => { });


    // .subscribe(
    //   res => {
    //     for (let i = 0; i < res1['length']; i++) {
    //       if (res1[i] !== null) {
    //         const filenameshort = res1[i].slice(res1[i].lastIndexOf('\\') + 1);
    //         const downloadfolder: string = this.gv.get('excelfiledownload', 'excelfiledownload') + filenameshort;
    //         // // console.log(downloadfolder);
    //         this.ss.downloadFileObservable(downloadfolder, filenameshort)
    //           .subscribe(
    //             res2 => {
    //               this.lv.remove(this.variablesHome, v.fingerprint);
    //             //   // --------------- Cleaning server tables
    //             //   const v2: CleanFileAndServer = {
    //             //     fullfilename: res1[i],
    //             //     qryname: v.qryname,
    //             //     c: v.c
    //             //   };
    //             //   this.ss.cleanFileServer(this.server, v2).subscribe(
    //             //     () => {
    //             //       if (this.ReportsArray.length !== 0) {
    //             //         this.reportsInfo = false;
    //             //       } else {
    //             //         this.reportsInfo = true;
    //             //       }
    //             //     }, err1 => {
    //             //       if (this.ReportsArray.length !== 0) {
    //             //         this.reportsInfo = false;
    //             //       } else {
    //             //         this.reportsInfo = true;
    //             //       }
    //             //     });
    //             }, err => {
    //             //   // --------------- Cleaning server tables
    //             //   const v2: CleanFileAndServer = {
    //             //     fullfilename: res1[i],
    //             //     qryname: v.qryname,
    //             //     c: v.c
    //             //   };
    //             //   this.ss.cleanFileServer(this.server, v2).subscribe(
    //             //     () => {
    //             //       if (this.ReportsArray.length !== 0) {
    //             //         this.reportsInfo = false;
    //             //       } else {
    //             //         this.reportsInfo = true;
    //             //       }
    //             //     }, err1 => {
    //             //       if (this.ReportsArray.length !== 0) {
    //             //         this.reportsInfo = false;
    //             //       } else {
    //             //         this.reportsInfo = true;
    //             //       }
    //             //     });
    //             });
    //       }
    //     }
    //   }, err => {
    //     const v2: CleanFileAndServer = {
    //       fullfilename: v.filename,
    //       qryname: v.qryname,
    //       c: v.c
    //     };
    //     this.ss.cleanFileServer(this.server, v2)
    //       .subscribe(
    //         () => { }, err1 => { });
    //     if (this.ReportsArray.length !== 0) {
    //       this.reportsInfo = false;
    //     } else {
    //       this.reportsInfo = true;
    //     }
    //   });
  }
  normalizeMMB(v: number) {
    if (v > this.PlaceHolderMonthBack * 5) {
      document.getElementById('mb')['value'] = this.PlaceHolderMonthBack;
    }
  }
}
