import { NgModule, CUSTOM_ELEMENTS_SCHEMA, Injector } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { createCustomElement } from '@angular/elements';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { Error404Component } from './errors/404.component';
import { SharedServices, GlobalVariables, ApiServices, GlobalObservables } from '@app/common/index';
import { LandingComponent } from './landing/landing.component';
import { OfflineService, DataService } from '@app/services/index';
import { FooterModule } from './components/footer/footer.module';
import { SpinnerModule } from './components/spinner/spinner.module';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ButtonComponent } from './button/button.component';
import { ChannelService, ChannelConfig, SignalrWindow } from './services/channel.sevice';
import { ChannelService0, SignalrWindow0 } from './services/signalr/signalr-service-api';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatMenuModule } from '@angular/material/menu';
import { MatSliderModule } from '@angular/material/slider';
// import { jqxBarGaugeComponent } from 'jqwidgets-scripts/jqwidgets-ts/angular_jqxbargauge';
// import { jqxBulletChartComponent } from 'jqwidgets-scripts/jqwidgets-ts/angular_jqxbulletchart';
// import { jqxChartComponent } from 'jqwidgets-scripts/jqwidgets-ts/angular_jqxchart';
// import { ChannelService, ChannelConfig, SignalrWindow } from './services/channel.sevice';
// import { ChannelService0, SignalrWindow0 } from './services/signalr/signalr-service-api';
// import { TaskComponent } from './task/task';
// const channelConfig = new ChannelConfig();
// channelConfig.url = 'http://localhost:63009/signalr/hubs';
// channelConfig.hubName = 'ChatHub';
// channelConfig.url = 'http://localhost:63009/signalr';
// channelConfig.hubName = 'EventHub';


@NgModule({
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FooterModule,
    SpinnerModule,
    HttpClientModule,
    FormsModule, ReactiveFormsModule,
    LayoutModule, MatToolbarModule,
    MatButtonModule, MatSidenavModule, MatIconModule,
    MatListModule, MatGridListModule, MatCardModule, MatMenuModule,
    MatSliderModule
  ],
  declarations: [
    AppComponent,
    LandingComponent,
    Error404Component,
    ButtonComponent,
    // jqxBarGaugeComponent,
    // jqxBulletChartComponent,
    // jqxChartComponent
  ],
  providers: [
    SharedServices,
    GlobalVariables,
    OfflineService,
    DataService,
    ApiServices,
    GlobalObservables,
    // ChartServices,
    ChannelService,
    { provide: SignalrWindow, useValue: window },
    // tslint:disable-next-line:no-angle-bracket-type-assertion
    { provide: 'channel.config', useValue: <ChannelConfig> { url: '', hubName: '' } },
    ChannelService0,
    { provide: SignalrWindow0, useValue: window }
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  entryComponents: [ButtonComponent]
  // IMPORTANT:
  // Since 'AdditionCalculateWindow' is never explicitly used (in a template)
  // we must tell angular about it.
  // entryComponents: []
})
export class AppModule {
  constructor(private injector: Injector) {
    const el = createCustomElement(ButtonComponent, {
      injector: this.injector
    });
    customElements.define('custom-button', el);
  }
}
